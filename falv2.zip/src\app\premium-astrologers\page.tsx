'use client';

import Link from 'next/link';
import { useProfile } from '@/components/ProfileProvider';
import { useLevel } from '@/components/LevelProvider';
import { useFreighter } from '@/components/FreighterProvider';
import { useState, useEffect } from 'react';

const PremiumAstrologersTheme = {
  colors: {
    primary: '#fbbf24',
    secondary: '#f97316',
    accent: '#ec4899',
    text: '#e0e7ff',
    dark: '#1e1b4b',
  },
};

function PremiumAstrologersContent() {
  const { profile } = useProfile();
  const { userLevel } = useLevel();
  const { address } = useFreighter();
  
  const [premiumAstrologers, setPremiumAstrologers] = useState<any[]>([]);

  // Load all profiles from localStorage to find premium astrologers
  useEffect(() => {
    if (!address) return;

    const astrologers: any[] = [];
    
    // Get all keys from localStorage
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith('profile_') && key?.includes('_isPremium')) {
        const addr = key.replace('profile_', '').replace('_isPremium', '');
        
        // Check if they're premium and an astrologer
        const isPremiumKey = `profile_${addr}_isPremium`;
        const isAstrologerKey = `profile_${addr}_isAstrologer`;
        const profileKey = `profile_${addr}`;
        
        const isPremium = localStorage.getItem(isPremiumKey) === 'true';
        const isAstrologer = localStorage.getItem(isAstrologerKey) === 'true';
        
        if (isPremium && isAstrologer) {
          try {
            const profileData = JSON.parse(localStorage.getItem(profileKey) || '{}');
            const levelData = localStorage.getItem(`level_${addr}`);
            const level = levelData ? JSON.parse(levelData).level : 1;
            
            astrologers.push({
              address: addr,
              ...profileData,
              level,
              isPremium,
              isAstrologer,
            });
          } catch (e) {
            console.error('Error parsing profile:', e);
          }
        }
      }
    }
    
    setPremiumAstrologers(astrologers);
  }, [address]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 relative overflow-hidden">
      {/* Arka Plan Elementleri */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-amber-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-orange-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float-slow" />
      </div>

      {/* İçerik */}
      <div className="relative z-10 min-h-screen">
        {/* Başlık */}
        <div className="bg-gradient-to-r from-amber-900/50 to-orange-900/50 backdrop-blur-sm border-b border-amber-500/30 sticky top-0 z-40">
          <div className="max-w-6xl mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="text-center flex-1">
                <p className="text-5xl mb-3">👑</p>
                <h1 className="text-3xl font-bold text-transparent bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text">
                  Premium Falcılar
                </h1>
                <p className="text-amber-300 mt-2">Deneyimli ve güvenilir falcılar</p>
              </div>
              <Link
                href="/"
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors whitespace-nowrap ml-4"
              >
                ← Geri Dön
              </Link>
            </div>
          </div>
        </div>

        {/* Ana İçerik */}
        <div className="max-w-6xl mx-auto px-4 py-12">
          {/* Premium Falcılar Listesi */}
          {premiumAstrologers.length > 0 ? (
            <div>
              <h2 className="text-2xl font-bold text-amber-300 mb-6">Mevcut Premium Falcılar ({premiumAstrologers.length})</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {premiumAstrologers.map((astrologer) => (
                  <div
                    key={astrologer.address}
                    className="p-6 rounded-2xl border-2 border-amber-500/30 bg-gradient-to-br from-amber-900/20 to-orange-900/20 hover:border-amber-400/50 transition-all backdrop-blur-sm"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <p className="text-4xl mb-2">✨</p>
                        <h3 className="text-xl font-bold text-amber-300">
                          {astrologer.name || 'Premium Falcı'}
                        </h3>
                        <p className="text-xs text-amber-400 mt-1">{astrologer.address.slice(0, 10)}...</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-yellow-400">Lv {astrologer.level || 1}</p>
                        <p className="text-xs text-amber-300 mt-1">Premium</p>
                      </div>
                    </div>
                    
                    <p className="text-sm text-purple-300 mb-4 line-clamp-2">
                      {astrologer.bio || 'Deneyimli ve güvenilir premium falcı'}
                    </p>
                    
                    <div className="space-y-2 text-xs text-amber-400 border-t border-amber-500/20 pt-3">
                      <p>⭐ {Math.floor(Math.random() * 50) + 50} soru cevaplandı</p>
                      <p>👍 {Math.floor(Math.random() * 100) + 90}% memnuniyet</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-gradient-to-br from-slate-900/30 to-slate-800/30 rounded-2xl border-2 border-slate-500/30 p-12 text-center">
              <p className="text-3xl mb-4">😔</p>
              <p className="text-xl text-purple-300 font-bold mb-2">Henüz Premium Falcı Yok</p>
              <p className="text-purple-400 mb-6">
                Şu anda premium falcı hizmetini kullanan hiç kimse yok. Lütfen daha sonra tekrar deneyin.
              </p>
              <Link
                href="/"
                className="inline-block px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-xl transition-all"
              >
                Geri Dön
              </Link>
            </div>
          )}

          {/* Bilgi Kutusu */}
          <div className="mt-12 bg-gradient-to-br from-indigo-900/30 to-slate-900/30 rounded-2xl border border-indigo-500/30 p-6 max-w-2xl mx-auto">
            <p className="text-sm text-slate-300 space-y-2">
              <span className="block font-bold text-indigo-300 mb-3">ℹ️ Premium Falcılar Hakkında</span>
              <span className="block">
                • Premium falcılar deneyimli ve güvenilir kişilerdir
              </span>
              <span className="block">
                • Yüksek seviye ve başarılı geçmiş ile tanınırlar
              </span>
              <span className="block">
                • Diğer kullanıcılara danışmanlık ve rehberlik sağlarlar
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function PremiumAstrologersPage() {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  if (!hydrated) return null;

  return <PremiumAstrologersContent />;
}
