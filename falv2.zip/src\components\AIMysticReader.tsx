'use client';

import React, { useState, useEffect } from 'react';
import { useFreighter } from './FreighterProvider';
import { useLevel } from './LevelProvider';

interface Card {
  id: number;
  name: string;
  short: string;
  long: string;
}

interface AIReading {
  zodiac: string;
  card: string;
  reading: string;
  advice: string;
  lucky: {
    number: number;
    color: string;
    day: string;
  };
  compatibility: string;
}

// Örnek AI yorumları
const AI_READINGS = {
  'Koç': {
    readings: [
      'Burada cesaretin sınandığı, yeni başlangıçların kapısı açılıyor. Enerjiniz tepe noktasında.',
      'Liderlik yeteneğiniz öne çıkıyor. Başkalarını rehberlik etme zamanı geldi.',
      'Risk almaktan korkma. Talihin seni desteklemesi için cesur adım at.',
    ],
    advice: [
      'Dürtüsel kararlardan sakın, akıl ve kalbi dengele.',
      'Sabır göster, her şey hızlı olmak zorunda değil.',
      'Çevrependekiler senin enerjiinden besleniyorlar. Olumlu kal.',
    ],
  },
  'Boğa': {
    readings: [
      'Stabilite ve güvenliğin çağında, temeller sağlamlaşıyor.',
      'Maddi konularda iyi bir dönem başlıyor. Uzun vadeli planlar yap.',
      'Sabırlı yaklaşımın sonuçlanıyor. Hasat zamanı yaklaşıyor.',
    ],
    advice: [
      'Aşırı kontrolcü olmaktan sakın.',
      'Değişime açık ol, katılık zarar görebilir.',
      'Duygularını daha çok paylaş.',
    ],
  },
  'İkizler': {
    readings: [
      'İletişim kaybolan kapıları açıyor. Söyle, dinle, konuş.',
      'Merakın seni yeni yerlere götürecek. Maceraya hazır ol.',
      'Esnek yaklaşımın avantaj sağlıyor. Çok seçeneği var.',
    ],
    advice: [
      'Kararı ertelemeden verdikten sonra net ol.',
      'Konsantrasyonunu topla, dağınık olma.',
      'Bir projeyi başına kadar bitir.',
    ],
  },
};

interface AIMysticReaderProps {
  zodiacName?: string;
  card?: Card;
}

export default function AIMysticReader({ zodiacName = 'Koç', card }: AIMysticReaderProps) {
  const { address } = useFreighter();
  const { userLevel, addPoints } = useLevel();
  const [reading, setReading] = useState<AIReading | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [readingCount, setReadingCount] = useState(0);
  const [lastReadingDate, setLastReadingDate] = useState<string | null>(null);
  const DAILY_READING_LIMIT = 2;
  const READING_COST = 5; // XLM
  const READING_REWARD = 15; // EXP

  useEffect(() => {
    if (card && zodiacName) {
      // Günlük sayacı kontrol et
      const today = new Date().toISOString().split('T')[0];
      const storedData = localStorage.getItem(`zodiac_readings_${address}`);
      
      if (storedData) {
        const data = JSON.parse(storedData);
        if (data.date === today) {
          setLastReadingDate(data.date);
          setReadingCount(data.count || 0);
        } else {
          // Yeni gün, sayacı sıfırla
          localStorage.setItem(`zodiac_readings_${address}`, JSON.stringify({ date: today, count: 0 }));
          setReadingCount(0);
          setLastReadingDate(today);
        }
      } else {
        // İlk kez
        localStorage.setItem(`zodiac_readings_${address}`, JSON.stringify({ date: today, count: 0 }));
        setReadingCount(0);
        setLastReadingDate(today);
      }
    }
  }, [address, card, zodiacName]);

  const generateReading = async () => {
    // Günlük limit kontrolü
    if (readingCount >= DAILY_READING_LIMIT) {
      alert(`⚠️ Günde ${DAILY_READING_LIMIT} kere burç falı bakabilirsiniz. Yarın tekrar deneyin!`);
      return;
    }

    // XLM kontrolü
    if (!userLevel || userLevel.rewards.xlm < READING_COST) {
      alert(`❌ Yetersiz XLM! Burç falı bakmanın bedeli: ${READING_COST} XLM`);
      return;
    }

    setIsLoading(true);
    setIsAnimating(false);

    try {
      // XLM ve EXP işlemleri
      await addPoints('xlm', -READING_COST); // XLM çıkar
      await addPoints('exp', READING_REWARD); // EXP ekle

      // Simüle edilmiş AI gecikme
      await new Promise((resolve) => setTimeout(resolve, 1500));

      const zodiacReadings = AI_READINGS[zodiacName as keyof typeof AI_READINGS] || AI_READINGS['Koç'];
      const randomReading = zodiacReadings.readings[Math.floor(Math.random() * zodiacReadings.readings.length)];
      const randomAdvice = zodiacReadings.advice[Math.floor(Math.random() * zodiacReadings.advice.length)];

      const reading: AIReading = {
        zodiac: zodiacName,
        card: card?.name || 'Gizemli Kart',
        reading: randomReading,
        advice: randomAdvice,
        lucky: {
          number: Math.floor(Math.random() * 9) + 1,
          color: ['Altın', 'Mor', 'Mavi', 'Gümüş', 'Yeşil'][Math.floor(Math.random() * 5)],
          day: ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma'][Math.floor(Math.random() * 5)],
        },
        compatibility: ['Çok Uyumlu', 'Uyumlu', 'Orta Uyumlu', 'Az Uyumlu'][Math.floor(Math.random() * 4)],
      };

      setReading(reading);

      // Günlük sayacı güncelle
      const today = new Date().toISOString().split('T')[0];
      const newCount = readingCount + 1;
      localStorage.setItem(`zodiac_readings_${address}`, JSON.stringify({ date: today, count: newCount }));
      setReadingCount(newCount);

      setIsLoading(false);
      setIsAnimating(true);
    } catch (error) {
      console.error('Burç falı okuma hatası:', error);
      alert('❌ Burç falı okunamadı. Lütfen tekrar deneyin.');
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <button
          onClick={generateReading}
          disabled={isLoading || readingCount >= DAILY_READING_LIMIT}
          className="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-all duration-300 flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
              Yapay Zeka Tarafından Yorum Yazılıyor...
            </>
          ) : readingCount >= DAILY_READING_LIMIT ? (
            <>
              ⏳ Bugünün Hakkınız Bitti
            </>
          ) : (
            <>
              🔮 Yeni Yorum Al (Bedel: {READING_COST} XLM, Kazanç: {READING_REWARD} EXP)
            </>
          )}
        </button>

        {/* Günlük Hak Göstergesi */}
        <div className="flex items-center justify-between text-sm px-4 py-2 bg-purple-900/30 rounded-lg border border-purple-500/30">
          <span className="text-purple-300">📅 Günlük Hak:</span>
          <span className="font-semibold text-yellow-300">
            {readingCount} / {DAILY_READING_LIMIT}
          </span>
        </div>

        {/* Bakiye Göstergesi */}
        <div className="flex items-center justify-between text-sm px-4 py-2 bg-indigo-900/30 rounded-lg border border-indigo-500/30">
          <span className="text-indigo-300">💰 Mevcut XLM:</span>
          <span className={`font-semibold ${(userLevel?.rewards.xlm || 0) >= READING_COST ? 'text-green-300' : 'text-red-300'}`}>
            {userLevel?.rewards.xlm.toFixed(2) || '0.00'} XLM
          </span>
        </div>
      </div>

      {reading && (
        <div
          className={`space-y-6 transition-all duration-700 ${
            isAnimating ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          }`}
        >
          {/* Başlık */}
          <div className="text-center">
            <h3 className="text-3xl font-bold text-transparent bg-gradient-to-r from-yellow-400 via-purple-400 to-pink-400 bg-clip-text mb-2">
              ✨ {reading.zodiac} - {reading.card} ✨
            </h3>
            <p className="text-yellow-300 text-sm font-semibold">Yapay Zeka Görmüş Falı</p>
          </div>

          {/* Ana Yorum */}
          <div className="bg-gradient-to-br from-indigo-900/60 to-purple-900/60 border border-purple-400/40 rounded-2xl p-6 backdrop-blur-sm">
            <div className="flex gap-4">
              <div className="text-3xl">🔮</div>
              <div>
                <h4 className="text-purple-300 font-semibold uppercase tracking-wider mb-2 text-xs">Yaşamın Mesajı</h4>
                <p className="text-white leading-relaxed text-lg italic">{reading.reading}</p>
              </div>
            </div>
          </div>

          {/* Tavsiye */}
          <div className="bg-gradient-to-br from-amber-900/40 to-orange-900/40 border border-amber-500/40 rounded-2xl p-6 backdrop-blur-sm">
            <div className="flex gap-4">
              <div className="text-3xl">💫</div>
              <div>
                <h4 className="text-amber-300 font-semibold uppercase tracking-wider mb-2 text-xs">Tavsiye</h4>
                <p className="text-yellow-100 leading-relaxed">{reading.advice}</p>
              </div>
            </div>
          </div>

          {/* Şans Faktörleri */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-gradient-to-br from-blue-900/50 to-indigo-900/50 border border-blue-400/40 rounded-xl p-4 text-center">
              <div className="text-xs uppercase text-blue-300 font-semibold tracking-wider mb-2">Şans Numarası</div>
              <div className="text-4xl font-bold text-blue-300 mb-1">{reading.lucky.number}</div>
              <div className="text-xs text-blue-200">Bu gün kullan</div>
            </div>

            <div className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 border border-green-400/40 rounded-xl p-4 text-center">
              <div className="text-xs uppercase text-green-300 font-semibold tracking-wider mb-2">Şans Rengi</div>
              <div
                className="w-full h-12 rounded-lg mb-2 border-2 border-green-300"
                style={{
                  background:
                    reading.lucky.color === 'Altın'
                      ? '#fbbf24'
                      : reading.lucky.color === 'Mor'
                        ? '#a78bfa'
                        : reading.lucky.color === 'Mavi'
                          ? '#3b82f6'
                          : reading.lucky.color === 'Gümüş'
                            ? '#d1d5db'
                            : '#10b981',
                }}
              />
              <div className="text-xs text-green-200">{reading.lucky.color}</div>
            </div>

            <div className="bg-gradient-to-br from-pink-900/50 to-rose-900/50 border border-pink-400/40 rounded-xl p-4 text-center">
              <div className="text-xs uppercase text-pink-300 font-semibold tracking-wider mb-2">Şans Günü</div>
              <div className="text-lg font-bold text-pink-300 mb-1">{reading.lucky.day}</div>
              <div className="text-xs text-pink-200">Önemli işler buna</div>
            </div>
          </div>

          {/* Uyumluluk */}
          <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 border border-purple-400/50 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-purple-300 font-semibold uppercase tracking-wider text-xs mb-1">İlişki Uyumu</h4>
                <p className="text-purple-100 text-sm">Bu dönemde {reading.compatibility}</p>
              </div>
              <div className="text-5xl">💕</div>
            </div>
          </div>

          {/* Footer Metin */}
          <div className="text-center text-xs text-slate-400 italic">
            ✨ Bu yorum yapay zeka tarafından üretilmiş eğlence amaçlıdır. ✨
          </div>
        </div>
      )}
    </div>
  );
}
