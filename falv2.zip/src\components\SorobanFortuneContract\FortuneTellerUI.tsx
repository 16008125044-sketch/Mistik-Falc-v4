'use client';

import React, { useState, useEffect } from 'react';
import { useFreighter } from '@/components/FreighterProvider';

interface Fortune {
  text: string;
  timestamp: number;
}

interface Request {
  user: string;
  timestamp: number;
}

export function FortuneTellerUI() {
  const { address, isConnected, balance } = useFreighter();
  const [fortune, setFortune] = useState<Fortune | null>(null);
  const [history, setHistory] = useState<Request[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [price, setPrice] = useState<number>(0);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminInput, setAdminInput] = useState('');
  const [fortuneText, setFortuneText] = useState('');

  useEffect(() => {
    if (isConnected && address) {
      checkIfAdmin();
      fetchPrice();
    }
  }, [isConnected, address]);

  const checkIfAdmin = async () => {
    // Admin check logic - localStorage'dan veya cüzdandan
    const adminAddress = localStorage.getItem('fortunes_admin');
    setIsAdmin(address === adminAddress);
  };

  const fetchPrice = async () => {
    try {
      // Soroban kontratından fiyat getir
      // TODO: Kontrat çağrısı - fiyat getir
      // Mock RPC call - gerçek implementasyon için stellar-sdk v11+ gerekli
      setPrice(50); // Mock değer
    } catch (error) {
      console.error('Fiyat alınamadı:', error);
    }
  };

  const requestFortune = async () => {
    if (!isConnected || !address) {
      alert('❌ Cüzdan bağlanması gerekli');
      return;
    }

    const xlmBalance = parseFloat(balance) || 0;
    if (xlmBalance < price) {
      alert(`❌ Yetersiz XLM! Gerekli: ${price} XLM, Mevcut: ${xlmBalance.toFixed(4)} XLM`);
      return;
    }

    setIsLoading(true);
    try {
      // Soroban kontratında requestFortune çağrısı
      alert(`✨ Fal isteği gönderildi! ${price} XLM harcandı.`);
    } catch (error) {
      console.error('Fal isteği başarısız:', error);
      alert('❌ Fal isteği başarısız oldu');
    } finally {
      setIsLoading(false);
    }
  };

  const getFortune = async () => {
    if (!isConnected || !address) {
      alert('❌ Cüzdan bağlanması gerekli');
      return;
    }

    setIsLoading(true);
    try {
      // Soroban kontratından son falı getir
      const mockFortune: Fortune = {
        text: 'Yıldızlar size rehberlik ediyor. İlerlemeye devam edin.',
        timestamp: Date.now(),
      };
      setFortune(mockFortune);
    } catch (error) {
      console.error('Fal alınamadı:', error);
      alert('❌ Fal alınamadı');
    } finally {
      setIsLoading(false);
    }
  };

  const getHistory = async () => {
    if (!isConnected || !address) {
      alert('❌ Cüzdan bağlanması gerekli');
      return;
    }

    setIsLoading(true);
    try {
      // Soroban kontratından geçmiş getir
      const mockHistory: Request[] = [
        { user: address, timestamp: Date.now() - 86400000 },
        { user: address, timestamp: Date.now() - 172800000 },
      ];
      setHistory(mockHistory);
    } catch (error) {
      console.error('Geçmiş alınamadı:', error);
      alert('❌ Geçmiş alınamadı');
    } finally {
      setIsLoading(false);
    }
  };

  const deliverFortune = async () => {
    if (!isAdmin) {
      alert('❌ Bu işlem sadece admin tarafından yapılabilir');
      return;
    }

    if (!adminInput || !fortuneText) {
      alert('❌ Kullanıcı adresi ve fal metni gereklidir');
      return;
    }

    setIsLoading(true);
    try {
      // Soroban kontratında deliverFortune çağrısı
      alert(`✨ Fal '${adminInput}' kullanıcısına gönderildi!`);
      setAdminInput('');
      setFortuneText('');
    } catch (error) {
      console.error('Fal gönderme başarısız:', error);
      alert('❌ Fal gönderme başarısız oldu');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Başlık */}
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text">
            🔮 Soroban Fal Sistemi
          </h1>
          <p className="text-purple-300">Blockchain üzerinde değiştirilemez fallar</p>
        </div>

        {/* Cüzdan Bilgisi */}
        {isConnected && address && (
          <div className="bg-gradient-to-r from-purple-900/50 to-indigo-900/50 rounded-2xl p-6 border border-purple-500/30">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <p className="text-sm text-slate-400 mb-2">Cüzdan Adresi</p>
                <p className="text-sm font-mono text-green-400 break-all">{address}</p>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-2">XLM Bakiyesi</p>
                <p className="text-2xl font-bold text-green-400">{parseFloat(balance).toFixed(4)} XLM</p>
              </div>
            </div>
          </div>
        )}

        {/* Kullanıcı Paneli */}
        <div className="bg-gradient-to-br from-purple-900/30 to-indigo-900/30 rounded-2xl p-8 border border-purple-500/30 space-y-6">
          <h2 className="text-2xl font-bold text-purple-300">📊 Fal İşlemleri</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={requestFortune}
              disabled={isLoading || !isConnected}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 text-white py-3 px-6 rounded-lg font-bold transition-all"
            >
              {isLoading ? '⏳ Yükleniyor...' : `✨ Fal Al (${price} XLM)`}
            </button>

            <button
              onClick={getFortune}
              disabled={isLoading || !isConnected}
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 disabled:opacity-50 text-white py-3 px-6 rounded-lg font-bold transition-all"
            >
              {isLoading ? '⏳ Yükleniyor...' : '🔍 Falımı Gör'}
            </button>

            <button
              onClick={getHistory}
              disabled={isLoading || !isConnected}
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 disabled:opacity-50 text-white py-3 px-6 rounded-lg font-bold transition-all"
            >
              {isLoading ? '⏳ Yükleniyor...' : '📜 Geçmiş'}
            </button>
          </div>

          {fortune && (
            <div className="bg-purple-900/50 rounded-lg p-6 border border-purple-500/30">
              <h3 className="text-xl font-bold text-purple-300 mb-3">✨ Son Falınız</h3>
              <p className="text-purple-100 italic mb-2">"{fortune.text}"</p>
              <p className="text-xs text-slate-400">
                {new Date(fortune.timestamp * 1000).toLocaleString('tr-TR')}
              </p>
            </div>
          )}

          {history.length > 0 && (
            <div className="bg-purple-900/50 rounded-lg p-6 border border-purple-500/30">
              <h3 className="text-xl font-bold text-purple-300 mb-3">📜 Geçmiş ({history.length})</h3>
              <div className="space-y-2">
                {history.map((h, idx) => (
                  <div key={idx} className="text-sm text-slate-300 flex justify-between">
                    <span>Fal #{idx + 1}</span>
                    <span className="text-slate-500">{new Date(h.timestamp * 1000).toLocaleString('tr-TR')}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Admin Paneli */}
        {isAdmin && (
          <div className="bg-gradient-to-br from-red-900/30 to-rose-900/30 rounded-2xl p-8 border border-red-500/30 space-y-6">
            <h2 className="text-2xl font-bold text-red-300">🔑 Admin Paneli</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">Kullanıcı Adresi</label>
                <input
                  type="text"
                  value={adminInput}
                  onChange={(e) => setAdminInput(e.target.value)}
                  placeholder="G..."
                  className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-400 mb-2">Fal Metni</label>
                <textarea
                  value={fortuneText}
                  onChange={(e) => setFortuneText(e.target.value)}
                  placeholder="Fal yorumunu yazın..."
                  rows={4}
                  className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <button
                onClick={deliverFortune}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 disabled:opacity-50 text-white py-3 px-6 rounded-lg font-bold transition-all"
              >
                {isLoading ? '⏳ Yükleniyor...' : '📤 Fal Gönder'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
