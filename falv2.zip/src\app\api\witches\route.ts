import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

// GET /api/witches - Tüm cadıları listele
export async function GET() {
  try {
    const { data, error } = await supabase
      .from('witches')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    console.error('Cadılar yüklenemedi:', error);
    return NextResponse.json({ error: 'Cadılar yüklenemedi' }, { status: 500 });
  }
}

// POST /api/witches - Yeni cadı ekle
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, avatarUrl, walletAddress, categories } = body;

    if (!name || !walletAddress) {
      return NextResponse.json({ error: 'Ad ve cüzdan adresi zorunlu' }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('witches')
      .insert([{
        name,
        description,
        avatar_url: avatarUrl,
        wallet_address: walletAddress,
        categories: categories || []
      }])
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    console.error('Cadı ekleme hatası:', error);
    return NextResponse.json({ error: 'Cadı eklenemedi' }, { status: 500 });
  }
}
