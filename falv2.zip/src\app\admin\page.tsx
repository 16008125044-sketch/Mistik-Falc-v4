'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useProfile } from '@/components/ProfileProvider';
import { MysticTarotTheme } from '@/components/mystic_tarot_theme';

export default function AdminPage() {
  const { profile, isAdmin, banUser, unbanUser, removePremiumFromUser, removeWitchFromUser } = useProfile();
  const [userAddress, setUserAddress] = useState('');
  const [action, setAction] = useState<'ban' | 'unban' | 'remove-premium' | 'remove-witch'>('ban');
  const [message, setMessage] = useState('');

  if (!isAdmin || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: MysticTarotTheme.colors.background }}>
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: MysticTarotTheme.colors.text }}>
            ❌ Yetkisiz Erişim!
          </p>
          <p style={{ color: MysticTarotTheme.colors.text }} className="mb-6">
            Bu sayfaya sadece Kral Falcı erişebilir.
          </p>
          <Link
            href="/"
            className="px-6 py-2 rounded-lg font-semibold"
            style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
          >
            Ana Sayfaya Dön
          </Link>
        </div>
      </div>
    );
  }

  const handleAction = () => {
    if (!userAddress.trim()) {
      setMessage('❌ Lütfen bir cüzdan adresi girin!');
      return;
    }

    if (action === 'ban') {
      banUser(userAddress);
      setMessage(`✅ Kullanıcı ${userAddress.slice(0, 8)}... başarıyla banlandı!`);
    } else if (action === 'unban') {
      unbanUser(userAddress);
      setMessage(`✅ Kullanıcı ${userAddress.slice(0, 8)}... başarıyla banlı listeden çıkarıldı!`);
    } else if (action === 'remove-premium') {
      removePremiumFromUser(userAddress);
      setMessage(`✅ Kullanıcı ${userAddress.slice(0, 8)}... premium rozetinden arındırıldı!`);
    } else if (action === 'remove-witch') {
      removeWitchFromUser(userAddress);
      setMessage(`✅ Kullanıcı ${userAddress.slice(0, 8)}... cadı rozetinden arındırıldı!`);
    }

    setUserAddress('');
    setTimeout(() => setMessage(''), 3000);
  };

  return (
    <div className="min-h-screen" style={{ background: MysticTarotTheme.colors.background }}>
      {/* Başlık */}
      <div className="bg-gradient-to-r from-red-600 to-orange-600 text-white shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold">👑 Kral Falcı Admin Paneli</h1>
          <p className="text-red-100 mt-2">Sistem yönetim araçları</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Admin Bilgisi */}
        <div
          className="rounded-xl shadow-xl p-6 border mb-8"
          style={{
            background: `linear-gradient(135deg, ${MysticTarotTheme.colors.secondary}, ${MysticTarotTheme.colors.background})`,
            borderColor: '#ff6b6b',
          }}
        >
          <h2 className="text-xl font-bold mb-2" style={{ color: '#ff6b6b' }}>
            👑 Kral Falcı
          </h2>
          <p className="text-sm opacity-80" style={{ color: MysticTarotTheme.colors.text }}>
            Cüzdan: {profile.walletAddress}
          </p>
        </div>

        {/* İşlem Paneli */}
        <div
          className="rounded-xl shadow-xl p-8 border mb-8"
          style={{
            background: `linear-gradient(135deg, ${MysticTarotTheme.colors.secondary}, ${MysticTarotTheme.colors.background})`,
            borderColor: MysticTarotTheme.colors.primary,
          }}
        >
          <h3 className="text-2xl font-bold mb-6" style={{ color: MysticTarotTheme.colors.highlight }}>
            ⚙️ Kullanıcı İşlemleri
          </h3>

          <div className="space-y-4">
            {/* İşlem Seçimi */}
            <div>
              <label className="block text-sm font-semibold mb-2" style={{ color: MysticTarotTheme.colors.text }}>
                📋 İşlem Seçiniz
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setAction('ban')}
                  className={`px-4 py-3 rounded-lg font-semibold transition ${
                    action === 'ban'
                      ? 'opacity-100'
                      : 'opacity-50 hover:opacity-75'
                  }`}
                  style={{
                    background: action === 'ban' ? '#dc2626' : '#666',
                    color: 'white',
                  }}
                >
                  🚫 Banla
                </button>
                <button
                  onClick={() => setAction('unban')}
                  className={`px-4 py-3 rounded-lg font-semibold transition ${
                    action === 'unban'
                      ? 'opacity-100'
                      : 'opacity-50 hover:opacity-75'
                  }`}
                  style={{
                    background: action === 'unban' ? '#16a34a' : '#666',
                    color: 'white',
                  }}
                >
                  ✅ Ban Kaldır
                </button>
                <button
                  onClick={() => setAction('remove-premium')}
                  className={`px-4 py-3 rounded-lg font-semibold transition ${
                    action === 'remove-premium'
                      ? 'opacity-100'
                      : 'opacity-50 hover:opacity-75'
                  }`}
                  style={{
                    background: action === 'remove-premium' ? '#ea580c' : '#666',
                    color: 'white',
                  }}
                >
                  👑 Premium Geri Al
                </button>
                <button
                  onClick={() => setAction('remove-witch')}
                  className={`px-4 py-3 rounded-lg font-semibold transition ${
                    action === 'remove-witch'
                      ? 'opacity-100'
                      : 'opacity-50 hover:opacity-75'
                  }`}
                  style={{
                    background: action === 'remove-witch' ? '#a855f7' : '#666',
                    color: 'white',
                  }}
                >
                  🧙‍♀️ Cadı Geri Al
                </button>
              </div>
            </div>

            {/* Cüzdan Adresi */}
            <div>
              <label className="block text-sm font-semibold mb-2" style={{ color: MysticTarotTheme.colors.text }}>
                💼 Cüzdan Adresi
              </label>
              <input
                type="text"
                value={userAddress}
                onChange={(e) => setUserAddress(e.target.value)}
                placeholder="GDYW...örneği"
                className="w-full px-4 py-3 rounded-lg bg-black/40 border border-purple-500 focus:outline-none focus:border-purple-400 text-sm"
                style={{ color: MysticTarotTheme.colors.text }}
              />
            </div>

            {/* Uygula Düğmesi */}
            <button
              onClick={handleAction}
              className="w-full px-6 py-3 rounded-lg font-bold text-white text-lg hover:opacity-80 transition"
              style={{
                background:
                  action === 'ban'
                    ? '#dc2626'
                    : action === 'unban'
                      ? '#16a34a'
                      : action === 'remove-premium'
                        ? '#ea580c'
                        : '#a855f7',
              }}
            >
              {action === 'ban'
                ? '🚫 Kullanıcıyı Banla'
                : action === 'unban'
                  ? '✅ Ban Kaldır'
                  : action === 'remove-premium'
                    ? '👑 Rozetini Geri Al'
                    : '🧙‍♀️ Cadı Rozetini Geri Al'}
            </button>
          </div>

          {/* Mesaj */}
          {message && (
            <div
              className="mt-6 px-4 py-3 rounded-lg text-center font-semibold"
              style={{
                background: message.includes('✅') ? '#16a34a' : '#dc2626',
                color: 'white',
              }}
            >
              {message}
            </div>
          )}
        </div>

        {/* Bilgi Kutusu */}
        <div
          className="rounded-xl p-6 border"
          style={{
            background: 'rgba(139, 92, 246, 0.1)',
            borderColor: MysticTarotTheme.colors.primary,
          }}
        >
          <h3 className="font-bold mb-3" style={{ color: MysticTarotTheme.colors.highlight }}>
            ℹ️ İşlemler
          </h3>
          <ul className="space-y-2 text-sm" style={{ color: MysticTarotTheme.colors.text }}>
            <li>🚫 <strong>Banla</strong>: Kullanıcıyı siteden uzaklaştır</li>
            <li>✅ <strong>Ban Kaldır</strong>: Banlandığı kullanıcıyı kaldır</li>
            <li>👑 <strong>Rozetini Geri Al</strong>: Kullanıcının premium rozetini kaldır</li>
          </ul>
        </div>

        {/* Geri Dön */}
        <div className="mt-8 text-center">
          <Link
            href="/"
            className="px-6 py-2 rounded-lg font-semibold hover:opacity-80 transition"
            style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
          >
            ← Ana Sayfaya Dön
          </Link>
        </div>
      </div>
    </div>
  );
}
