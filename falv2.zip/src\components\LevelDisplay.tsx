'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useLevel } from './LevelProvider';
import { useFreighter } from './FreighterProvider';
import { MysticTarotTheme } from './mystic_tarot_theme';

export function LevelDisplay() {
  const router = useRouter();
  const { userLevel, isLoading } = useLevel();
  const { address } = useFreighter();
  const [levelUpNotification, setLevelUpNotification] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (userLevel && address) {
      const key = `level_${address}_levelUpNotification`;
      const notif = localStorage.getItem(key);
      if (notif) {
        try {
          setLevelUpNotification(JSON.parse(notif));
          localStorage.removeItem(key);
          setTimeout(() => setLevelUpNotification(null), 5000);
        } catch {}
      }
    }
  }, [userLevel, address]);

  if (isLoading || !userLevel) return null;

  const progressPercent = (userLevel.currentExp / (userLevel.level === 10 ? 1 : 100)) * 100;

  return (
    <>
      {/* Tıklanabilir Seviye Kutusu */}
      <div 
        className="fixed top-24 right-4 max-w-xs rounded-xl shadow-2xl p-4 border cursor-pointer hover:shadow-3xl hover:scale-105 transition-all pointer-events-auto"
        style={{ 
          background: MysticTarotTheme.colors.secondary, 
          borderColor: MysticTarotTheme.colors.primary,
          zIndex: 50
        }}
        onClick={() => router.push('/profile')}
      >
        {/* Başlık */}
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-xs opacity-70" style={{ color: MysticTarotTheme.colors.text }}>Seviye</p>
            <h3 className="text-2xl font-bold" style={{ color: MysticTarotTheme.colors.primary }}>{userLevel.level}/10</h3>
          </div>
          <div className="text-right">
            <p className="text-xs font-semibold opacity-80" style={{ color: MysticTarotTheme.colors.highlight }}>{userLevel.title}</p>
          </div>
        </div>

        {/* İlerleme Barı */}
        <div className="mb-3">
          <div className="w-full bg-black/40 rounded-full h-2 overflow-hidden">
            <div 
              className="h-full transition-all duration-500" 
              style={{ 
                width: `${progressPercent}%`, 
                background: `linear-gradient(90deg, ${MysticTarotTheme.colors.primary}, ${MysticTarotTheme.colors.highlight})`
              }}
            />
          </div>
          <p className="text-xs mt-1 opacity-70" style={{ color: MysticTarotTheme.colors.text }}>
            {userLevel.currentExp} / 100 EXP
          </p>
        </div>

        {/* Puanlar */}
        <div className="grid grid-cols-3 gap-2 mb-3 text-center text-xs">
          <div className="p-2 rounded-lg" style={{ background: 'rgba(224, 224, 224, 0.1)' }}>
            <div className="text-lg">🌙</div>
            <div style={{ color: MysticTarotTheme.colors.text }}>{userLevel.rewards.moonlight}</div>
          </div>
          <div className="p-2 rounded-lg" style={{ background: 'rgba(251, 191, 36, 0.1)' }}>
            <div className="text-lg">⭐</div>
            <div style={{ color: MysticTarotTheme.colors.text }}>{userLevel.rewards.star}</div>
          </div>
          <div className="p-2 rounded-lg" style={{ background: 'rgba(124, 58, 237, 0.1)' }}>
            <div className="text-lg">💎</div>
            <div style={{ color: MysticTarotTheme.colors.text }}>{userLevel.rewards.xlm.toFixed(4)}</div>
          </div>
        </div>

        {/* Açılan içerikler */}
        {userLevel.unlockedDecks.length > 0 && (
          <div className="text-xs mb-2 p-2 rounded" style={{ background: 'rgba(124, 58, 237, 0.15)' }}>
            <p className="opacity-70" style={{ color: MysticTarotTheme.colors.text }}>
              📚 {userLevel.unlockedDecks.length} deste açıldı
            </p>
          </div>
        )}

        {/* Seviye yükselme animasyonu */}
        {levelUpNotification && (
          <div className="mt-3 p-3 rounded-lg animate-bounce" style={{ background: MysticTarotTheme.colors.primary }}>
            <p className="font-bold text-center" style={{ color: 'white' }}>🎉 Seviye {levelUpNotification.newLevel}!</p>
            <div className="flex gap-1 justify-center mt-1 text-xs">
              {levelUpNotification.rewards.map((r: any, i: number) => (
                <span key={i}>{r.icon} +{r.amount}</span>
              ))}
            </div>
          </div>
        )}

        {/* Tıkla işareti */}
        <div className="text-xs mt-2 text-center opacity-60" style={{ color: MysticTarotTheme.colors.text }}>
          Detaylar için tıkla →
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div 
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowModal(false)}
        >
          <div 
            className="max-w-3xl w-full max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl border-2 p-8"
            style={{ 
              background: `linear-gradient(135deg, ${MysticTarotTheme.colors.background}, ${MysticTarotTheme.colors.secondary})`,
              borderColor: MysticTarotTheme.colors.primary
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Başlık */}
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold mb-2" style={{ color: MysticTarotTheme.colors.primary }}>
                🏆 Seviyeler & Ranklar
              </h2>
              <p className="text-lg" style={{ color: MysticTarotTheme.colors.highlight }}>
                Seviyelendirme Sistemi
              </p>
            </div>

            {/* Seviye Tablosu */}
            <div className="space-y-3 mb-8">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => {
                const isCurrentOrPassed = level <= userLevel.level;
                const isCurrent = level === userLevel.level;
                
                const titles: Record<number, string> = {
                  1: 'Yeni Talib', 2: 'Başlangıç Medyumu', 3: 'Aydın Gözlü',
                  4: 'Kristal Temizleyici', 5: 'Ay Kütüphanecisi', 6: 'Yıldız Danışmanı',
                  7: 'Estetik Falcı', 8: 'Mistik Hakkim', 9: 'Kader Ustası', 10: 'En Büyük Falcı'
                };

                const rewards: Record<number, string> = {
                  1: '10 🌙', 2: '25 🌙 + 5 ⭐', 3: '40 🌙 + 15 ⭐',
                  4: '30 ⭐ + 3 💎', 5: '60 🌙 + 50 ⭐ + 5 💎',
                  6: '75 ⭐ + 8 💎', 7: '100 🌙 + 100 ⭐ + 12 💎',
                  8: '150 ⭐ + 20 💎', 9: '150 🌙 + 200 ⭐ + 30 💎',
                  10: '200 🌙 + 300 ⭐ + 50 💎'
                };

                return (
                  <div
                    key={level}
                    className={`p-4 rounded-lg border-l-4 transition-all ${
                      isCurrent ? 'scale-105 shadow-lg' : ''
                    }`}
                    style={{
                      background: isCurrent 
                        ? `rgba(124, 58, 237, 0.3)`
                        : isCurrentOrPassed
                        ? `rgba(124, 58, 237, 0.1)`
                        : `rgba(255, 255, 255, 0.05)`,
                      borderLeftColor: isCurrent 
                        ? MysticTarotTheme.colors.highlight
                        : isCurrentOrPassed
                        ? MysticTarotTheme.colors.primary
                        : '#444'
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold" style={{ color: MysticTarotTheme.colors.primary }}>
                            {level}
                          </span>
                          <span className="text-lg font-semibold" style={{ color: MysticTarotTheme.colors.text }}>
                            {titles[level]}
                          </span>
                          {isCurrent && (
                            <span className="text-xs px-2 py-1 rounded-full animate-pulse" style={{ background: MysticTarotTheme.colors.highlight, color: 'black' }}>
                              Mevcut
                            </span>
                          )}
                        </div>
                        <p className="text-sm mt-2 opacity-80" style={{ color: MysticTarotTheme.colors.text }}>
                          Ödüller: {rewards[level]}
                        </p>
                      </div>
                      <div className="text-3xl opacity-70">
                        {isCurrent && '👈'}
                        {isCurrentOrPassed && !isCurrent && '✓'}
                        {!isCurrentOrPassed && '🔒'}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Puan Sistemi Açıklaması */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="p-4 rounded-lg" style={{ background: 'rgba(224, 224, 224, 0.1)', borderTop: '3px solid #e0e0e0' }}>
                <p className="text-3xl mb-2">🌙</p>
                <p className="font-semibold mb-2" style={{ color: MysticTarotTheme.colors.text }}>Ay Işığı</p>
                <p className="text-xs opacity-80" style={{ color: MysticTarotTheme.colors.text }}>Temel puan. Yeni desteler ve temalar açar.</p>
              </div>
              <div className="p-4 rounded-lg" style={{ background: 'rgba(251, 191, 36, 0.1)', borderTop: '3px solid #fbbf24' }}>
                <p className="text-3xl mb-2">⭐</p>
                <p className="font-semibold mb-2" style={{ color: MysticTarotTheme.colors.text }}>Yıldız</p>
                <p className="text-xs opacity-80" style={{ color: MysticTarotTheme.colors.text }}>Tema ve kategori özelleştirmesi için.</p>
              </div>
              <div className="p-4 rounded-lg" style={{ background: 'rgba(124, 58, 237, 0.1)', borderTop: '3px solid #7c3aed' }}>
                <p className="text-3xl mb-2">💎</p>
                <p className="font-semibold mb-2" style={{ color: MysticTarotTheme.colors.text }}>Kristal</p>
                <p className="text-xs opacity-80" style={{ color: MysticTarotTheme.colors.text }}>Premium içerik ve özel fal için.</p>
              </div>
            </div>

            {/* Kapatma Butonu */}
            <div className="text-center">
              <button
                onClick={() => setShowModal(false)}
                className="px-6 py-2 rounded-lg font-semibold hover:opacity-80 transition"
                style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
