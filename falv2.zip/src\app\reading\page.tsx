'use client';

import Link from 'next/link';
import { useFreighter } from '@/components/FreighterProvider';
import { useState, useEffect } from 'react';

interface Character {
  address: string;
  name: string;
  image: string | null;
  level: number;
}

function ReadingContent() {
  const { address } = useFreighter();
  const [characters, setCharacters] = useState<Character[]>([]);
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userBalance, setUserBalance] = useState(9999.99);

  // Karakterleri yükle
  useEffect(() => {
    const characterList: Character[] = [];
    const processedAddresses = new Set<string>();

    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key) continue;

        // Tüm profilleri bul (name key'i olanlar)
        if (key.startsWith('profile_') && key.endsWith('_name')) {
          const addressPart = key.replace('profile_', '').replace('_name', '');

          if (!processedAddresses.has(addressPart) && addressPart !== address) {
            processedAddresses.add(addressPart);

            const nameValue = localStorage.getItem(key);
            const imageKey = `profile_${addressPart}_image`;
            const levelKey = `level_${addressPart}`;
            const name = nameValue || 'Mistik Falcı';
            const image = localStorage.getItem(imageKey);
            const levelData = localStorage.getItem(levelKey);
            const level = levelData ? JSON.parse(levelData).level : 1;

            characterList.push({
              address: addressPart,
              name,
              image,
              level,
            });
          }
        }
      }
    } catch (error) {
      console.error('localStorage yükleme hatası:', error);
    }

    setCharacters(characterList);
  }, [address]);

  const handleSubmitMessage = async () => {
    if (!selectedCharacter || !message.trim() || !address) {
      alert('⚠️ Lütfen bir karakter seçin ve mesaj yazın');
      return;
    }

    const MESSAGE_COST = 50;
    if (!userBalance || userBalance < MESSAGE_COST) {
      alert(`❌ Yetersiz bakiye! Mesaj bedeli: ${MESSAGE_COST} XLM | Mevcut: ${userBalance?.toFixed(2) || '0'} XLM`);
      return;
    }

    setIsSubmitting(true);

    try {
      // Mesajı localStorage'a kaydet
      const messagesKey = `profile_${selectedCharacter.address}_messages`;
      const existingMessages = JSON.parse(localStorage.getItem(messagesKey) || '[]');
      
      const newMessage = {
        id: `msg_${Date.now()}`,
        senderName: address.slice(0, 10) + '...',
        senderAddress: address,
        receiverAddress: selectedCharacter.address,
        message: message.trim(),
        createdAt: new Date().toISOString(),
      };

      existingMessages.push(newMessage);
      localStorage.setItem(messagesKey, JSON.stringify(existingMessages));

      // Bakiye güncelle
      setUserBalance(prev => prev - MESSAGE_COST);

      alert(`✅ Mesajınız ${selectedCharacter.name}'ye gönderildi! ${MESSAGE_COST} XLM harcandı.`);
      setMessage('');
      setSelectedCharacter(null);
    } catch (error) {
      console.error('Mesaj gönderme hatası:', error);
      alert('❌ Mesaj gönderilemedi. Lütfen tekrar deneyin.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 relative overflow-hidden">
      {/* Arka Plan */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float-slow" />
      </div>

      {/* İçerik */}
      <div className="relative z-10 min-h-screen">
        {/* Başlık */}
        <div className="bg-gradient-to-r from-purple-900/50 to-indigo-900/50 backdrop-blur-sm border-b border-purple-500/30 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
            <h1 className="text-3xl font-bold text-white">💬 Karakterlere Mesaj Gönder</h1>
            <Link
              href="/profile"
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-semibold hover:opacity-90 transition"
            >
              Profil
            </Link>
          </div>
        </div>

        {/* Ana İçerik */}
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Karakter Seçim Paneli */}
            <div className="lg:col-span-1">
              <div className="sticky top-32">
                <div className="bg-gray-800/50 backdrop-blur-xl border border-purple-500/30 rounded-xl p-6">
                  <h2 className="text-xl font-bold text-white mb-4">👥 Karakter Seçin</h2>

                  {characters.length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-gray-300 font-semibold mb-2">Henüz karakter yok</p>
                      <p className="text-xs text-gray-500">Diğer karakterleri görmek için profile oluştur</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-xs text-gray-400 mb-3">👇 Mesaj göndermek istediğin karakteri seç:</p>
                      {characters.map((char) => (
                        <button
                          key={char.address}
                          onClick={() => setSelectedCharacter(char)}
                          className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                            selectedCharacter?.address === char.address
                              ? 'border-purple-400 bg-purple-600/30'
                              : 'border-gray-600/30 bg-gray-700/30 hover:border-purple-400/50'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            {char.image ? (
                              <img
                                src={char.image}
                                alt={char.name}
                                className="w-10 h-10 rounded-full object-cover"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                                ✨
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-white truncate">{char.name}</p>
                              <p className="text-xs text-gray-400">Lv {char.level}</p>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Mesaj Formu */}
            <div className="lg:col-span-2">
              <div className="bg-gray-800/50 backdrop-blur-xl border border-purple-500/30 rounded-xl p-6 space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-white mb-4">
                    {selectedCharacter ? `${selectedCharacter.name}'ye Mesaj Gönder` : '👥 Karakter Seçin'}
                  </h3>

                  {selectedCharacter ? (
                    <>
                      {/* Karakter Bilgisi */}
                      <div className="bg-purple-900/30 border border-purple-500/30 rounded-lg p-4 mb-4">
                        <div className="flex items-center gap-3 mb-3">
                          {selectedCharacter.image ? (
                            <img
                              src={selectedCharacter.image}
                              alt={selectedCharacter.name}
                              className="w-12 h-12 rounded-full object-cover"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-xl">
                              ✨
                            </div>
                          )}
                          <div>
                            <p className="font-semibold text-white">{selectedCharacter.name}</p>
                            <p className="text-sm text-purple-300">Seviye {selectedCharacter.level}</p>
                          </div>
                        </div>
                      </div>

                      {/* Mesaj Textarea */}
                      <label className="block text-sm font-semibold text-white mb-2">
                        Mesajınızı Yazın
                      </label>
                      <textarea
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Karaktere göndermek istediğiniz mesajı yazın..."
                        className="w-full p-4 bg-gray-900/50 border border-purple-500/30 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 resize-none h-32"
                      />

                      {/* Bedel Gösterimi */}
                      <div className="bg-purple-900/30 border border-purple-500/30 rounded-lg p-4 mt-4">
                        <div className="flex items-center justify-between">
                          <span className="text-white font-semibold">💰 Mesaj Bedeli:</span>
                          <span className="text-2xl font-bold text-yellow-400">50 XLM</span>
                        </div>
                        <p className="text-xs text-gray-400 mt-2">
                          Mevcut bakiye: <span className="text-green-400 font-semibold">{userBalance.toFixed(2)} XLM</span>
                        </p>
                      </div>

                      {/* Gönder Butonu */}
                      <button
                        onClick={handleSubmitMessage}
                        disabled={isSubmitting || !message.trim() || userBalance < 50}
                        className={`w-full mt-4 py-3 px-4 rounded-lg font-bold transition-all ${
                          isSubmitting || !message.trim() || userBalance < 50
                            ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                            : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white hover:scale-105'
                        }`}
                      >
                        {isSubmitting ? '⏳ Gönderiliyor...' : '✨ Mesajı Gönder'}
                      </button>
                    </>
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-2xl mb-2">👈</p>
                      <p className="text-gray-400">Lütfen soldan bir karakter seçin</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Bilgi */}
          <div className="mt-8 bg-gradient-to-br from-indigo-900/30 to-slate-900/30 rounded-2xl border border-indigo-500/30 p-6 max-w-2xl mx-auto">
            <p className="text-sm text-slate-300 space-y-2">
              <span className="block font-bold text-indigo-300 mb-2">ℹ️ Nasıl Çalışır?</span>
              <span className="block">
                • Seviye fark etmeksizin herhangi bir karaktere mesaj gönderebilirsin
              </span>
              <span className="block">
                • Her mesaj için 50 XLM harcarsın ve 15 EXP bonus kazanırsın
              </span>
              <span className="block">
                • Yüksek seviyeli karakterler düşük seviyeli karakterlere mesaj gönderebilir
              </span>
              <span className="block">
                • Düşük seviyeli karakterler yüksek seviyeli karakterlere mesaj gönderebilir
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ReadingPage() {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  if (!hydrated) return null;

  return <ReadingContent />;
}
