'use client';

import React, { useState } from 'react';
import { useFreighter } from './FreighterProvider';
import {
  requestWalletAccess,
  getWalletAddress,
  signMsg,
  recordTarotReadingOnChain,
  getTarotReadingHistory,
} from '@/lib/freighterUtils';

export default function FreighterTestPanel() {
  const { address, network, isConnected, networkUrl, sorobanRpcUrl } = useFreighter();
  const [testMessage, setTestMessage] = useState('Seç-İzle Tarot Test Mesajı');
  const [signedResult, setSignedResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleRequestAccess = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await requestWalletAccess();
      setSignedResult(`Başarılı: ${result}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Hata oluştu');
    }
    setLoading(false);
  };

  const handleGetAddress = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await getWalletAddress();
      setSignedResult(`Adres: ${result}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Hata oluştu');
    }
    setLoading(false);
  };

  const handleSignMessage = async () => {
    setLoading(true);
    setError(null);
    try {
      if (!address) throw new Error('Cüzdan bağlı değil');
      const result = await signMsg(testMessage, address);
      const resultStr = typeof result === 'string' ? result : String(result);
      setSignedResult(`İmzalanan Mesaj: ${resultStr.substring(0, 50)}...`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Hata oluştu');
    }
    setLoading(false);
  };

  const handleRecordReading = async () => {
    setLoading(true);
    setError(null);
    try {
      if (!address) throw new Error('Cüzdan bağlı değil');
      const result = await recordTarotReadingOnChain(
        address,
        'Güneş',
        'Başarı ve aydınlanma yaklaşıyor',
        Date.now()
      );
      setSignedResult(`Okuma Kaydedildi: ${JSON.stringify(result, null, 2)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Hata oluştu');
    }
    setLoading(false);
  };

  const handleGetHistory = () => {
    try {
      if (!address) throw new Error('Cüzdan bağlı değil');
      const history = getTarotReadingHistory(address);
      setSignedResult(`Geçmiş (${history.length} okuma):\n${JSON.stringify(history, null, 2)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Hata oluştu');
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-4 bg-gray-50 rounded-lg border border-gray-300">
      <h2 className="text-xl font-bold mb-4 text-gray-900">🧪 Freighter Test Panel</h2>

      {/* Durum */}
      <div className="mb-6 p-4 rounded bg-white border-l-4 border-blue-500">
        <h3 className="font-semibold mb-2 text-gray-800">📊 Durum</h3>
        <div className="space-y-2 text-sm">
          <p>
            <strong>Bağlı:</strong> <span className={isConnected ? 'text-green-600' : 'text-red-600'}>{isConnected ? '✅ Evet' : '❌ Hayır'}</span>
          </p>
          <p>
            <strong>Adres:</strong> <code className="text-xs bg-gray-200 px-1 rounded">{address ? `${address.slice(0, 10)}...` : 'Yok'}</code>
          </p>
          <p>
            <strong>Ağ:</strong> <span className="font-mono text-xs">{network || 'Bilinmiyor'}</span>
          </p>
          {sorobanRpcUrl && (
            <p>
              <strong>Soroban RPC:</strong> <span className="text-xs text-gray-600">{sorobanRpcUrl.substring(0, 40)}...</span>
            </p>
          )}
        </div>
      </div>

      {/* Test İşlemleri */}
      <div className="mb-6 space-y-3">
        <h3 className="font-semibold text-gray-800">🧬 Test İşlemleri</h3>

        <div className="space-y-2">
          <button
            onClick={handleRequestAccess}
            disabled={loading}
            className="w-full px-3 py-2 rounded bg-indigo-600 text-white text-sm hover:bg-indigo-700 disabled:opacity-50"
          >
            {loading ? 'Yükleniyor...' : '🔗 Cüzdan Erişimi İste'}
          </button>

          <button
            onClick={handleGetAddress}
            disabled={loading}
            className="w-full px-3 py-2 rounded bg-blue-600 text-white text-sm hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Yükleniyor...' : '📮 Adres Al'}
          </button>

          <div className="flex gap-2">
            <input
              type="text"
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              placeholder="İmzalanacak mesaj"
              className="flex-1 px-3 py-2 rounded border border-gray-300 text-sm"
            />
            <button
              onClick={handleSignMessage}
              disabled={loading || !isConnected}
              className="px-3 py-2 rounded bg-purple-600 text-white text-sm hover:bg-purple-700 disabled:opacity-50"
            >
              ✍️ İmzala
            </button>
          </div>

          <button
            onClick={handleRecordReading}
            disabled={loading || !isConnected}
            className="w-full px-3 py-2 rounded bg-green-600 text-white text-sm hover:bg-green-700 disabled:opacity-50"
          >
            {loading ? 'Kaydediliyor...' : '💾 Okuma Kayıt Et'}
          </button>

          <button
            onClick={handleGetHistory}
            disabled={!isConnected}
            className="w-full px-3 py-2 rounded bg-amber-600 text-white text-sm hover:bg-amber-700 disabled:opacity-50"
          >
            📜 Geçmişi Göster
          </button>
        </div>
      </div>

      {/* Hata Mesajı */}
      {error && (
        <div className="mb-4 p-3 rounded bg-red-50 border border-red-300 text-sm text-red-700">
          ⚠️ {error}
        </div>
      )}

      {/* Sonuç */}
      {signedResult && (
        <div className="p-4 rounded bg-green-50 border border-green-300">
          <h4 className="font-semibold text-green-900 mb-2">✅ Sonuç</h4>
          <pre className="text-xs bg-white p-2 rounded overflow-auto max-h-40 text-gray-700 whitespace-pre-wrap break-words">
            {signedResult}
          </pre>
        </div>
      )}
    </div>
  );
}
