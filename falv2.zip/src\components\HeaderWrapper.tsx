'use client';

import { useFreighter } from './FreighterProvider';

export default function HeaderWrapper() {
  const { isConnected, isLoading } = useFreighter();

  return (
    <header className="bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <h1 className="text-3xl font-bold">✨ Mistik Falcı</h1>
        <p className="text-purple-100 mt-1">Freighter ile Kozmik Enerji Deneyimi</p>
      </div>
    </header>
  );
}
