'use client';

import React, { useState } from 'react';

interface ZodiacSign {
  name: string;
  symbol: string;
  date: string;
  element: 'Ateş' | 'Toprak' | 'Hava' | 'Su';
  traits: string[];
  color: string;
}

const ZODIAC_SIGNS: ZodiacSign[] = [
  {
    name: 'Koç',
    symbol: '♈',
    date: '21 Mart - 19 Nisan',
    element: 'Ateş',
    traits: ['Cesur', 'Dinamik', 'Lider'],
    color: 'from-red-600 to-orange-500',
  },
  {
    name: 'Boğa',
    symbol: '♉',
    date: '20 Nisan - 20 Mayıs',
    element: 'Toprak',
    traits: ['Güvenilir', 'Sakin', 'Pratik'],
    color: 'from-green-600 to-emerald-500',
  },
  {
    name: 'İkizler',
    symbol: '♊',
    date: '21 Mayıs - 20 Haziran',
    element: 'Hava',
    traits: ['Meraklı', 'Akıcı', 'İletişimci'],
    color: 'from-yellow-500 to-amber-400',
  },
  {
    name: 'Yengeç',
    symbol: '♋',
    date: '21 Haziran - 22 Temmuz',
    element: 'Su',
    traits: ['Duygusal', 'Koruyucu', 'Sezgili'],
    color: 'from-blue-400 to-cyan-400',
  },
  {
    name: 'Aslan',
    symbol: '♌',
    date: '23 Temmuz - 22 Ağustos',
    element: 'Ateş',
    traits: ['Cömert', 'Gururlu', 'Karizmatik'],
    color: 'from-yellow-600 to-amber-500',
  },
  {
    name: 'Başak',
    symbol: '♍',
    date: '23 Ağustos - 22 Eylül',
    element: 'Toprak',
    traits: ['Analitik', 'Organize', 'Yardımsever'],
    color: 'from-green-500 to-teal-400',
  },
  {
    name: 'Terazi',
    symbol: '♎',
    date: '23 Eylül - 22 Ekim',
    element: 'Hava',
    traits: ['Dengeli', 'Sosyal', 'Adil'],
    color: 'from-pink-400 to-rose-400',
  },
  {
    name: 'Akrep',
    symbol: '♏',
    date: '23 Ekim - 21 Kasım',
    element: 'Su',
    traits: ['Güçlü', 'Gizemli', 'Tutkunlu'],
    color: 'from-purple-700 to-indigo-600',
  },
  {
    name: 'Yay',
    symbol: '♐',
    date: '22 Kasım - 21 Aralık',
    element: 'Ateş',
    traits: ['Maceraperest', 'Iyimser', 'Felsefeci'],
    color: 'from-blue-600 to-purple-500',
  },
  {
    name: 'Oğlak',
    symbol: '♑',
    date: '22 Aralık - 19 Ocak',
    element: 'Toprak',
    traits: ['Sorumlu', 'Sabırlı', 'Başarılı'],
    color: 'from-slate-600 to-gray-500',
  },
  {
    name: 'Kova',
    symbol: '♒',
    date: '20 Ocak - 18 Şubat',
    element: 'Hava',
    traits: ['Özgür', 'Vizyoner', 'Özdeğer'],
    color: 'from-cyan-500 to-blue-400',
  },
  {
    name: 'Balık',
    symbol: '♓',
    date: '19 Şubat - 20 Mart',
    element: 'Su',
    traits: ['Yaratıcı', 'Sempatik', 'Ruhsal'],
    color: 'from-teal-500 to-cyan-400',
  },
];

interface ZodiacSelectorProps {
  onSelect: (zodiac: ZodiacSign) => void;
}

export default function ZodiacSelector({ onSelect }: ZodiacSelectorProps) {
  const [selectedZodiac, setSelectedZodiac] = useState<ZodiacSign | null>(null);

  const handleSelect = (zodiac: ZodiacSign) => {
    setSelectedZodiac(zodiac);
    onSelect(zodiac);
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent mb-2">
          ✨ Burç Seçiniz ✨
        </h2>
        <p className="text-slate-300 text-lg">Kişiye özel falınız için burçunuzu seçin</p>
      </div>

      {/* Burç Grid */}
      <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-8">
        {ZODIAC_SIGNS.map((zodiac) => (
          <button
            key={zodiac.name}
            onClick={() => handleSelect(zodiac)}
            className={`group relative p-4 rounded-xl transition-all duration-300 transform hover:scale-110 ${
              selectedZodiac?.name === zodiac.name
                ? `bg-gradient-to-br ${zodiac.color} shadow-2xl ring-2 ring-white`
                : 'bg-slate-800 hover:bg-slate-700 border border-purple-500/30'
            }`}
          >
            <div className="relative z-10">
              <div className="text-3xl mb-1">{zodiac.symbol}</div>
              <div className="text-xs font-semibold text-center text-white group-hover:text-yellow-200">
                {zodiac.name}
              </div>
            </div>

            {/* Hover effect */}
            <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-yellow-400/0 to-yellow-400/0 group-hover:from-yellow-400/20 group-hover:to-yellow-400/10 transition-all" />
          </button>
        ))}
      </div>

      {/* Seçilen Burç Detayları */}
      {selectedZodiac && (
        <div className="bg-gradient-to-r from-purple-900/50 to-indigo-900/50 border border-purple-500/50 rounded-2xl p-6 backdrop-blur-sm animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Sol taraf - Sembol ve Ad */}
            <div className="flex flex-col items-center justify-center">
              <div className={`text-8xl mb-4 p-6 rounded-full bg-gradient-to-br ${selectedZodiac.color} opacity-80`}>
                {selectedZodiac.symbol}
              </div>
              <h3 className="text-3xl font-bold text-white mb-2">{selectedZodiac.name}</h3>
              <p className="text-yellow-300 font-semibold">{selectedZodiac.date}</p>
            </div>

            {/* Sağ taraf - Element ve Özellikler */}
            <div className="space-y-4">
              <div>
                <h4 className="text-sm uppercase tracking-widest text-purple-300 mb-2">Element</h4>
                <div className={`inline-block px-4 py-2 rounded-full bg-gradient-to-r ${selectedZodiac.color} text-white font-semibold`}>
                  {selectedZodiac.element} ♦
                </div>
              </div>

              <div>
                <h4 className="text-sm uppercase tracking-widest text-purple-300 mb-3">Karakteristikler</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedZodiac.traits.map((trait) => (
                    <span key={trait} className="px-3 py-1 bg-indigo-900/80 border border-indigo-400/50 rounded-full text-sm text-indigo-200">
                      {trait}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-purple-500/30">
                <p className="text-sm text-slate-300 italic">
                  {selectedZodiac.name} burcu, {selectedZodiac.element} elementinin güçlü enerjisini taşır.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
