'use client';

import { useFreighter } from './FreighterProvider';
import FreighterProfile from './FreighterProfile';

export default function HeaderClient() {
  const { isConnected, isLoading, address } = useFreighter();

  return (
    <header className="bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-6 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">✨ Mistik Falcı</h1>
          <p className="text-purple-100 mt-1">
            {isConnected && address ? `Hoşgeldiniz! ${address.slice(0, 6)}...${address.slice(-4)}` : 'Freighter ile Kozmik Enerji Deneyimi'}
          </p>
        </div>
        {isConnected && !isLoading && <FreighterProfile />}
      </div>
    </header>
  );
}
