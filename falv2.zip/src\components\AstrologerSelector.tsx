'use client';

import React, { useState } from 'react';
import { useAstrologer } from './AstrologerProvider';
import { useLevel } from './LevelProvider';
import { useFreighter } from './FreighterProvider';

const MysticTarotTheme = {
  colors: {
    primary: '#a78bfa',
    secondary: '#ec4899',
    accent: '#fbbf24',
    text: '#e0e7ff',
    dark: '#1e1b4b',
  },
};

interface AstrologerSelectorProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AstrologerSelector({ isOpen, onClose }: AstrologerSelectorProps) {
  const { astrologers, selectedAstrologer, selectAstrologer } = useAstrologer();
  const { userLevel } = useLevel();
  const { balance: freighterBalance } = useFreighter();
  const [selectedId, setSelectedId] = useState(selectedAstrologer?.id || '');

  const handleSelect = (id: string) => {
    const astrologer = astrologers.find(a => a.id === id);
    const cost = astrologer?.cost || 50;
    const xlmBalance = parseFloat(freighterBalance) || 0;

    // XLM balance kontrol et
    if (xlmBalance < cost) {
      alert(`❌ Yetersiz XLM! Gerekli: ${cost} XLM, Mevcut: ${xlmBalance.toFixed(4)} XLM`);
      return;
    }

    setSelectedId(id);
    selectAstrologer(id);
    setTimeout(() => onClose(), 300);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div
        className="bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 rounded-2xl border border-purple-500/30 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        style={{ boxShadow: '0 0 60px rgba(168, 85, 247, 0.3)' }}
      >
        {/* Başlık */}
        <div className="sticky top-0 bg-gradient-to-r from-purple-900 to-indigo-900 p-6 border-b border-purple-500/30">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold text-transparent bg-gradient-to-r from-yellow-300 to-pink-400 bg-clip-text">
                ✨ Falcı Seçin
              </h2>
              <p className="text-purple-300 text-sm mt-2">
                Falınızı almak için bir falcı seçin (Her okuma 0.05 XLM maliyeti vardır)
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-2xl text-purple-300 hover:text-pink-400 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Falcı Listesi */}
        <div className="p-6 space-y-3">
          {astrologers.map((astrologer) => {
            const isSelected = selectedId === astrologer.id;
            const xlmBalance = parseFloat(freighterBalance) || 0;
            const hasEnoughXLM = xlmBalance >= astrologer.cost;

            return (
              <button
                key={astrologer.id}
                onClick={() => handleSelect(astrologer.id)}
                disabled={!hasEnoughXLM}
                className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                  isSelected
                    ? 'border-pink-400 bg-pink-500/20'
                    : hasEnoughXLM
                    ? 'border-purple-500/30 hover:border-purple-400 bg-purple-900/20'
                    : 'border-slate-600/30 bg-slate-900/20 opacity-50 cursor-not-allowed'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-4xl">{astrologer.emoji}</span>
                      <div>
                        <h3 className="text-lg font-bold text-purple-200">
                          {astrologer.name}
                        </h3>
                        <p className="text-sm text-slate-300">
                          {astrologer.description}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-400">
                      ⭐ {astrologer.cost}
                    </div>
                    <div className="text-xs text-slate-400 mt-1">XLM</div>
                    {isSelected && (
                      <div className="text-xs text-pink-400 font-bold mt-1">
                        ✓ Seçildi
                      </div>
                    )}
                    {!hasEnoughXLM && (
                      <div className="text-xs text-red-400 font-bold mt-1">
                        ✕ Yetersiz XLM
                      </div>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-gradient-to-r from-slate-900 to-purple-900 p-6 border-t border-purple-500/30">
          <div className="flex justify-between items-center">
            <div className="text-sm text-purple-300">
              <p>Mevcut XLM: <span className="font-bold text-yellow-300">{freighterBalance ? parseFloat(freighterBalance).toFixed(4) : '0.0000'}</span></p>
            </div>
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gradient-to-r from-slate-700 to-slate-600 hover:from-slate-600 hover:to-slate-500 text-white rounded-lg transition-all"
            >
              Kapat
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
