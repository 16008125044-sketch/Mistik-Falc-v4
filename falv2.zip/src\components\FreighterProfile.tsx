'use client';

import { useFreighter } from './FreighterProvider';
import { useState, useEffect } from 'react';

export default function FreighterProfile() {
  const { address, network, isConnected, isLoading, disconnect, balance } = useFreighter();
  const [showDropdown, setShowDropdown] = useState(false);
  const [walletName, setWalletName] = useState('Freighter Cüzdan');
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(walletName);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // LocalStorage key'i cüzdan adresiyle eşleştir
  const getStorageKey = (suffix: string) => `freighter_${address}_${suffix}`;

  const handleLogout = () => {
    // Çıkış yapıldığında bilgi göster
    setIsLoggingOut(true);
    // Freighter'dan çıkış yap
    disconnect();
  };

  const handleSaveName = () => {
    if (tempName.trim()) {
      setWalletName(tempName);
      localStorage.setItem(getStorageKey('wallet_name'), tempName);
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setTempName(walletName);
    setIsEditing(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageData = event.target?.result as string;
        setProfileImage(imageData);
        localStorage.setItem(getStorageKey('profile_image'), imageData);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setProfileImage(null);
    localStorage.removeItem(getStorageKey('profile_image'));
  };

  // LocalStorage'dan kaydedilen adı ve fotoğrafı yükle
  useEffect(() => {
    const savedName = localStorage.getItem(getStorageKey('wallet_name'));
    if (savedName) {
      setWalletName(savedName);
      setTempName(savedName);
    }

    const savedImage = localStorage.getItem(getStorageKey('profile_image'));
    if (savedImage) {
      setProfileImage(savedImage);
    }
  }, [address]);

  if (isLoading) {
    return (
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 bg-white/20 rounded-full animate-pulse" />
      </div>
    );
  }

  if (!isConnected) {
    return (
      <div className="flex items-center gap-3 text-sm">
        <div className="h-3 w-3 rounded-full bg-red-400" />
      </div>
    );
  }

  return (
    <div className="relative flex items-center gap-4">
      {/* Profil Fotoğrafı */}
      <div className="relative">
        <button
          onClick={() => setShowDropdown(!showDropdown)}
          className="flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 hover:from-purple-500 hover:to-pink-500 transition-all border-2 border-white/30 overflow-hidden"
        >
          {profileImage ? (
            <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <span className="text-xl font-bold text-white">
              {address?.charAt(0).toUpperCase()}
            </span>
          )}
        </button>
        <div className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-400 animate-pulse border-2 border-white" />
      </div>

      {/* Aktiflik Durumu */}
      <div className="flex flex-col items-end gap-1">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-xs font-semibold text-white">Aktif</span>
        </div>
        <span className="text-xs text-purple-200">
          {network === 'public' ? 'Mainnet' : 'Testnet'}
        </span>
      </div>

      {/* Dropdown Menu */}
      {showDropdown && (
        <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-purple-500 rounded-lg shadow-xl z-50 top-full">
          <div className="p-4 space-y-4">
            {/* Profil Başlığı */}
            <div className="flex items-center gap-3 border-b border-purple-500/30 pb-3">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 overflow-hidden">
                {profileImage ? (
                  <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-lg font-bold text-white">
                    {address?.charAt(0).toUpperCase()}
                  </span>
                )}
              </div>
              <div className="flex-1">
                {isEditing ? (
                  <input
                    type="text"
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    className="w-full px-2 py-1 bg-purple-900/50 text-white rounded border border-purple-400 focus:outline-none focus:border-purple-300"
                    autoFocus
                  />
                ) : (
                  <p className="text-sm font-semibold text-white">{walletName}</p>
                )}
                <p className="text-xs text-purple-200">Bağlı</p>
              </div>
            </div>

            {/* Profil Fotoğrafı Düzenleme */}
            <div className="border-b border-purple-500/30 pb-3">
              <p className="text-xs text-purple-300 uppercase tracking-wider mb-2">Profil Fotoğrafı</p>
              <div className="flex gap-2">
                <label className="flex-1 px-3 py-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 hover:text-blue-200 rounded-lg transition-all border border-blue-500/30 font-medium text-sm cursor-pointer text-center">
                  📷 Değiştir
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
                {profileImage && (
                  <button
                    onClick={handleRemoveImage}
                    className="flex-1 px-3 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 hover:text-red-200 rounded-lg transition-all border border-red-500/30 font-medium text-sm"
                  >
                    🗑️ Kaldır
                  </button>
                )}
              </div>
            </div>

            {/* Cüzdan Adı Düzenleme */}
            <div className="border-b border-purple-500/30 pb-3">
              <p className="text-xs text-purple-300 uppercase tracking-wider mb-2">Cüzdan Adı</p>
              {isEditing ? (
                <div className="flex gap-2">
                  <button
                    onClick={handleSaveName}
                    className="flex-1 px-3 py-2 bg-green-500/20 hover:bg-green-500/30 text-green-300 hover:text-green-200 rounded-lg transition-all border border-green-500/30 font-medium text-sm"
                  >
                    ✓ Kaydet
                  </button>
                  <button
                    onClick={handleCancel}
                    className="flex-1 px-3 py-2 bg-gray-500/20 hover:bg-gray-500/30 text-gray-300 hover:text-gray-200 rounded-lg transition-all border border-gray-500/30 font-medium text-sm"
                  >
                    ✕ İptal
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="w-full px-3 py-2 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 hover:text-purple-200 rounded-lg transition-all border border-purple-500/30 font-medium text-sm"
                >
                  ✏️ Adı Değiştir
                </button>
              )}
            </div>

            {/* Bakiye Bilgisi */}
            <div className="border-b border-purple-500/30 pb-3">
              <p className="text-xs text-purple-300 uppercase tracking-wider mb-2">Bakiye</p>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-yellow-300">
                  {balance ? parseFloat(balance).toFixed(2) : '0.00'}
                </span>
                <span className="text-sm text-purple-200">XLM</span>
              </div>
              {balance === '0' && (
                <p className="text-xs text-yellow-500/70 mt-1">💡 Faucet'ten testnet XLM alabilirsin</p>
              )}
            </div>
            
            {/* Ağ Bilgisi */}
            <div className="border-b border-purple-500/30 pb-3">
              <p className="text-xs text-purple-300 uppercase tracking-wider mb-2">Ağ</p>
              <p className="text-sm text-white">
                {network === 'public' ? '🌍 Stellar Mainnet' : '🧪 Stellar Testnet'}
              </p>
            </div>

            {/* Durum */}
            <div className="border-b border-purple-500/30 pb-3">
              <p className="text-xs text-purple-300 uppercase tracking-wider mb-2">Durum</p>
              <div className="flex items-center gap-2">
                {isLoggingOut ? (
                  <>
                    <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-sm text-red-400">Çıkılıyor...</span>
                  </>
                ) : (
                  <>
                    <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
                    <span className="text-sm text-green-400">Bağlı</span>
                  </>
                )}
              </div>
            </div>

            {/* Çıkış Butonu */}
            <div className="border-t border-red-500/30 pt-3">
              <button
                onClick={handleLogout}
                disabled={isLoggingOut}
                className={`w-full px-4 py-3 rounded-lg transition-all transform font-bold text-sm uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 ${
                  isLoggingOut
                    ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
                    : 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white hover:scale-105'
                }`}
              >
                {isLoggingOut ? (
                  <>
                    <span className="animate-spin">⏳</span>
                    <span>Çıkılıyor...</span>
                  </>
                ) : (
                  <>
                    <span>🚪</span>
                    <span>Freighter'dan Çıkış Yap</span>
                  </>
                )}
              </button>
              <p className="text-xs text-red-400/70 text-center mt-2">Profil ve bakiye bilgileri silinecek</p>
            </div>
          </div>1) Smart Contract (Backend) — Soroban / Rust

Fal sitesi için aşağıdaki özelliklere sahip bir akıllı kontrat yaz:

🔮 Fonksiyonlar

requestFortune(user)

Kullanıcı fal isteği oluşturur.

Kullanıcıdan belirlenen miktarda token veya XLM çekilir.

İstek blockchain üzerinde kaydedilir (timestamp + user ID).

deliverFortune(user, fortuneText)

Admin/Falcı, kullanıcının fal yorumunu blokzincire yazar.

Fal metni zincir üzerinde değiştirilemez şekilde tutulur.

getFortune(user)

Kullanıcının aldığı son falı döndürür.

getHistory(user)

Kullanıcının geçmiş fal kayıtlarını listeler.

setPrice(amount)

Fal ücretini admin belirler.

🛡 Kurallar

Fal ödemesi yapılmadan request açılamaz.

Fortune sadece admin adres tarafından yazılabilir.

Veri yapıları:

User → Fal kayıtları listesi

User → Son fal

Fiyat, admin, toplam işlem sayısı

📦 Çıktı

Kontrat Rust + Soroban SDK ile yazılsın.

WASM dosyası çıkacak şekilde build ayarları yapılsın.

soroban-cli ile deploy komutları README’ye ekle.

2) Frontend (React + Freighter Wallet)

React tabanlı bir frontend oluştur:

🎨 UI Gereksinimleri

Connect Wallet butonu

“Fal Al” butonu → kontrattaki requestFortune() fonksiyonunu çalıştırır

“Falımı Gör” butonu → getFortune() fonksiyonunu çağırır

“Fal Geçmişim” → getHistory() çağrısı

Admin paneli:

Kullanıcının adresi girilip fal metni yazılacak alan

“Fal Gönder” → deliverFortune() çağrısı

🔌 Teknik Gereksinimler

Freighter ile kullanıcı bağlantısı:

Public key alma

Transaction imzalatma

@stellar/freighter-api

soroban-client ile kontrat çağrıları

📘 README İçeriği

Kontrat nasıl derlenir (WASM)

Test ağında nasıl deploy edilir

Frontend nasıl çalıştırılır

Freighter ile işlem nasıl imzalanır

3) Proje Dosya Yapısı
/contract
   └── Soroban akıllı kontrat (Rust)
/frontend
   └── React + Freighter UI
README.md

4) Ekstra İstek

Fal metinleri zincirde değiştirilemez şekilde saklansın.

Kullanıcı ücret ödemeden fal isteği oluşturamasın.

Admin harici kimse fal yükleyemesin.

UI sade, mistik temalı, koyu mod odaklı olsun.

Bu gereksinimlere uygun olarak tüm kodları, dosya yapısını ve konfigürasyonları üret.”
        </div>
      )}
    </div>
  );
}

