import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

// PUT /api/consultations/:id - Danışmaya cevap ver
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { answer } = body;

    if (!answer) {
      return NextResponse.json({ error: 'Cevap zorunlu' }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('consultations')
      .update({
        answer,
        status: 'answered',
        updated_at: new Date().toISOString()
      })
      .eq('id', params.id)
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    console.error('Cevap yazma hatası:', error);
    return NextResponse.json({ error: 'Cevap yazılamadı' }, { status: 500 });
  }
}
