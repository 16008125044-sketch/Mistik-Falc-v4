﻿'use client';

import React, { useState, useEffect } from 'react';
import { MysticTarotTheme } from './mystic_tarot_theme';
import { useLevel } from './LevelProvider';

const SAMPLE_CARDS: Card[] = [
  { id: 1, name: 'Güneş', short: 'Başarı, aydınlanma', long: 'Yakın zamanda bir aydınlanma yaşayacaksınız; hedeflerinizde ilerleme bekleyin.', rarity: 'normal', value: 1 },
  { id: 2, name: 'Ay', short: 'İçsel sezgi, belirsizlik', long: 'Sezgilerinize güvenin; görünmeyen bağlantılar bugün önem kazanacak.', rarity: 'normal', value: 1 },
  { id: 3, name: 'Kule', short: 'Değişim, şok', long: 'Beklenmedik bir değişim var - yıkımın ardından hızla yeniden inşa etme fırsatı gelecek.', rarity: 'normal', value: 1 },
  { id: 4, name: 'Aşıklar', short: 'Seçimler, yakınlık', long: 'Kalbiniz ve mantığınız arasında bir seçim sizi bekliyor; dürüst iletişim anahtar.', rarity: 'normal', value: 1 },
  { id: 5, name: 'Adalet', short: 'Denge, sonuç', long: 'Eylemlerinizin sonuçları netleşiyor; adil davranmak size avantaj sağlar.', rarity: 'normal', value: 1 },
  { id: 6, name: 'Şair', short: 'Yaratıcılık, ilham', long: 'Sanat ve yaratıcılık seni çağırıyor. Hayal gücünü serbest bırak ve yeni şeyler yarat.', rarity: 'normal', value: 1 },
  { id: 7, name: 'Erem', short: 'İç aydınlanma, bilgelik', long: 'Yalnızlığa ihtiyaç var. Sessizlikte kendini bul ve ruhun mesajını dinle.', rarity: 'normal', value: 1 },
  { id: 8, name: 'Macera', short: 'Yolculuk, keşif', long: 'Yeni maceralar ve keşifler kapıda. Bilinmeyene adım at ve korkularını aş.', rarity: 'normal', value: 1 },
  { id: 9, name: 'Değişim', short: 'Dönüşüm, gelişim', long: 'Büyük bir dönüşüm yaşıyorsun veya yaşayacaksın. Eskileri bırak, yeniye hoşgeldin de.', rarity: 'normal', value: 1 },
  { id: 10, name: 'Çakra', short: 'Daimî döngü, karma', long: 'Hayatın döngüsü seni yeniden başlangıca getiriyor. Tarihten ders al ve farklı hareket et.', rarity: 'normal', value: 1 },
  { id: 11, name: 'Gücü', short: 'İç kuvvet, kontrol', long: 'Hayatında gücü sendin. Korku ve şüphelerini alt et, kendi yaşamının sahibi ol.', rarity: 'normal', value: 1 },
  { id: 12, name: 'İçgüzelleme', short: 'Yavaşlık, adanmışlık', long: 'Hızı kesmek ve önemli şeylere bağlanmak zamanı. Sabırla ve imanla devam et.', rarity: 'normal', value: 1 },
  { id: 13, name: '⭐ Yıldız Karması', short: 'Efsanevi bereket, istediklerini çekme', long: '✨ EFSANEVI! Evrenden muazzam bir hediye geliyor! Tüm iyiliklerin kendini bulacak. Hayatın değişeceğini hisset. ✨', rarity: 'rare', value: 2 },
  { id: 14, name: '🔮 Kozmik Birlik', short: 'Efsanevi uyum, evrensel bağlantı', long: '✨ EFSANEVI! Senin ve evrenin vibrasyonları mükemmel uyum içinde. Her şey mümkün, sınırlar yok. Sonsuzluğu hisset. ✨', rarity: 'rare', value: 2 },
];

interface Card {
  id: number;
  name: string;
  short: string;
  long: string;
  rarity: 'normal' | 'rare';
  value: number;
}

interface CardWithUid extends Card {
  uid: string;
}

interface Reading {
  title: string;
  text: string;
}

export default function SecIzleTarot({ cardPool = SAMPLE_CARDS, animationSeconds = 10, isPremium = false }) {
  const { addReading, userLevel } = useLevel();
  const [deck, setDeck] = useState<CardWithUid[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [flipped, setFlipped] = useState(false);
  const [reading, setReading] = useState<Reading | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [dailyCard, setDailyCard] = useState<Card | null>(null);
  const [usesLeft, setUsesLeft] = useState(1);
  const [lastReset, setLastReset] = useState<string>('');

  useEffect(() => {
    // Günlük kartı ve kullanım hakkını kontrol et
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString().split('T')[0];
    
    const stored = localStorage.getItem('tarot_daily_date');
    const storedUses = localStorage.getItem('tarot_uses_left');
    
    if (stored !== todayStr) {
      // Yeni gün, kartı ve kullanım hakkını sıfırla
      const seed = today.getTime();
      const seededRandom = (index: number) => {
        const x = Math.sin(seed + index) * 10000;
        return x - Math.floor(x);
      };
      const randomCard = cardPool[Math.floor(seededRandom(1) * cardPool.length)];
      setDailyCard(randomCard);
      setUsesLeft(1);
      localStorage.setItem('tarot_daily_date', todayStr);
      localStorage.setItem('tarot_uses_left', '1');
    } else {
      // Aynı gün, kaydedilmiş kartı ve kullanım hakkını kullan
      const savedCard = localStorage.getItem('tarot_daily_card');
      if (savedCard) {
        setDailyCard(JSON.parse(savedCard));
      }
      const uses = storedUses ? parseInt(storedUses) : 1;
      setUsesLeft(uses);
    }
    
    setLastReset(todayStr);
    shuffleDeck();
  }, []);

  useEffect(() => {
    if (dailyCard) {
      localStorage.setItem('tarot_daily_card', JSON.stringify(dailyCard));
    }
  }, [dailyCard]);

  function getWeightedRandomCard(): Card {
    // Calculate rare card probability based on user level
    // Level 1-10: 15% rare (normal users) or 30% (premium)
    // Level 11-20: 20% rare or 40% (premium)
    // Level 21-30: 25% rare or 50% (premium)
    // Level 31-50: 30% rare or 60% (premium)
    // Level 50+: 40% rare or 70% (premium)
    
    const userLevel_val = userLevel?.level || 1;
    
    let baseRarePercentage = 0;
    if (userLevel_val >= 50) {
      baseRarePercentage = 0.40;  // 40% rare
    } else if (userLevel_val >= 31) {
      baseRarePercentage = 0.30;  // 30% rare
    } else if (userLevel_val >= 21) {
      baseRarePercentage = 0.25;  // 25% rare
    } else if (userLevel_val >= 11) {
      baseRarePercentage = 0.20;  // 20% rare
    } else {
      baseRarePercentage = 0.15;  // 15% rare
    }
    
    // Premium users get additional 15% boost to rare chance
    const rarePercentage = isPremium ? baseRarePercentage + 0.15 : baseRarePercentage;
    
    const rand = Math.random();
    const rareThreshold = 1 - rarePercentage; // Convert to threshold (lower = more rare)
    
    if (rand < rareThreshold) {
      // Normal kart seç
      const normalCards = cardPool.filter((c): c is Card => c.rarity === 'normal');
      return normalCards[Math.floor(Math.random() * normalCards.length)];
    } else {
      // Rare kart seç
      const rareCards = cardPool.filter((c): c is Card => c.rarity === 'rare');
      return rareCards[Math.floor(Math.random() * rareCards.length)];
    }
  }

  function shuffleDeck() {
    // 3 rastgele kart seç (ağırlıklı olasılıkla)
    const deckCards: Card[] = [];
    for (let i = 0; i < 3; i++) {
      deckCards.push(getWeightedRandomCard());
    }
    
    const expanded = deckCards.map((c) => {
      return { ...c, uid: `${c.id}-${Math.random().toString(36).slice(2, 9)}` };
    });
    
    setDeck(expanded);
    setSelected(null);
    setFlipped(false);
    setReading(null);
    setIsAnimating(false);
  }

  function drawCard(index: number) {
    if (isAnimating) return;
    if (usesLeft <= 0) return;
    
    setSelected(index);
    setFlipped(false);
    setReading(null);
    setIsAnimating(true);

    setTimeout(() => setFlipped(true), 400);

    setTimeout(() => {
      const card = deck[index];
      const mode = Math.random();
      let text = '';
      if (mode < 0.33) text = `Kısa: ${card.short}`;
      else if (mode < 0.66) text = `Ayrıntılı: ${card.long}`;
      else text = `Mesaj: ${card.name} seni uyarıyor - ${card.short.toLowerCase()}.`;

      setReading({ title: card.name, text });
      setIsAnimating(false);
      
      // Kullanım hakkını azalt
      const newUses = usesLeft - 1;
      setUsesLeft(newUses);
      localStorage.setItem('tarot_uses_left', newUses.toString());
      
      // EXP ekle (kart değerine göre çarpı)
      addReading(card.value);
    }, animationSeconds * 1000);
  }

  return (
    <div className="max-w-3xl mx-auto p-4 min-h-screen relative overflow-hidden" style={{ background: MysticTarotTheme.colors.background }}>
      <div className={MysticTarotTheme.effects.stars.className} style={MysticTarotTheme.effects.stars.style}></div>
      
      <h2 className="text-2xl font-bold mb-3" style={{ color: MysticTarotTheme.colors.text, fontFamily: MysticTarotTheme.fonts.heading }}>✨ Seç-İzle Tarot ✨</h2>
      
      {/* Günlük Bilgi */}
      <div className="mb-4 p-3 rounded-lg" style={{ background: 'rgba(107, 13, 173, 0.3)', borderLeft: `3px solid ${MysticTarotTheme.colors.primary}` }}>
        <div className="text-xs mb-2" style={{ color: MysticTarotTheme.colors.text }}>
          📅 Bugünün Kartı: <span style={{ color: MysticTarotTheme.colors.highlight }}>{dailyCard?.name || 'Yükleniyor...'}</span>
        </div>
        <div className="text-sm" style={{ color: usesLeft > 0 ? MysticTarotTheme.colors.text : '#ff6b6b' }}>
          🎯 Kalan Kullanım: <span style={{ fontWeight: 'bold' }}>{usesLeft}/1</span>
          {usesLeft === 0 && ' - Yarın yeniden deneyebilirsin!'}
        </div>
        <div className="text-xs mt-2" style={{ color: MysticTarotTheme.colors.highlight }}>
          💎 Ödül: {dailyCard?.value === 2 ? '⭐⭐ 0.02 XLM + 2x EXP (EFSANEVI!)' : '0.01 XLM + EXP'}
        </div>
      </div>

      <p className="mb-4 text-sm opacity-80" style={{ color: MysticTarotTheme.colors.text }}>Günlük kartını seç. (Günde 1 kez kullanabilirsin)</p>

      <div className="flex gap-3 justify-center mb-6">
        {deck.map((card, idx) => (
          <div 
            key={card.uid} 
            className="w-28 h-40"
            style={{ 
              perspective: '1000px',
              cursor: usesLeft > 0 ? 'pointer' : 'not-allowed',
              opacity: usesLeft > 0 ? 1 : 0.5
            }}
            onClick={() => drawCard(idx)}
          >
            <div 
              className={`relative w-full h-full transition-transform duration-700 ${MysticTarotTheme.animations.cardGlow}`}
              style={{
                transformStyle: 'preserve-3d',
                transform: flipped && selected === idx ? 'rotateY(180deg)' : 'rotateY(0deg)',
              }}
            >
              {/* Kartın Arka Tarafı */}
              <div 
                className="absolute inset-0 rounded-2xl shadow-lg flex items-center justify-center font-semibold"
                style={{ 
                  background: 'linear-gradient(135deg,#6A0DAD,#9B59B6)', 
                  color: MysticTarotTheme.colors.text,
                  backfaceVisibility: 'hidden',
                  WebkitBackfaceVisibility: 'hidden'
                }}
              >
                <div className="text-center px-2 text-sm">Kart<br/>Arka</div>
              </div>
              
              {/* Kartın Ön Tarafı */}
              <div 
                className="absolute inset-0 rounded-2xl shadow-lg flex flex-col items-center justify-center"
                style={{ 
                  padding: '8px', 
                  background: MysticTarotTheme.colors.primary, 
                  color: MysticTarotTheme.colors.highlight,
                  backfaceVisibility: 'hidden',
                  WebkitBackfaceVisibility: 'hidden',
                  transform: 'rotateY(180deg)',
                }}
              >
                <div className="text-sm font-bold text-center">{card.name}</div>
                <div className="text-xs opacity-70 mt-2 text-center px-2">{card.short}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center gap-4 mb-6">
        <button onClick={shuffleDeck} className="px-4 py-2 rounded-lg shadow hover:opacity-90" style={{ background: MysticTarotTheme.colors.primary, color: MysticTarotTheme.colors.text }}>
          Yeniden Karıştır
        </button>
        <button onClick={() => { if (selected !== null) drawCard(selected); }} className="px-4 py-2 rounded-lg shadow hover:opacity-90" style={{ background: MysticTarotTheme.colors.highlight, color: 'black' }}>
          Tekrar Göster
        </button>
      </div>

      <div className="min-h-[120px] rounded-md p-4 shadow-inner" style={{ background: MysticTarotTheme.colors.secondary, color: MysticTarotTheme.colors.text }}>
        {reading ? (
          <div>
            <h3 className="text-lg font-semibold mb-2">{reading.title}</h3>
            <p className="text-sm leading-6">{reading.text}</p>
            <div className="mt-3 text-xs opacity-70">Not: Bu yorum eğlence amaçlıdır.</div>
          </div>
        ) : (
          <div className="text-sm opacity-70">Bir kart seçip gösterimi izleyin.</div>
        )}
      </div>

      <style jsx>{`
        /* Perspective styles removed - using inline styles instead */
      `}</style>
    </div>
  );
}
