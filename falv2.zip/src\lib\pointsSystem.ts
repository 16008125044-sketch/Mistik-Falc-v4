// Seviye Sistemi ve Puanlama Yapısı

export interface UserLevel {
  level: number; // 1-10
  currentExp: number;
  totalExp: number;
  title: string;
  rewards: {
    moonlight: number; // Ay ışığı puanı
    star: number; // Yıldız puanı
    xlm: number; // XLM (Stellar)
  };
  unlockedDecks: string[];
  unlockedThemes: string[];
  unlockedCategories: string[];
}

export interface RewardType {
  type: 'moonlight' | 'star' | 'xlm';
  amount: number;
  icon: string;
  color: string;
  label: string;
}

// Seviye başına gerekli EXP
const EXP_PER_LEVEL = [
  100,  // Level 1 → 2
  200,  // Level 2 → 3
  300,  // Level 3 → 4
  450,  // Level 4 → 5
  600,  // Level 5 → 6
  800,  // Level 6 → 7
  1000, // Level 7 → 8
  1300, // Level 8 → 9
  1600, // Level 9 → 10
  2000, // Level 10 max
];

// Seviye başına verilen ödüller
const LEVEL_REWARDS: Record<number, RewardType[]> = {
  1: [
    { type: 'moonlight', amount: 10, icon: '🌙', color: '#e0e0e0', label: 'Ay Işığı' }
  ],
  2: [
    { type: 'moonlight', amount: 25, icon: '🌙', color: '#e0e0e0', label: 'Ay Işığı' },
    { type: 'star', amount: 5, icon: '⭐', color: '#fbbf24', label: 'Yıldız' }
  ],
  3: [
    { type: 'moonlight', amount: 40, icon: '🌙', color: '#e0e0e0', label: 'Ay Işığı' },
    { type: 'star', amount: 15, icon: '⭐', color: '#fbbf24', label: 'Yıldız' }
  ],
  4: [
    { type: 'star', amount: 30, icon: '⭐', color: '#fbbf24', label: 'Yıldız' },
    { type: 'xlm', amount: 3, icon: '⭐', color: '#fbbf24', label: 'XLM' }
  ],
  5: [
    { type: 'moonlight', amount: 60, icon: '🌙', color: '#e0e0e0', label: 'Ay Işığı' },
    { type: 'star', amount: 50, icon: '⭐', color: '#fbbf24', label: 'Yıldız' },
    { type: 'xlm', amount: 5, icon: '⭐', color: '#fbbf24', label: 'XLM' }
  ],
  6: [
    { type: 'star', amount: 75, icon: '⭐', color: '#fbbf24', label: 'Yıldız' },
    { type: 'xlm', amount: 8, icon: '⭐', color: '#fbbf24', label: 'XLM' }
  ],
  7: [
    { type: 'moonlight', amount: 100, icon: '🌙', color: '#e0e0e0', label: 'Ay Işığı' },
    { type: 'star', amount: 100, icon: '⭐', color: '#fbbf24', label: 'Yıldız' },
    { type: 'xlm', amount: 12, icon: '⭐', color: '#fbbf24', label: 'XLM' }
  ],
  8: [
    { type: 'star', amount: 150, icon: '⭐', color: '#fbbf24', label: 'Yıldız' },
    { type: 'xlm', amount: 20, icon: '⭐', color: '#fbbf24', label: 'XLM' }
  ],
  9: [
    { type: 'moonlight', amount: 150, icon: '🌙', color: '#e0e0e0', label: 'Ay Işığı' },
    { type: 'star', amount: 200, icon: '⭐', color: '#fbbf24', label: 'Yıldız' },
    { type: 'xlm', amount: 30, icon: '⭐', color: '#fbbf24', label: 'XLM' }
  ],
  10: [
    { type: 'moonlight', amount: 200, icon: '🌙', color: '#e0e0e0', label: 'Ay Işığı' },
    { type: 'star', amount: 300, icon: '⭐', color: '#fbbf24', label: 'Yıldız' },
    { type: 'xlm', amount: 50, icon: '⭐', color: '#fbbf24', label: 'XLM' }
  ]
};

// Seviye başına başlık
const LEVEL_TITLES: Record<number, string> = {
  1: 'Yeni Talib',
  2: 'Başlangıç Medyumu',
  3: 'Aydın Gözlü',
  4: 'Kristal Temizleyici',
  5: 'Ay Kütüphanecisi',
  6: 'Yıldız Danışmanı',
  7: 'Estetik Falcı',
  8: 'Mistik Hakkim',
  9: 'Kader Ustası',
  10: 'En Büyük Falcı'
};

// Seviye başına açılan yeni desteler
const DECK_UNLOCKS: Record<number, string[]> = {
  1: ['Klasik Tarot'],
  2: ['Rider-Waite'],
  3: ['Thoth Destesi'],
  4: ['Oracle Kartları'],
  5: ['Lenormand'],
  6: ['Kıbrıs Fotoğrafları'],
  7: ['Chakra Falcılığı'],
  8: ['Astral Projeksiyon'],
  9: ['Evren Bilgeliği'],
  10: ['Kozmik Destesi']
};

// Seviye başına açılan temalar
const THEME_UNLOCKS: Record<number, string[]> = {
  1: ['Klasik Koyu'],
  2: ['Ay Nuru'],
  3: ['Yıldız Işılı'],
  4: ['Kristal Fantezi'],
  5: ['Mistik Mor'],
  6: ['Gece Gökyüzü'],
  7: ['Kozmik Mavileri'],
  8: ['Büyü Karası'],
  9: ['Ruhsal Altın'],
  10: ['Sonsuz Evren']
};

// Seviye başına açılan kategoriler
const CATEGORY_UNLOCKS: Record<number, string[]> = {
  1: ['Günlük Fal'],
  2: ['Aşk Falcılığı'],
  3: ['Kariyer Danışması'],
  4: ['Sağlık Fırsat'],
  5: ['Finans Rehberi'],
  6: ['Ruhsal Gelişim'],
  7: ['Kader Analizi'],
  8: ['Gizli Bilgelik'],
  9: ['Kozmik Sürü'],
  10: ['Üstün Bilgi']
};

// Fal çekildiğinde EXP kazanç
export const EXP_REWARD_PER_READING = 25;

// Kullanıcı seviyesini hesapla
export function getCurrentLevel(totalExp: number): { level: number; currentExp: number; nextLevelExp: number } {
  let level = 1;
  let remainingExp = totalExp;

  for (let i = 0; i < EXP_PER_LEVEL.length; i++) {
    if (remainingExp >= EXP_PER_LEVEL[i]) {
      remainingExp -= EXP_PER_LEVEL[i];
      level++;
    } else {
      break;
    }
  }

  const nextLevelExp = EXP_PER_LEVEL[Math.min(level - 1, EXP_PER_LEVEL.length - 1)] || 0;
  return { level: Math.min(level, 10), currentExp: remainingExp, nextLevelExp };
}

// Seviye ödüllerini al
export function getLevelRewards(level: number): RewardType[] {
  return LEVEL_REWARDS[Math.min(level, 10)] || [];
}

// Seviye başlığı
export function getLevelTitle(level: number): string {
  return LEVEL_TITLES[Math.min(level, 10)] || 'Yeni Talib';
}

// Açılan desteler
export function getUnlockedDecks(level: number): string[] {
  const decks: string[] = [];
  for (let i = 1; i <= Math.min(level, 10); i++) {
    decks.push(...DECK_UNLOCKS[i]);
  }
  return decks;
}

// Açılan temalar
export function getUnlockedThemes(level: number): string[] {
  const themes: string[] = [];
  for (let i = 1; i <= Math.min(level, 10); i++) {
    themes.push(...THEME_UNLOCKS[i]);
  }
  return themes;
}

// Açılan kategoriler
export function getUnlockedCategories(level: number): string[] {
  const categories: string[] = [];
  for (let i = 1; i <= Math.min(level, 10); i++) {
    categories.push(...CATEGORY_UNLOCKS[i]);
  }
  return categories;
}

// Başlangıç profili
export function createInitialUserLevel(): UserLevel {
  return {
    level: 1,
    currentExp: 0,
    totalExp: 0,
    title: 'Yeni Talib',
    rewards: { moonlight: 10, star: 0, xlm: 0 },
    unlockedDecks: DECK_UNLOCKS[1],
    unlockedThemes: THEME_UNLOCKS[1],
    unlockedCategories: CATEGORY_UNLOCKS[1]
  };
}

// EXP ekle ve seviye kontrol et
export function addExpAndCheckLevelUp(userLevel: UserLevel, expToAdd: number): { 
  newUserLevel: UserLevel; 
  leveledUp: boolean; 
  newLevel: number;
  rewards: RewardType[];
} {
  const newTotalExp = userLevel.totalExp + expToAdd;
  const { level, currentExp, nextLevelExp } = getCurrentLevel(newTotalExp);

  let leveledUp = false;
  let rewards: RewardType[] = [];

  if (level > userLevel.level) {
    leveledUp = true;
    rewards = getLevelRewards(level);
  }

  const newRewards = { ...userLevel.rewards };
  rewards.forEach(reward => {
    if (reward.type === 'moonlight') newRewards.moonlight += reward.amount;
    if (reward.type === 'star') newRewards.star += reward.amount;
    if (reward.type === 'xlm') newRewards.xlm += reward.amount;
  });

  const newUserLevel: UserLevel = {
    level,
    currentExp,
    totalExp: newTotalExp,
    title: getLevelTitle(level),
    rewards: newRewards,
    unlockedDecks: getUnlockedDecks(level),
    unlockedThemes: getUnlockedThemes(level),
    unlockedCategories: getUnlockedCategories(level)
  };

  return { newUserLevel, leveledUp, newLevel: level, rewards };
}
