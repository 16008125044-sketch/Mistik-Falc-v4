'use client';

import Link from 'next/link';
import { useFreighter } from '@/components/FreighterProvider';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

export default function Home() {
  const { isConnected, isLoading, error, connect, address } = useFreighter();
  const [hydrated, setHydrated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  useEffect(() => {
    checkAdmin();
  }, [address]);

  const checkAdmin = async () => {
    if (!address) {
      setIsAdmin(false);
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from('admins')
        .select('*')
        .eq('wallet_address', address);

      if (error) throw error;

      if (data && data.length > 0) {
        setIsAdmin(true);
      } else {
        setIsAdmin(false);
      }
    } catch (err) {
      console.error('Admin check hatası:', err);
      setIsAdmin(false);
    }
  };

  const handleConnect = async () => {
    try {
      await connect();
    } catch (err) {
      console.error('Bağlantı hatası:', err);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <div className="h-12 w-12 border-4 border-purple-400 border-t-pink-400 rounded-full mx-auto" />
          </div>
          <p className="text-purple-300 text-lg">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 relative overflow-hidden">
        {/* Arka Plan Elementleri */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float-slow" />
        </div>

        {/* İçerik */}
        <div className="relative z-10 min-h-screen flex items-center justify-center px-4">
          <div className="text-center max-w-2xl space-y-8">
            {/* Başlık */}
            <div className="space-y-4">
              <h1 className="text-6xl md:text-7xl font-bold text-transparent bg-gradient-to-r from-yellow-300 via-purple-400 to-pink-400 bg-clip-text animate-pulse">
                ✨ MİSTİK FALCI ✨
              </h1>
              <p className="text-2xl text-purple-200">
                Yıldızlar, Burçlar ve Tarot Kartları Seni Çağırıyor
              </p>
            </div>

            {/* Hata Mesajı */}
            {error && (
              <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 text-red-300">
                <p className="text-sm">{error}</p>
                <p className="text-xs mt-2">Lütfen Freighter cüzdanını yükleyin veya kurun.</p>
              </div>
            )}

            {/* Açıklama */}
            <div className="space-y-4 text-lg text-slate-300">
              <p>
                🌙 Kozmik enerjiyle bağlantı kur
              </p>
              <p>
                ☀️ Günün falını keşfet
              </p>
              <p>
                ♈ Burçunun mesajını dinle
              </p>
              <p>
                🃏 Tarot kartlarının rehberliğinde yol al
              </p>
            </div>

            {/* Buton */}
            <div className="pt-8">
              <div className="text-center">
                <p className="text-purple-300 mb-4">Devam etmek için Freighter cüzdanı bağlayın</p>
                <div className="bg-purple-900/30 border border-purple-500/50 rounded-lg p-6 space-y-4">
                  <p className="text-sm text-purple-200">
                    📱 Freighter Chrome uzantısını kurun veya mobil uygulamayı açın
                  </p>
                  <button
                    onClick={handleConnect}
                    className="inline-block px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg"
                  >
                    🔐 Freighter Bağla
                  </button>
                  <p className="text-xs text-slate-400 pt-2">veya</p>
                  <a
                    href="https://www.freighter.app/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block px-8 py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-xl text-lg transition-all"
                  >
                    Freighter Kur
                  </a>
                </div>
              </div>
            </div>

            <div className="pt-8 text-sm text-slate-400 italic">
              ✨ Bu deneyim eğlence amaçlıdır. Önemli kararlar için profesyonel tavsiye alınız. ✨
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!hydrated) return null;

  // Giriş yapıldıysa, ana sayfayı göster
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 relative overflow-hidden">
      {/* Arka Plan Elementleri */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float-slow" />
      </div>

      {/* İçerik */}
      <div className="relative z-10 min-h-screen flex items-center justify-center px-4">
        <div className="text-center max-w-2xl space-y-8">
          {/* Başlık */}
          <div className="space-y-4">
            <h1 className="text-6xl md:text-7xl font-bold text-transparent bg-gradient-to-r from-yellow-300 via-purple-400 to-pink-400 bg-clip-text animate-pulse">
              ✨ MİSTİK FALCI ✨
            </h1>
            <p className="text-2xl text-purple-200">
              Yıldızlar, Burçlar ve Tarot Kartları Seni Çağırıyor
            </p>
          </div>

          {/* Açıklama */}
          <div className="space-y-4 text-lg text-slate-300">
            <p>
              🌙 Kozmik enerjiyle bağlantı kur
            </p>
            <p>
              ☀️ Günün falını keşfet
            </p>
            <p>
              ♈ Burçunun mesajını dinle
            </p>
            <p>
              🃏 Tarot kartlarının rehberliğinde yol al
            </p>
          </div>

          {/* Butonlar */}
          <div className="flex flex-col gap-4 justify-center pt-8">
            <Link
              href="/mystic"
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg"
            >
              🔮 Mistik Falcıya Gir
            </Link>
            <Link
              href="/witch-consultation"
              className="px-8 py-4 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white font-bold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg"
            >
              🧙‍♀️ Cadı Danışması
            </Link>
            {isAdmin && (
              <Link
                href="/admin/profile"
                className="px-8 py-4 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white font-bold rounded-xl text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                👨‍💼 Admin Panel
              </Link>
            )}
          </div>

          {/* Alt Metin */}
          <div className="pt-8 text-sm text-slate-400 italic">
            ✨ Bu deneyim eğlence amaçlıdır. Önemli kararlar için profesyonel tavsiye alınız. ✨
          </div>
        </div>
      </div>
    </div>
  );
}