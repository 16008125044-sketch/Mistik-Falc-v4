'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { useFreighter } from './FreighterProvider';
import type { UserLevel, RewardType } from '@/lib/pointsSystem';
import { 
  createInitialUserLevel, 
  addExpAndCheckLevelUp,
  EXP_REWARD_PER_READING,
  getCurrentLevel,
  getLevelTitle
} from '@/lib/pointsSystem';

interface LevelContextType {
  userLevel: UserLevel | null;
  isLoading: boolean;
  addReading: (multiplier?: number) => Promise<void>;
  addCustomExp: (exp: number) => Promise<void>;
  spendPoints: (type: 'moonlight' | 'star' | 'xlm', amount: number) => Promise<void>;
  addPoints: (type: 'xlm' | 'exp' | 'moonlight' | 'star' | 'crystal', amount: number) => Promise<void>;
}

const LevelContext = createContext<LevelContextType | undefined>(undefined);

export function LevelProvider({ children }: { children: React.ReactNode }) {
  const { address, balance: freighterBalance } = useFreighter();
  const [userLevel, setUserLevel] = useState<UserLevel | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const storageKey = (addr: string, field: string) => `level_${addr}_${field}`;

  // Seviye verilerini yükle
  useEffect(() => {
    if (!address) {
      setUserLevel(null);
      return;
    }

    setIsLoading(true);
    
    // Yeni format: level_{address} (tek bir JSON object)
    const newFormatKey = `level_${address}`;
    const newFormatData = localStorage.getItem(newFormatKey);
    
    // Eski format: level_{address}_{field} (ayrı ayrı fields)
    const oldFormatExp = localStorage.getItem(storageKey(address, 'totalExp'));
    const oldFormatMoonlight = localStorage.getItem(storageKey(address, 'moonlight'));
    const oldFormatStar = localStorage.getItem(storageKey(address, 'star'));
    const oldFormatCrystal = localStorage.getItem(storageKey(address, 'crystal'));

    let totalExp = 0;
    let moonlight = 10;
    let star = 0;
    let xlm = 0;

    // Yeni format varsa, onu kullan (localStorage'daki değer kalıcıdır)
    if (newFormatData) {
      try {
        const parsed = JSON.parse(newFormatData);
        totalExp = parsed.totalExp || 0;
        moonlight = parsed.rewards?.moonlight || 10;
        star = parsed.rewards?.star || 0;
        xlm = parsed.rewards?.xlm || 0; // localStorage'daki XLM'i KOR
      } catch (e) {
        console.error('Yeni format parse hatası:', e);
        xlm = parseFloat(freighterBalance) || 0;
      }
    } else if (oldFormatExp || oldFormatMoonlight || oldFormatStar || oldFormatCrystal) {
      // Eski format varsa, onu kullan
      totalExp = parseInt(oldFormatExp || '0', 10);
      moonlight = parseInt(oldFormatMoonlight || '10', 10);
      star = parseInt(oldFormatStar || '0', 10);
      xlm = parseFloat(freighterBalance) || 0; // İlk kez Freighter'dan al
      
      // Eski formatı yeni formata migre et
      const migratedData = {
        level: getCurrentLevel(totalExp).level,
        currentExp: getCurrentLevel(totalExp).currentExp,
        totalExp,
        title: getLevelTitle(getCurrentLevel(totalExp).level),
        rewards: { moonlight, star, xlm },
        unlockedDecks: [],
        unlockedThemes: [],
        unlockedCategories: []
      };
      localStorage.setItem(newFormatKey, JSON.stringify(migratedData));
      
      // Eski format verisini temizle
      localStorage.removeItem(storageKey(address, 'totalExp'));
      localStorage.removeItem(storageKey(address, 'moonlight'));
      localStorage.removeItem(storageKey(address, 'star'));
      localStorage.removeItem(storageKey(address, 'crystal'));
    } else {
      // Hiçbir veri yoksa, Freighter'dan alınan balansı ilk kez kaydet
      xlm = parseFloat(freighterBalance) || 0;
      
      // İlk veriyi kaydet
      const initialData = {
        level: getCurrentLevel(0).level,
        currentExp: getCurrentLevel(0).currentExp,
        totalExp: 0,
        title: getLevelTitle(getCurrentLevel(0).level),
        rewards: { moonlight, star, xlm },
        unlockedDecks: [],
        unlockedThemes: [],
        unlockedCategories: []
      };
      localStorage.setItem(newFormatKey, JSON.stringify(initialData));
    }

    const { level, currentExp, nextLevelExp } = getCurrentLevel(totalExp);

    const newUserLevel: UserLevel = {
      level,
      currentExp,
      totalExp,
      title: getLevelTitle(level),
      rewards: {
        moonlight,
        star,
        xlm
      },
      unlockedDecks: [],
      unlockedThemes: [],
      unlockedCategories: []
    };

    setUserLevel(newUserLevel);
    setIsLoading(false);
  }, [address]);

  // Freighter bakiyesini sadece bir kez yükle (otomatik refresh yok)
  useEffect(() => {
    if (!address || !userLevel) return;

    const syncFreighterBalance = () => {
      const freighterXLM = parseFloat(freighterBalance) || 0;
      
      // Eğer Freighter bakiyesi localStorage'dakinden farklıysa, güncelle
      if (Math.abs(freighterXLM - userLevel.rewards.xlm) > 0.0001) {
        console.log(`💰 Freighter senkronizasyonu: ${userLevel.rewards.xlm} → ${freighterXLM} XLM`);
        
        const newFormatKey = `level_${address}`;
        const updated = {
          ...userLevel,
          rewards: {
            ...userLevel.rewards,
            xlm: freighterXLM
          }
        };
        
        localStorage.setItem(newFormatKey, JSON.stringify(updated));
        setUserLevel(updated);
      }
    };

    // Sadece ilk senkronizasyon (otomatik refresh kaldırıldı)
    syncFreighterBalance();
  }, [address, freighterBalance, userLevel]);

  const addReading = async (multiplier: number = 1) => {
    if (!userLevel || !address) return;

    const { newUserLevel, leveledUp, rewards } = addExpAndCheckLevelUp(
      userLevel,
      EXP_REWARD_PER_READING * multiplier
    );

    // XLM reward ekle (Freighter balance'dan kontrol edilir)
    const updatedUserLevel = {
      ...newUserLevel
    };

    // Yeni format: level_{address} (tek bir JSON object)
    const newFormatKey = `level_${address}`;
    localStorage.setItem(newFormatKey, JSON.stringify(updatedUserLevel));

    // Seviye animasyonu için geçici bir flag ekle
    if (leveledUp) {
      localStorage.setItem(`level_${address}_levelUpNotification`, JSON.stringify({
        newLevel: updatedUserLevel.level,
        rewards: rewards,
        timestamp: Date.now()
      }));
    }

    setUserLevel(updatedUserLevel);
  };

  const addCustomExp = async (exp: number) => {
    if (!userLevel || !address) return;

    const { newUserLevel, leveledUp, rewards } = addExpAndCheckLevelUp(userLevel, exp);

    const newFormatKey = `level_${address}`;
    localStorage.setItem(newFormatKey, JSON.stringify(newUserLevel));

    if (leveledUp) {
      localStorage.setItem(`level_${address}_levelUpNotification`, JSON.stringify({
        newLevel: newUserLevel.level,
        rewards: rewards,
        timestamp: Date.now()
      }));
    }

    setUserLevel(newUserLevel);
  };

  const spendPoints = async (type: 'moonlight' | 'star' | 'xlm', amount: number) => {
    if (!userLevel || !address) return;

    if (userLevel.rewards[type] < amount) {
      throw new Error(`Yeterli ${type} puanı yok`);
    }

    const newRewards = { ...userLevel.rewards };
    newRewards[type] -= amount;

    const updated: UserLevel = { ...userLevel, rewards: newRewards };
    
    const newFormatKey = `level_${address}`;
    // Her harcanma işlemini kaydet - böylece sayfa yenilense de kaybolmaz
    localStorage.setItem(newFormatKey, JSON.stringify(updated));
    
    setUserLevel(updated);
  };

  const addPoints = async (type: 'xlm' | 'exp' | 'moonlight' | 'star' | 'crystal', amount: number) => {
    if (!userLevel || !address) return;

    let updated: UserLevel;

    if (type === 'exp') {
      // EXP için special handling - level up control
      const { newUserLevel, leveledUp, newLevel, rewards } = addExpAndCheckLevelUp(userLevel, amount);
      
      updated = newUserLevel;

      if (leveledUp) {
        localStorage.setItem(`level_${address}_levelUpNotification`, JSON.stringify({
          newLevel,
          rewards,
          timestamp: Date.now()
        }));
      }
    } else if (type === 'crystal') {
      // Crystal hesaplanmıyor, direkt ekleme
      const newRewards = { ...userLevel.rewards };
      // @ts-ignore - crystal rewards'te yok ama type'da var
      newRewards['crystal'] = ((newRewards as any)['crystal'] || 0) + amount;
      
      updated = { ...userLevel, rewards: newRewards };
    } else {
      // Diğer reward türleri için direkt ekleme (moonlight, star, xlm)
      const newRewards = { ...userLevel.rewards };
      newRewards[type as keyof typeof newRewards] = (newRewards[type as keyof typeof newRewards] || 0) + amount;
      
      updated = { ...userLevel, rewards: newRewards };
    }

    const newFormatKey = `level_${address}`;
    localStorage.setItem(newFormatKey, JSON.stringify(updated));
    setUserLevel(updated);
  };

  return (
    <LevelContext.Provider value={{ userLevel, isLoading, addReading, addCustomExp, spendPoints, addPoints }}>
      {children}
    </LevelContext.Provider>
  );
}

export function useLevel() {
  const context = useContext(LevelContext);
  if (!context) {
    throw new Error('useLevel must be used within LevelProvider');
  }
  return context;
}
