'use server';

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_ROLE_KEY || ''
);

export async function addAdmin(walletAddress: string, name: string) {
  try {
    const { data, error } = await supabase
      .from('admins')
      .insert([
        {
          wallet_address: walletAddress,
          name: name,
          role: 'admin'
        }
      ])
      .select();

    if (error) {
      console.error('Supabase hata:', error);
      throw new Error(error.message);
    }

    return { success: true, data };
  } catch (err) {
    console.error('Admin eklenirken hata:', err);
    return { success: false, error: err instanceof Error ? err.message : 'Bilinmeyen hata' };
  }
}
