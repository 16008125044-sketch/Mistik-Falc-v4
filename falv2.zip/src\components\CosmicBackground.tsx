'use client';

import React, { useState, useEffect } from 'react';

interface StarFieldProps {
  count?: number;
}

export default function CosmicBackground({ count = 100 }) {
  const [stars, setStars] = useState<Array<{ x: number; y: number; size: number; opacity: number; duration: number }> | null>(null);
  const [microStars, setMicroStars] = useState<Array<{ x: number; y: number; opacity: number; duration: number }> | null>(null);

  useEffect(() => {
    const generatedStars = Array.from({ length: count }).map(() => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 0.5,
      opacity: Math.random() * 0.7 + 0.3,
      duration: Math.random() * 3 + 2,
    }));
    setStars(generatedStars);

    const generatedMicroStars = Array.from({ length: 200 }).map(() => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      opacity: Math.random() * 0.5 + 0.2,
      duration: Math.random() * 4 + 2,
    }));
    setMicroStars(generatedMicroStars);
  }, [count]);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {/* Arka Plan Gradient - Galaksi */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950" />

      {/* Nebulalar */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float-slow" />
      <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-indigo-600 rounded-full mix-blend-multiply filter blur-3xl opacity-15" />

      {/* Yıldızlar */}
      {stars && stars.map((star, idx) => (
        <div
          key={idx}
          className="absolute rounded-full animate-twinkle"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            backgroundColor: 'white',
            opacity: star.opacity,
            animationDuration: `${star.duration}s`,
            boxShadow: `0 0 ${star.size * 2}px rgba(255, 255, 255, ${star.opacity})`,
          }}
        />
      ))}

      {/* Ay Silueti */}
      <div className="absolute top-12 right-12 w-24 h-24 rounded-full bg-yellow-100 opacity-10 shadow-lg" style={{
        boxShadow: 'inset -2px -2px 6px rgba(0, 0, 0, 0.3), 0 0 40px rgba(255, 200, 0, 0.2)'
      }} />

      {/* Yıldız Konstelasyonları - Çizgiler */}
      <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none">
        <defs>
          <linearGradient id="starGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(168, 85, 247, 0.6)" />
            <stop offset="100%" stopColor="rgba(99, 102, 241, 0.6)" />
          </linearGradient>
        </defs>

        {/* Örnek konstelasyon çizgileri */}
        <line x1="10%" y1="20%" x2="15%" y2="25%" stroke="url(#starGradient)" strokeWidth="1" />
        <line x1="15%" y1="25%" x2="12%" y2="32%" stroke="url(#starGradient)" strokeWidth="1" />
        <line x1="80%" y1="30%" x2="85%" y2="35%" stroke="url(#starGradient)" strokeWidth="1" />
        <line x1="85%" y1="35%" x2="90%" y2="40%" stroke="url(#starGradient)" strokeWidth="1" />
      </svg>

      {/* Çok sayıda micro-stars */}
      {microStars && microStars.map((star, i) => (
        <div
          key={`micro-${i}`}
          className="absolute rounded-full"
          style={{
            width: '1px',
            height: '1px',
            backgroundColor: 'white',
            left: `${star.x}%`,
            top: `${star.y}%`,
            opacity: star.opacity,
            animation: `twinkle ${star.duration}s infinite`,
          }}
        />
      ))}
    </div>
  );
}
