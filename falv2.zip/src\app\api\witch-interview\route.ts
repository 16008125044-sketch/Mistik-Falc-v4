import { NextRequest, NextResponse } from 'next/server';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export async function POST(request: NextRequest) {
  try {
    const { question, answer, questionNumber } = await request.json();

    if (!OPENAI_API_KEY) {
      return NextResponse.json(
        { error: 'OpenAI API key not configured' },
        { status: 500 }
      );
    }

    const systemPrompt = `You are a mystical and wise AI evaluator for a witch badge interview. 
Your role is to assess answers to questions about psychology, divination (tarot), and magic.

Evaluate the answer based on:
1. Depth of understanding (10%)
2. Spiritual/mystical perspective (30%)
3. Psychological insight (30%)
4. Connection to helping others (20%)
5. Overall coherence and effort (10%)

Rules:
- Score 70+ means PASS (evaluation: true)
- Score <70 means FAIL (evaluation: false)
- Be encouraging but honest
- Respond in Turkish
- Keep response to 2-3 sentences max
- Always start with ✅ for pass or ❌ for fail
- Include brief feedback

Format your response EXACTLY like this:
✅/❌ [Feedback in Turkish]. Score: [number]/100

If pass: "✅ Excellent insights about [topic]! Your spiritual understanding is clear. Score: 82/100"
If fail: "❌ Interesting perspective, but needs more depth in mystical context. Score: 65/100"`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: systemPrompt,
          },
          {
            role: 'user',
            content: `Question ${questionNumber}/12: "${question}"\n\nAnswer: "${answer}"`,
          },
        ],
        temperature: 0.7,
        max_tokens: 150,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('OpenAI API error:', error);
      return NextResponse.json(
        { error: 'OpenAI API error', details: error },
        { status: response.status }
      );
    }

    const data = await response.json();
    const evaluation = data.choices[0].message.content;

    // Parse pass/fail from evaluation
    const passed = evaluation.startsWith('✅');

    return NextResponse.json({
      evaluation,
      passed,
      score: extractScore(evaluation),
    });
  } catch (error) {
    console.error('Interview evaluation error:', error);
    return NextResponse.json(
      { error: 'Interview evaluation failed' },
      { status: 500 }
    );
  }
}

function extractScore(evaluation: string): number {
  const match = evaluation.match(/Score:\s*(\d+)/);
  return match ? parseInt(match[1]) : 0;
}
