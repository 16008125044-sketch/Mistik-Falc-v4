'use client';

import React from 'react';
import { useLevel } from './LevelProvider';
import { MysticTarotTheme } from './mystic_tarot_theme';

export function QuickTestPanel() {
  const { addReading, addCustomExp, userLevel } = useLevel();

  return (
    <div className="max-w-2xl mx-auto p-4 rounded-lg border" style={{ background: MysticTarotTheme.colors.secondary, borderColor: MysticTarotTheme.colors.primary }}>
      <h3 className="text-lg font-bold mb-3" style={{ color: MysticTarotTheme.colors.text }}>🧪 Test Paneli</h3>
      
      <div className="flex gap-2 flex-wrap">
        <button 
          onClick={() => addReading()}
          className="px-4 py-2 rounded-lg font-semibold hover:opacity-80 transition"
          style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
        >
          Fal Çek (+25 EXP)
        </button>
        
        <button 
          onClick={() => addCustomExp(50)}
          className="px-4 py-2 rounded-lg font-semibold hover:opacity-80 transition"
          style={{ background: MysticTarotTheme.colors.highlight, color: 'black' }}
        >
          +50 EXP
        </button>

        <button 
          onClick={() => addCustomExp(100)}
          className="px-4 py-2 rounded-lg font-semibold hover:opacity-80 transition"
          style={{ background: '#7c3aed', color: 'white' }}
        >
          +100 EXP
        </button>

        <button 
          onClick={() => addCustomExp(500)}
          className="px-4 py-2 rounded-lg font-semibold hover:opacity-80 transition"
          style={{ background: '#ec4899', color: 'white' }}
        >
          +500 EXP
        </button>
      </div>

      {userLevel && (
        <div className="mt-3 text-xs opacity-70" style={{ color: MysticTarotTheme.colors.text }}>
          Mevcut: Level {userLevel.level} | EXP: {userLevel.currentExp}/100
        </div>
      )}
    </div>
  );
}
