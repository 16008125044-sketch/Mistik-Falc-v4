'use client';

import React, { useEffect, useState } from 'react';
import { useFreighter } from '@/components/FreighterProvider';

export default function QuestionDebugPage() {
  const { address } = useFreighter();
  const [allData, setAllData] = useState<Record<string, any>>({});

  useEffect(() => {
    // Tüm localStorage'ı oku
    const data: Record<string, any> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        try {
          const value = localStorage.getItem(key);
          // JSON parse etmeyi dene
          try {
            data[key] = JSON.parse(value || '');
          } catch {
            data[key] = value;
          }
        } catch (e) {
          data[key] = 'Hata';
        }
      }
    }
    setAllData(data);
    console.log('=== TÜIM localStorage ===', data);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">🔍 Soru Debug Sayfası</h1>

        <div className="mb-8 bg-blue-900/50 p-4 rounded">
          <p className="font-bold mb-2">📍 Şu anki Adres:</p>
          <p className="font-mono text-sm">{address || 'Yükleniyor...'}</p>
        </div>

        {/* receivedQuestions içeren tüm anahtarları göster */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">📋 receivedQuestions Anahtarları</h2>
          {Object.entries(allData).map(([key, value]) => {
            if (key.includes('receivedQuestions')) {
              return (
                <div key={key} className="bg-gray-800 p-4 rounded mb-4">
                  <p className="font-mono text-sm font-bold text-yellow-400 mb-2">{key}</p>
                  <pre className="bg-black p-2 rounded text-xs overflow-auto max-h-64 text-gray-300">
                    {typeof value === 'string' ? value : JSON.stringify(value, null, 2)}
                  </pre>
                  {Array.isArray(value) && (
                    <p className="text-sm text-gray-400 mt-2">
                      ✅ {value.length} soru var
                    </p>
                  )}
                </div>
              );
            }
            return null;
          })}
        </div>

        {/* profile_*_name anahtarlarını göster */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">👥 Profil Adları</h2>
          {Object.entries(allData).map(([key, value]) => {
            if (key.includes('profile_') && key.includes('_name')) {
              const addr = key.match(/profile_(.+)_name/)?.[1];
              const isAstrologer = allData[`profile_${addr}_isAstrologer`];
              return (
                <div key={key} className="bg-gray-800 p-3 rounded mb-2">
                  <p className="font-bold">{value}</p>
                  <p className="text-xs text-gray-500">{addr}</p>
                  <p className="text-xs">
                    {isAstrologer === 'true' ? '✅ Falcı' : '❌ Falcı değil'}
                  </p>
                </div>
              );
            }
            return null;
          })}
        </div>

        {/* Soruları Filtrele - answererAddress kontrolü */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">🔎 Adrese Gönderilen Sorular</h2>
          {address && (
            <>
              <p className="mb-4 text-gray-400">Aranan adres: <span className="font-mono">{address}</span></p>
              {(() => {
                const foundQuestions: any[] = [];
                Object.entries(allData).forEach(([key, value]) => {
                  if (key.includes('receivedQuestions') && Array.isArray(value)) {
                    const questionsForThisAddress = value.filter(
                      (q: any) => q.answererAddress === address
                    );
                    if (questionsForThisAddress.length > 0) {
                      foundQuestions.push({
                        key,
                        questions: questionsForThisAddress,
                      });
                    }
                  }
                });

                if (foundQuestions.length === 0) {
                  return (
                    <div className="bg-red-900/30 border border-red-500 p-4 rounded">
                      ❌ Bu adrese hiç soru bulunamadı!
                    </div>
                  );
                }

                return foundQuestions.map(({ key, questions }) => (
                  <div key={key} className="bg-green-900/30 border border-green-500 p-4 rounded mb-4">
                    <p className="font-bold text-green-300 mb-2">✅ {questions.length} soru bulundu:</p>
                    {questions.map((q: any, idx: number) => (
                      <div key={idx} className="bg-green-900/50 p-3 rounded mb-2 text-sm">
                        <p className="font-bold">Q{idx + 1}: {q.question}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          Soran: {q.askerName} ({q.askerAddress?.slice(0, 8)}...)
                        </p>
                        <p className="text-xs text-gray-400">
                          ID: {q.id}
                        </p>
                      </div>
                    ))}
                  </div>
                ));
              })()}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
