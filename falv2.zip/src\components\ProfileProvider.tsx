'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { useFreighter } from './FreighterProvider';

// Admin adresi - Kral Falcı
const ADMIN_ADDRESS = 'GDYWAIW7PUWCXAQ3PN6G6HHU76IRBP43T7XBXE5FHUNRQU2LKT5BCERO';

interface UserProfile {
  name: string;
  profileImage: string | null;
  walletAddress: string;
  isPremium: boolean;
  isBanned?: boolean;
  isWitch?: boolean;
}

interface ProfileContextType {
  profile: UserProfile | null;
  isLoading: boolean;
  updateName: (name: string) => Promise<void>;
  uploadProfileImage: (file: File) => Promise<void>;
  removeProfileImage: () => Promise<void>;
  setPremium: (isPremium: boolean) => void;
  isAdmin: boolean;
  banUser: (address: string) => void;
  unbanUser: (address: string) => void;
  removePremiumFromUser: (address: string) => void;
  setWitch: (isWitch: boolean) => void;
  removeWitchFromUser: (address: string) => void;
  isWitch: boolean;
}

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

export function ProfileProvider({ children }: { children: React.ReactNode }) {
  const { address, balance: freighterBalance } = useFreighter();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isWitch, setIsWitchState] = useState(false);

  const storageKey = (addr: string, field: string) => `profile_${addr}_${field}`;

  useEffect(() => {
    if (!address) {
      setProfile(null);
      setIsWitchState(false);
      return;
    }

    setIsLoading(true);
    const savedName = localStorage.getItem(storageKey(address, 'name')) || 'Mistik Falcı';
    const savedImage = localStorage.getItem(storageKey(address, 'image'));
    const isPremium = localStorage.getItem(storageKey(address, 'isPremium')) === 'true';
    const witchStatus = localStorage.getItem(storageKey(address, 'isWitch')) === 'true';

    setProfile({
      name: savedName,
      profileImage: savedImage,
      walletAddress: address,
      isPremium,
      isWitch: witchStatus,
    });
    setIsWitchState(witchStatus);
    setIsLoading(false);
  }, [address]);

  const updateName = async (name: string) => {
    if (!address || !profile) return;
    localStorage.setItem(storageKey(address, 'name'), name);
    setProfile({ ...profile, name });
  };

  const uploadProfileImage = async (file: File): Promise<void> => {
    if (!address || !profile) return;

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        localStorage.setItem(storageKey(address, 'image'), base64);
        setProfile({ ...profile, profileImage: base64 });
        resolve(undefined);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const removeProfileImage = async () => {
    if (!address || !profile) return;
    localStorage.removeItem(storageKey(address, 'image'));
    setProfile({ ...profile, profileImage: null });
  };

  const setPremium = (isPremium: boolean) => {
    if (!address || !profile) return;
    
    // Eğer premium olmaya çalışıyorsa (isPremium = true)
    if (isPremium && !profile.isPremium) {
      const xlmBalance = parseFloat(freighterBalance) || 0;
      
      // 250 XLM kontrol et (Premium rozeti 250 XLM mal)
      if (xlmBalance < 250) {
        alert('❌ Yetersiz XLM! Premium rozeti 250 XLM tutuyor. Cüzdanınızda: ' + xlmBalance.toFixed(4) + ' XLM');
        return;
      }
      
      // Note: XLM çıkarma işlemi Freighter'ın kendisi tarafından yapılmalı
      // Bu uygulama için localStorage'a not alalım
      localStorage.setItem(storageKey(address, 'premiumPaid'), 'true');
    }
    
    localStorage.setItem(storageKey(address, 'isPremium'), isPremium.toString());
    setProfile({ ...profile, isPremium });
  };

  const banUser = (userAddress: string) => {
    localStorage.setItem(`ban_${userAddress}`, 'true');
  };

  const unbanUser = (userAddress: string) => {
    localStorage.removeItem(`ban_${userAddress}`);
  };

  const removePremiumFromUser = (userAddress: string) => {
    localStorage.setItem(storageKey(userAddress, 'isPremium'), 'false');
  };

  const setWitch = (witchStatus: boolean) => {
    if (!address || !profile) return;
    localStorage.setItem(storageKey(address, 'isWitch'), witchStatus.toString());
    setProfile({ ...profile, isWitch: witchStatus });
    setIsWitchState(witchStatus);
  };

  const removeWitchFromUser = (userAddress: string) => {
    localStorage.setItem(storageKey(userAddress, 'isWitch'), 'false');
  };

  const isAdmin = address === ADMIN_ADDRESS;



  return (
    <ProfileContext.Provider
      value={{
        profile,
        isLoading,
        updateName,
        uploadProfileImage,
        removeProfileImage,
        setPremium,
        isAdmin,
        banUser,
        unbanUser,
        removePremiumFromUser,
        setWitch,
        removeWitchFromUser,
        isWitch,
      }}
    >
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error('useProfile must be used within ProfileProvider');
  }
  return context;
}
