'use client';

import React, { useState, useEffect } from 'react';
import { MysticTarotTheme } from './mystic_tarot_theme';

interface WitchInterviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface QuestionOption {
  text: string;
  isCorrect: boolean;
}

interface WitchQuestion {
  question: string;
  options: QuestionOption[];
}

export const WitchInterviewModal: React.FC<WitchInterviewModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isInterviewActive, setIsInterviewActive] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [feedback, setFeedback] = useState('');
  const [showFeedback, setShowFeedback] = useState(false);
  const [isPassed, setIsPassed] = useState(false);
  const [interviewEnded, setInterviewEnded] = useState(false);
  const [passedQuestions, setPassedQuestions] = useState(0);
  const [failedQuestions, setFailedQuestions] = useState(0);
  const [randomizedQuestions, setRandomizedQuestions] = useState<WitchQuestion[]>([]);

  const allWitchQuestions: WitchQuestion[] = [
    {
      question: 'Ruhsal farkındalık nedir?',
      options: [
        { text: 'Sadece dini inanç', isCorrect: false },
        { text: 'İçsel bilinç ve enerjinin farkına varma', isCorrect: true },
        { text: 'Sadece meditasyon yapmak', isCorrect: false },
        { text: 'Mantıksal düşünme', isCorrect: false },
      ],
    },
    {
      question: 'Bir kişiye sezgisel tavsiye verilirken en önemli şey nedir?',
      options: [
        { text: 'Onları yargılamak', isCorrect: false },
        { text: 'Empati ve dinlemeyi temel almak', isCorrect: true },
        { text: 'Hemen çözüm sunmak', isCorrect: false },
        { text: 'Kendi deneyimini dayatmak', isCorrect: false },
      ],
    },
    {
      question: 'Psikoloji ve mistisizm arasındaki ilişki nedir?',
      options: [
        { text: 'Birbirinden tamamen bağımsız', isCorrect: false },
        { text: 'İkisi de insan davranışını anlamaya yardımcı olabilir', isCorrect: true },
        { text: 'Mistisizm bilimsel değildir', isCorrect: false },
        { text: 'Sadece mistisizm doğru', isCorrect: false },
      ],
    },
    {
      question: 'Fala inanmak neye dayanır?',
      options: [
        { text: 'Sadece kehanetler', isCorrect: false },
        { text: 'Semboller ve farkındalık aracı olarak', isCorrect: true },
        { text: 'Tesadüfe', isCorrect: false },
        { text: 'Bilimsel kanıtlara', isCorrect: false },
      ],
    },
    {
      question: 'Büyü ve niyet arasındaki fark nedir?',
      options: [
        { text: 'Hiç fark yok', isCorrect: false },
        { text: 'Niyet enerji, büyü ise bu enerjiyi yönlendirme', isCorrect: true },
        { text: 'Büyü gerçek, niyet değil', isCorrect: false },
        { text: 'İkisi de aynı şey', isCorrect: false },
      ],
    },
    {
      question: 'İnsanlara pozitif etki yapmak için en önemli şey nedir?',
      options: [
        { text: 'Onları değiştirmeye çalışmak', isCorrect: false },
        { text: 'Samimi ilgi göstermek ve sevgi göndermek', isCorrect: true },
        { text: 'Bilgelik yüklemeyle anlatmak', isCorrect: false },
        { text: 'Kendi fikirlerini kabul ettirmek', isCorrect: false },
      ],
    },
    {
      question: 'Çakralar ve enerji merkezleri neyi temsil eder?',
      options: [
        { text: 'Sadece fantezi', isCorrect: false },
        { text: 'Vücudumuzun enerji sistemi ve duygusal merkezleri', isCorrect: true },
        { text: 'Sadece fiziksel noktalar', isCorrect: false },
        { text: 'Astronomi ile ilgili', isCorrect: false },
      ],
    },
    {
      question: 'Empati ve enerjik bağlantı nasıl geliştirilir?',
      options: [
        { text: 'Kendine kapanarak', isCorrect: false },
        { text: 'Meditasyon, dinleme ve açık kalp tutumu ile', isCorrect: true },
        { text: 'İnsanları görmezden gelerek', isCorrect: false },
        { text: 'Sadece düşünerek', isCorrect: false },
      ],
    },
    {
      question: 'Tarot kartları ne içindir?',
      options: [
        { text: 'Sadece gelecek tahmin etmek', isCorrect: false },
        { text: 'Farkındalık, rehberlik ve iç gözlem aracı', isCorrect: true },
        { text: 'Oyun oynamak', isCorrect: false },
        { text: 'Sadece eğlence', isCorrect: false },
      ],
    },
    {
      question: 'Kişisel dönüşüm nasıl başlar?',
      options: [
        { text: 'Birden bire olur', isCorrect: false },
        { text: 'Kendini tanımak ve açık olmak ile', isCorrect: true },
        { text: 'Sadece dış faktörlerle', isCorrect: false },
        { text: 'Kimse değişemez', isCorrect: false },
      ],
    },
    {
      question: 'Bilinçaltı ve sezgi arasındaki fark nedir?',
      options: [
        { text: 'Hiç fark yok', isCorrect: false },
        { text: 'Bilinçaltı deposu, sezgi ise haberci', isCorrect: true },
        { text: 'Sezgi gerçek değil', isCorrect: false },
        { text: 'Sadece bilinçaltı önemli', isCorrect: false },
      ],
    },
    {
      question: 'Bir cadının en önemli sorumluluğu nedir?',
      options: [
        { text: 'Güçlü olmak', isCorrect: false },
        { text: 'Bilgelik, etik ve insanlara yardım etmek', isCorrect: true },
        { text: 'Kontrol sahibi olmak', isCorrect: false },
        { text: 'Herkes tarafından korkulan olmak', isCorrect: false },
      ],
    },
  ];

  const shuffleQuestions = (questions: WitchQuestion[]): WitchQuestion[] => {
    return questions.sort(() => Math.random() - 0.5);
  };

  const witchQuestions = randomizedQuestions.length > 0 ? randomizedQuestions : allWitchQuestions;

  useEffect(() => {
    if (!isInterviewActive || interviewEnded) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isInterviewActive, interviewEnded]);

  const handleTimeUp = () => {
    setIsInterviewActive(false);
    setFeedback('⏰ Süre bitti! Cevap değerlendirilmedi.');
    setShowFeedback(true);
    setFailedQuestions(failedQuestions + 1);
    moveToNextQuestion();
  };

  const handleAnswerSelect = (optionIndex: number) => {
    if (!isInterviewActive) return;

    setSelectedAnswer(optionIndex);
    setIsInterviewActive(false);

    const isCorrect = witchQuestions[currentQuestion].options[optionIndex].isCorrect;
    
    if (isCorrect) {
      setFeedback('✅ Doğru cevap! Müthiş bilgelik gösterdiniz.');
      setPassedQuestions(passedQuestions + 1);
    } else {
      const correctAnswer = witchQuestions[currentQuestion].options.find(opt => opt.isCorrect)?.text;
      setFeedback('❌ Yanlış cevap. Doğru cevap: ' + correctAnswer);
      setFailedQuestions(failedQuestions + 1);
    }

    setShowFeedback(true);
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);

    // Sonraki soruya geç
    moveToNextQuestion();
  };

  const moveToNextQuestion = () => {
    setTimeout(() => {
      setCurrentQuestion((prev) => {
        const nextQuestion = prev + 1;
        if (nextQuestion >= witchQuestions.length) {
          setInterviewEnded(true);
          setIsPassed(passedQuestions >= 10);
        } else {
          setCurrentQuestion(nextQuestion);
          setSelectedAnswer(null);
          setShowFeedback(false);
          setTimeLeft(30);
          setIsInterviewActive(true);
        }
        return nextQuestion;
      });
    }, 2500);
  };

  const handleStartInterview = () => {
    const shuffled = shuffleQuestions([...allWitchQuestions]);
    setRandomizedQuestions(shuffled);
    
    setIsInterviewActive(true);
    setAttempts(attempts + 1);
    setCurrentQuestion(0);
    setAnswers([]);
    setSelectedAnswer(null);
    setShowFeedback(false);
    setIsPassed(false);
    setInterviewEnded(false);
    setTimeLeft(30);
    setPassedQuestions(0);
    setFailedQuestions(0);
  };

  const handleRetry = () => {
    if (attempts < 2) {
      handleStartInterview();
    }
  };

  const handleSuccess = () => {
    onSuccess();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div
        className="rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border-2"
        style={{
          background: `linear-gradient(135deg, ${MysticTarotTheme.colors.secondary}, ${MysticTarotTheme.colors.background})`,
          borderColor: MysticTarotTheme.colors.primary,
        }}
      >
        <div className="p-6">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold mb-2" style={{ color: MysticTarotTheme.colors.primary }}>
              🧙‍♀️ Cadı Sınav
            </h2>
            <p style={{ color: MysticTarotTheme.colors.text }}>
              12 soru • 30 saniye • 2 hak
            </p>
          </div>

          {!isInterviewActive && !interviewEnded && attempts === 0 && (
            <div className="text-center">
              <p className="mb-4" style={{ color: MysticTarotTheme.colors.text }}>
                Cadı rozetini kazanmak için sınavı geçmelisin. (10/12 başarılı)
              </p>
              <button
                onClick={handleStartInterview}
                className="px-6 py-3 rounded-lg font-bold text-white hover:opacity-80 transition text-lg"
                style={{ background: MysticTarotTheme.colors.primary }}
              >
                ✨ Sınavı Başlat
              </button>
            </div>
          )}

          {isInterviewActive && !interviewEnded && (
            <div>
              <div className="mb-6">
                <div className="flex justify-between mb-2">
                  <span style={{ color: MysticTarotTheme.colors.text }}>
                    Soru {currentQuestion + 1} / {witchQuestions.length}
                  </span>
                  <span
                    style={{
                      color: timeLeft < 10 ? '#ef4444' : MysticTarotTheme.colors.primary,
                      fontWeight: 'bold',
                    }}
                  >
                    ⏱️ {timeLeft}s
                  </span>
                </div>
                <div
                  className="w-full h-2 rounded-full overflow-hidden"
                  style={{ background: 'rgba(124, 58, 237, 0.2)' }}
                >
                  <div
                    className="h-full transition-all duration-300"
                    style={{
                      width: `${((currentQuestion + 1) / witchQuestions.length) * 100}%`,
                      background: MysticTarotTheme.colors.primary,
                    }}
                  />
                </div>
              </div>

              <div className="mb-6">
                <h3
                  className="text-xl font-bold mb-6"
                  style={{ color: MysticTarotTheme.colors.primary }}
                >
                  {witchQuestions[currentQuestion]?.question}
                </h3>

                <div className="space-y-3">
                  {witchQuestions[currentQuestion]?.options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswerSelect(index)}
                      className="w-full p-4 rounded-lg text-left font-semibold transition transform hover:scale-105"
                      style={{
                        background: selectedAnswer === index
                          ? MysticTarotTheme.colors.primary
                          : 'rgba(124, 58, 237, 0.2)',
                        color: MysticTarotTheme.colors.text,
                        border: `2px solid ${selectedAnswer === index ? MysticTarotTheme.colors.primary : 'transparent'}`,
                      }}
                    >
                      {String.fromCharCode(65 + index)}. {option.text}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {showFeedback && !interviewEnded && (
            <div
              className="p-4 rounded-lg border-2 mb-4"
              style={{
                background: feedback.includes('✅')
                  ? 'rgba(34, 197, 94, 0.2)'
                  : 'rgba(239, 68, 68, 0.2)',
                borderColor: feedback.includes('✅')
                  ? '#22c55e'
                  : '#ef4444',
              }}
            >
              <p style={{ color: MysticTarotTheme.colors.text }}>{feedback}</p>
            </div>
          )}

          {interviewEnded && (
            <div className="text-center">
              {isPassed ? (
                <div>
                  <p className="text-3xl mb-2 font-bold">✅ Tebrikler!</p>
                  <p className="text-xl mb-6" style={{ color: '#22c55e' }}>
                    Sınavı başarıyla geçtiniz! 🧙‍♀️
                  </p>
                  <div className="mb-6 p-4 rounded-lg" style={{ background: 'rgba(34, 197, 94, 0.2)', borderLeft: '4px solid #22c55e' }}>
                    <p className="text-lg font-bold" style={{ color: MysticTarotTheme.colors.text }}>
                      📊 Sonuç: {passedQuestions}/12 Doğru
                    </p>
                  </div>
                  <button
                    onClick={handleSuccess}
                    className="px-6 py-3 rounded-lg font-bold text-white hover:opacity-80 transition"
                    style={{ background: MysticTarotTheme.colors.primary }}
                  >
                    ✨ Cadı Rozeti Al
                  </button>
                </div>
              ) : (
                <div>
                  <p className="text-3xl mb-2 font-bold">❌ Başarısız</p>
                  <p className="mb-6" style={{ color: MysticTarotTheme.colors.text }}>
                    Minimum 10/12 soru başarılı olmalıdır.
                  </p>
                  <div className="mb-6 p-4 rounded-lg" style={{ background: 'rgba(239, 68, 68, 0.2)', borderLeft: '4px solid #ef4444' }}>
                    <p className="text-lg font-bold" style={{ color: MysticTarotTheme.colors.text }}>
                      📊 Sonuç: {passedQuestions}/12 Doğru
                    </p>
                  </div>
                  <p className="mb-4" style={{ color: MysticTarotTheme.colors.text }}>
                    {attempts < 2 ? `${2 - attempts} haklarınız kaldı.` : 'Tüm haklarınız bitti.'}
                  </p>
                  {attempts < 2 ? (
                    <button
                      onClick={handleRetry}
                      className="px-6 py-3 rounded-lg font-bold text-white hover:opacity-80 transition"
                      style={{ background: MysticTarotTheme.colors.primary }}
                    >
                      🔄 Tekrar Dene
                    </button>
                  ) : (
                    <button
                      onClick={onClose}
                      className="px-6 py-3 rounded-lg font-bold text-white hover:opacity-80 transition"
                      style={{ background: '#ef4444' }}
                    >
                      Kapat
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
