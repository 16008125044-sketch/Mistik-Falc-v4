'use client';

import { useState } from 'react';
import CosmicBackground from '@/components/CosmicBackground';
import ZodiacSelector from '@/components/ZodiacSelector';
import SecIzleTarot from '@/components/SecIzleTarot';
import AIMysticReader from '@/components/AIMysticReader';
import DailyFortune from '@/components/DailyFortune';
import { LevelStats } from '@/components/LevelStats';
import { useFreighter } from '@/components/FreighterProvider';
import { useProfile } from '@/components/ProfileProvider';

interface Card {
  id: number;
  name: string;
  short: string;
  long: string;
  rarity: 'normal' | 'rare';
  value: number;
}

const SAMPLE_CARDS: Card[] = [
  {
    id: 1,
    name: 'Güneş',
    short: 'Başarı, aydınlanma',
    long: 'Yakın zamanda bir aydınlanma yaşayacaksınız; hedeflerinizde ilerleme bekleyin.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 2,
    name: 'Ay',
    short: 'İçsel sezgi, belirsizlik',
    long: 'Sezgilerinize güvenin; görünmeyen bağlantılar bugün önem kazanacak.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 3,
    name: 'Kule',
    short: 'Değişim, şok',
    long: 'Beklenmedik bir değişim var — yıkımın ardından hızla yeniden inşa etme fırsatı gelecek.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 4,
    name: 'Aşıklar',
    short: 'Seçimler, yakınlık',
    long: 'Kalbiniz ve mantığınız arasında bir seçim sizi bekliyor; dürüst iletişim anahtar.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 5,
    name: 'Adalet',
    short: 'Denge, sonuç',
    long: 'Eylemlerinizin sonuçları netleşiyor; adil davranmak size avantaj sağlar.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 6,
    name: 'Şair',
    short: 'Yaratıcılık, ilham',
    long: 'Sanat ve yaratıcılık seni çağırıyor. Hayal gücünü serbest bırak ve yeni şeyler yarat.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 7,
    name: 'Erem',
    short: 'İç aydınlanma, bilgelik',
    long: 'Yalnızlığa ihtiyaç var. Sessizlikte kendini bul ve ruhun mesajını dinle.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 8,
    name: 'Macera',
    short: 'Yolculuk, keşif',
    long: 'Yeni maceralar ve keşifler kapıda. Bilinmeyene adım at ve korkularını aş.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 9,
    name: 'Değişim',
    short: 'Dönüşüm, gelişim',
    long: 'Büyük bir dönüşüm yaşıyorsun veya yaşayacaksın. Eskileri bırak, yeniye hoşgeldin de.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 10,
    name: 'Çakra',
    short: 'Daimî döngü, karma',
    long: 'Hayatın döngüsü seni yeniden başlangıca getiriyor. Tarihten ders al ve farklı hareket et.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 11,
    name: 'Gücü',
    short: 'İç kuvvet, kontrol',
    long: 'Hayatında gücü sendin. Korku ve şüphelerini alt et, kendi yaşamının sahibi ol.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 12,
    name: 'İçgüzelleme',
    short: 'Yavaşlık, adanmışlık',
    long: 'Hızı kesmek ve önemli şeylere bağlanmak zamanı. Sabırla ve imanla devam et.',
    rarity: 'normal',
    value: 1,
  },
  {
    id: 13,
    name: '⭐ Yıldız Karması',
    short: 'Efsanevi bereket, istediklerini çekme',
    long: '✨ EFSANEVI! Evrenden muazzam bir hediye geliyor! Tüm iyiliklerin kendini bulacak. Hayatın değişeceğini hisset. ✨',
    rarity: 'rare',
    value: 2,
  },
  {
    id: 14,
    name: '🔮 Kozmik Birlik',
    short: 'Efsanevi uyum, evrensel bağlantı',
    long: '✨ EFSANEVI! Senin ve evrenin vibrasyonları mükemmel uyum içinde. Her şey mümkün, sınırlar yok. Sonsuzluğu hisset. ✨',
    rarity: 'rare',
    value: 2,
  },
];

export default function MysticHome() {
  const [currentTab, setCurrentTab] = useState<'daily' | 'tarot' | 'zodiac'>('daily');
  const [selectedZodiac, setSelectedZodiac] = useState<any>(null);
  const [selectedCard, setSelectedCard] = useState<Card | null>(null);
  const { address, isConnected } = useFreighter();
  const { profile } = useProfile();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 text-white overflow-hidden">
      {/* Kozmik Arka Plan */}
      <CosmicBackground count={100} />

      {/* İçerik */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="backdrop-blur-md bg-gradient-to-r from-purple-900/30 to-indigo-900/30 border-b border-purple-500/30 sticky top-0 z-20">
          <div className="max-w-7xl mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="text-center flex-1">
                <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-gradient-to-r from-yellow-300 via-purple-400 to-pink-400 bg-clip-text">
                  ✨ MİSTİK FALCI ✨
                </h1>
                <p className="text-purple-200 mt-2">Yıldızlar, burçlar ve tarot kartları seni çağırıyor...</p>
              </div>
            </div>

            {/* Freighter Durumu */}
            {isConnected && address && (
              <div className="mt-4 text-center text-xs text-yellow-300">
                🔗 Cüzdan Bağlı: {address.slice(0, 8)}...{address.slice(-8)}
              </div>
            )}
          </div>
        </header>

        {/* Tab Navigasyonu */}
        <div className="backdrop-blur-sm bg-slate-900/40 border-b border-purple-500/20">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex gap-2 py-4 flex-wrap">
              {[
                { id: 'daily', label: '☀️ Günün Falı', icon: '📅' },
                { id: 'zodiac', label: '♈ Burç Falı', icon: '⭐' },
                { id: 'tarot', label: '🃏 Tarot Kartları', icon: '🔮' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setCurrentTab(tab.id as any)}
                  className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                    currentTab === tab.id
                      ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                      : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700/60 border border-purple-500/30'
                  }`}
                >
                  {tab.icon} {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Ana İçerik */}
        <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-12">
          {/* Günün Falı */}
          {currentTab === 'daily' && (
            <div className="animate-fadeIn">
              <DailyFortune />
            </div>
          )}

          {/* Burç Falı */}
          {currentTab === 'zodiac' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <div className="sticky top-32">
                  <ZodiacSelector onSelect={setSelectedZodiac} />
                </div>
              </div>
              <div className="lg:col-span-2">
                {selectedZodiac && (
                  <div className="animate-fadeIn">
                    <AIMysticReader zodiacName={selectedZodiac.name} card={selectedCard || undefined} />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Tarot Kartları */}
          {currentTab === 'tarot' && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text mb-2">
                  🃏 Tarot Kartı Seçiniz
                </h2>
                <p className="text-purple-200">Bir kart seçerek kaderinizi keşfedin</p>
              </div>

              <SecIzleTarot cardPool={SAMPLE_CARDS} animationSeconds={10} isPremium={profile?.isPremium || false} />
            </div>
          )}
        </main>

        {/* Seviye Bilgileri */}
        <section className="mb-8 max-w-7xl mx-auto px-4">
          <LevelStats />
        </section>

        {/* Footer */}
        <footer className="backdrop-blur-md bg-gradient-to-r from-purple-900/30 to-indigo-900/30 border-t border-purple-500/30 py-8 mt-12">
          <div className="max-w-7xl mx-auto px-4 text-center space-y-2">
            <p className="text-sm text-purple-300">
              ✨ Bu platform eğlence ve rehberlik amaçlıdır. Önemli kararlar için profesyonel tavsiye alınız. ✨
            </p>
            <p className="text-xs text-slate-400">
              Rise in Istanbul 2025 • Web3 & Stellar Bootcamp • Powered by Freighter
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
