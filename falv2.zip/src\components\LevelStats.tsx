'use client';

import React from 'react';
import { useLevel } from './LevelProvider';
import { MysticTarotTheme } from './mystic_tarot_theme';

export function LevelStats() {
  const { userLevel } = useLevel();

  if (!userLevel) return null;

  return (
    <div className="max-w-4xl mx-auto p-6" style={{ background: MysticTarotTheme.colors.background, borderRadius: '12px' }}>
      <h2 className="text-2xl font-bold mb-6" style={{ color: MysticTarotTheme.colors.text }}>📊 Seviye Bilgileri</h2>

      {/* Başlık ve Seviye */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="p-4 rounded-lg" style={{ background: MysticTarotTheme.colors.secondary, borderLeft: `4px solid ${MysticTarotTheme.colors.primary}` }}>
          <p className="text-sm opacity-70" style={{ color: MysticTarotTheme.colors.text }}>Mevcut Başlık</p>
          <p className="text-xl font-bold" style={{ color: MysticTarotTheme.colors.highlight }}>{userLevel.title}</p>
        </div>
        <div className="p-4 rounded-lg" style={{ background: MysticTarotTheme.colors.secondary, borderLeft: `4px solid ${MysticTarotTheme.colors.highlight}` }}>
          <p className="text-sm opacity-70" style={{ color: MysticTarotTheme.colors.text }}>Seviye</p>
          <p className="text-xl font-bold" style={{ color: MysticTarotTheme.colors.primary }}>{userLevel.level} / 10</p>
        </div>
      </div>

      {/* İlerleme */}
      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <p className="text-sm" style={{ color: MysticTarotTheme.colors.text }}>İlerleme</p>
          <p className="text-sm font-semibold" style={{ color: MysticTarotTheme.colors.highlight }}>
            {userLevel.currentExp} / {userLevel.level === 10 ? 'MAX' : '100'} EXP
          </p>
        </div>
        <div className="w-full bg-black/40 rounded-full h-3 overflow-hidden">
          <div 
            className="h-full transition-all duration-500" 
            style={{ 
              width: `${(userLevel.currentExp / 100) * 100}%`, 
              background: `linear-gradient(90deg, ${MysticTarotTheme.colors.primary}, ${MysticTarotTheme.colors.highlight})`
            }}
          />
        </div>
      </div>

      {/* Puanlar */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-lg text-center" style={{ background: 'rgba(224, 224, 224, 0.1)', borderTop: '2px solid #e0e0e0' }}>
          <p className="text-3xl mb-2">🌙</p>
          <p className="text-xs opacity-70" style={{ color: MysticTarotTheme.colors.text }}>Ay Işığı</p>
          <p className="text-2xl font-bold" style={{ color: '#e0e0e0' }}>{userLevel.rewards.moonlight}</p>
        </div>
        <div className="p-4 rounded-lg text-center" style={{ background: 'rgba(251, 191, 36, 0.1)', borderTop: '2px solid #fbbf24' }}>
          <p className="text-3xl mb-2">⭐</p>
          <p className="text-xs opacity-70" style={{ color: MysticTarotTheme.colors.text }}>Yıldız</p>
          <p className="text-2xl font-bold" style={{ color: '#fbbf24' }}>{userLevel.rewards.star}</p>
        </div>
        <div className="p-4 rounded-lg text-center" style={{ background: 'rgba(124, 58, 237, 0.1)', borderTop: '2px solid #7c3aed' }}>
          <p className="text-3xl mb-2">💎</p>
          <p className="text-xs opacity-70" style={{ color: MysticTarotTheme.colors.text }}>Kristal</p>
          <p className="text-2xl font-bold" style={{ color: '#22c55e' }}>{userLevel.rewards.xlm.toFixed(4)}</p>
        </div>
      </div>

      {/* Açılan İçerik */}
      <div className="grid grid-cols-1 gap-4">
        {/* Desteler */}
        <div className="p-4 rounded-lg" style={{ background: MysticTarotTheme.colors.secondary }}>
          <p className="text-sm font-semibold mb-2" style={{ color: MysticTarotTheme.colors.highlight }}>📚 Desteler</p>
          <ul className="text-xs space-y-1" style={{ color: MysticTarotTheme.colors.text }}>
            {userLevel.unlockedDecks.map((deck, i) => (
              <li key={i} className="opacity-80">✓ {deck}</li>
            ))}
          </ul>
        </div>

        {/* Temalar */}
        <div className="p-4 rounded-lg" style={{ background: MysticTarotTheme.colors.secondary }}>
          <p className="text-sm font-semibold mb-2" style={{ color: MysticTarotTheme.colors.highlight }}>🎨 Temalar</p>
          <ul className="text-xs space-y-1" style={{ color: MysticTarotTheme.colors.text }}>
            {userLevel.unlockedThemes.map((theme, i) => (
              <li key={i} className="opacity-80">✓ {theme}</li>
            ))}
          </ul>
        </div>

        {/* Kategoriler */}
        <div className="p-4 rounded-lg" style={{ background: MysticTarotTheme.colors.secondary }}>
          <p className="text-sm font-semibold mb-2" style={{ color: MysticTarotTheme.colors.highlight }}>📖 Kategoriler</p>
          <ul className="text-xs space-y-1" style={{ color: MysticTarotTheme.colors.text }}>
            {userLevel.unlockedCategories.map((cat, i) => (
              <li key={i} className="opacity-80">✓ {cat}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
