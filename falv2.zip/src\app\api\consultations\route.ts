import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

// GET /api/consultations - Danışmaları listele (witchId filtresiyle)
export async function GET(request: NextRequest) {
  try {
    const witchId = request.nextUrl.searchParams.get('witchId');
    const userAddress = request.nextUrl.searchParams.get('userAddress');

    let query = supabase.from('consultations').select('*');

    if (witchId) {
      query = query.eq('witch_id', witchId);
    }
    if (userAddress) {
      query = query.eq('user_address', userAddress);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    console.error('Danışmalar yüklenemedi:', error);
    return NextResponse.json({ error: 'Danışmalar yüklenemedi' }, { status: 500 });
  }
}

// POST /api/consultations - Danışma isteği oluştur
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userAddress, witchId, question } = body;

    if (!userAddress || !witchId || !question) {
      return NextResponse.json(
        { error: 'Tüm alanlar zorunlu' },
        { status: 400 }
      );
    }

    const { data, error } = await supabase
      .from('consultations')
      .insert([{
        user_address: userAddress,
        witch_id: witchId,
        question,
        status: 'pending'
      }])
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    console.error('Danışma oluşturma hatası:', error);
    return NextResponse.json({ error: 'Danışma oluşturulamadı' }, { status: 500 });
  }
}
