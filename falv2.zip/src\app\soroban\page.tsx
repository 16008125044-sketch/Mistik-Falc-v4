'use client';

import { SorobanProvider } from '@/components/SorobanFortuneContract/SorobanProvider';
import { FortuneTellerUI } from '@/components/SorobanFortuneContract/FortuneTellerUI';

export default function SorobanFortunePage() {
  return (
    <SorobanProvider>
      <FortuneTellerUI />
    </SorobanProvider>
  );
}
