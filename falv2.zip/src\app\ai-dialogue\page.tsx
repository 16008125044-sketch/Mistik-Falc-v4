'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useFreighter } from '@/components/FreighterProvider';
import { supabase } from '@/lib/supabase';

interface Conversation {
  id: string;
  user_address: string;
  title: string;
  created_at: string;
  updated_at: string;
}

interface Message {
  id: string;
  conversation_id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: number;
  created_at: string;
}

const QUESTION_COST = 20;

export default function AIDialoguePage() {
  const { address, balance } = useFreighter();
  
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isAIThinking, setIsAIThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Konuşmaları yükle
  const loadConversations = async () => {
    try {
      const { data, error: err } = await supabase
        .from('conversations')
        .select('*')
        .order('updated_at', { ascending: false });

      if (err) throw err;
      setConversations(data || []);
    } catch (err) {
      console.error('Konuşmalar yüklenemedi:', err);
    }
  };

  // Mesajları yükle
  const loadMessages = async (conversationId: string) => {
    try {
      const { data, error: err } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('timestamp', { ascending: true });

      if (err) throw err;
      setMessages(data || []);
      
      // Scroll to bottom
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err) {
      console.error('Mesajlar yüklenemedi:', err);
    }
  };

  // Sayfa yüklendiğinde konuşmaları getir
  useEffect(() => {
    if (address) {
      loadConversations();
      const interval = setInterval(loadConversations, 5000);
      return () => clearInterval(interval);
    }
  }, [address]);

  // Konuşma seçilince mesajları yükle
  useEffect(() => {
    if (selectedConversation) {
      loadMessages(selectedConversation.id);
      const interval = setInterval(() => loadMessages(selectedConversation.id), 3000);
      return () => clearInterval(interval);
    }
  }, [selectedConversation]);

  // AI cevabını al
  const getAIResponse = async (userMessage: string, conversationHistory: Message[]): Promise<string> => {
    try {
      // Konuşma bağlamını oluştur
      const context = conversationHistory
        .map(msg => `${msg.sender === 'user' ? 'Kullanıcı' : 'AI'}: ${msg.content}`)
        .join('\n');

      const response = await fetch('/api/ai-answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          question: userMessage,
          context: context
        }),
      });

      if (!response.ok) throw new Error('AI cevap alınamadı');
      
      const data = await response.json();
      return data.answer || 'Üzgünüm, anlayamadım. Lütfen tekrar deneyin.';
    } catch (err) {
      console.error('AI hatası:', err);
      return 'Sistemde bir hata oluştu. Lütfen daha sonra deneyin.';
    }
  };

  // Yeni konuşma başlat
  const startNewConversation = async () => {
    if (!address) return;

    try {
      const { data, error: err } = await supabase
        .from('conversations')
        .insert([{
          user_address: address,
          title: 'Yeni Konuşma',
        }])
        .select()
        .single();

      if (err) throw err;

      setSelectedConversation(data);
      setMessages([]);
      await loadConversations();
    } catch (err) {
      setError('Konuşma başlatılamadı: ' + (err instanceof Error ? err.message : 'Bilinmeyen'));
    }
  };

  // Mesaj gönder
  const handleSendMessage = async () => {
    if (!selectedConversation || !newMessage.trim()) {
      setError('Lütfen bir mesaj yazınız');
      return;
    }

    const balanceNum = typeof balance === 'string' ? parseFloat(balance) : (balance || 0);
    if (balanceNum < QUESTION_COST) {
      setError('Yetersiz bakiye. En az ' + QUESTION_COST + ' XLM gerekli');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Kullanıcı mesajını kaydet
      const userMessageData = {
        conversation_id: selectedConversation.id,
        sender: 'user' as const,
        content: newMessage.trim(),
        timestamp: Date.now(),
      };

      const { data: userMsg, error: userErr } = await supabase
        .from('messages')
        .insert([userMessageData])
        .select()
        .single();

      if (userErr) throw userErr;

      setMessages(prev => [...prev, userMsg]);
      setNewMessage('');

      // AI'yı düşünmeye koy
      setIsAIThinking(true);

      // AI cevabını al
      const aiResponse = await getAIResponse(newMessage.trim(), [...messages, userMsg]);

      // AI mesajını kaydet
      const aiMessageData = {
        conversation_id: selectedConversation.id,
        sender: 'ai' as const,
        content: aiResponse,
        timestamp: Date.now(),
      };

      const { data: aiMsg, error: aiErr } = await supabase
        .from('messages')
        .insert([aiMessageData])
        .select()
        .single();

      if (aiErr) throw aiErr;

      setMessages(prev => [...prev, aiMsg]);

      // Konuşmanın updated_at'ını güncelle
      await supabase
        .from('conversations')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', selectedConversation.id);

      setSuccess('Mesaj gönderildi');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('Hata: ' + (err instanceof Error ? err.message : 'Bilinmeyen'));
    } finally {
      setIsLoading(false);
      setIsAIThinking(false);
    }
  };

  if (!address) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-purple-300 mb-4">Diyalog için cüzdan bağlayınız.</p>
          <Link href="/" className="text-blue-400 hover:text-blue-300 underline">
            Ana sayfaya dön
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-6xl mx-auto h-[calc(100vh-100px)]">
        {error && <div className="mb-4 p-4 rounded-lg bg-red-500/20 text-red-300">{error}</div>}
        {success && <div className="mb-4 p-4 rounded-lg bg-green-500/20 text-green-300">{success}</div>}

        <div className="mb-6">
          <Link href="/" className="text-purple-400 mb-4 inline-block">← Ana Sayfa</Link>
          <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text">
            💬 Yapay Zeka ile Diyalog
          </h1>
          <p className="text-slate-300 mt-2">Devam eden bir konuşma başlatın ve yapay zeka ile sohbet edin</p>
        </div>

        <div className="grid md:grid-cols-4 gap-6 h-[calc(100%-150px)]">
          {/* Sol panel - Konuşmalar */}
          <div className="md:col-span-1 bg-purple-950/50 border border-purple-500/50 rounded-xl p-4 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-purple-300">💬 Konuşmalar</h2>
              <button
                onClick={startNewConversation}
                className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-lg"
              >
                +
              </button>
            </div>

            <div className="space-y-2 overflow-y-auto flex-1">
              {conversations.length === 0 ? (
                <p className="text-slate-400 text-sm">Henüz konuşma yok</p>
              ) : (
                conversations.map(conv => (
                  <button
                    key={conv.id}
                    onClick={() => setSelectedConversation(conv)}
                    className={`w-full p-3 rounded-lg text-left text-sm transition ${
                      selectedConversation?.id === conv.id 
                        ? 'bg-purple-600 text-white' 
                        : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <div className="truncate font-medium">{conv.title}</div>
                    <div className="text-xs opacity-75">
                      {new Date(conv.updated_at).toLocaleDateString('tr-TR')}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Sağ panel - Mesajlar */}
          <div className="md:col-span-3 bg-purple-950/50 border border-purple-500/50 rounded-xl p-6 flex flex-col overflow-hidden">
            {selectedConversation ? (
              <>
                {/* Konuşma başlığı */}
                <div className="mb-4 pb-4 border-b border-purple-500/30">
                  <h2 className="text-xl font-bold text-purple-300">{selectedConversation.title}</h2>
                  <p className="text-xs text-slate-400">
                    Başlatıldı: {new Date(selectedConversation.created_at).toLocaleDateString('tr-TR')}
                  </p>
                </div>

                {/* Mesajlar */}
                <div className="flex-1 overflow-y-auto mb-4 space-y-3">
                  {messages.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-slate-400">
                      <p>Konuşmayı başlatmak için bir mesaj yazınız</p>
                    </div>
                  ) : (
                    messages.map(msg => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                            msg.sender === 'user'
                              ? 'bg-blue-600 text-white rounded-br-none'
                              : 'bg-slate-700 text-slate-100 rounded-bl-none'
                          }`}
                        >
                          <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                          <p className="text-xs opacity-60 mt-1">
                            {new Date(msg.timestamp).toLocaleTimeString('tr-TR', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </p>
                        </div>
                      </div>
                    ))
                  )}

                  {isAIThinking && (
                    <div className="flex justify-start">
                      <div className="bg-slate-700 text-slate-100 px-4 py-2 rounded-lg rounded-bl-none">
                        <div className="flex space-x-2">
                          <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </div>

                {/* Bakiye ve İleti Gönderme */}
                <div className="border-t border-purple-500/30 pt-4">
                  <div className="mb-3 p-3 bg-slate-800/50 rounded-lg text-sm text-slate-300">
                    <div>💰 Bakiye: <span className="text-yellow-400 font-bold">{typeof balance === 'string' ? parseFloat(balance).toFixed(2) : balance} XLM</span></div>
                    <div>💸 Mesaj Ücreti: <span className="text-orange-400">{QUESTION_COST} XLM</span></div>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSendMessage()}
                      placeholder="Mesajınızı yazınız..."
                      disabled={isLoading}
                      className="flex-1 px-4 py-2 rounded-lg bg-slate-800 text-white border border-purple-500/50 focus:border-purple-400 focus:outline-none disabled:opacity-50"
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() || isLoading || isAIThinking}
                      className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-slate-600 text-white font-bold rounded-lg transition"
                    >
                      {isLoading ? '📤' : '✈️'}
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <p className="text-slate-400 mb-4">Konuşma seçiniz veya yeni başlatınız</p>
                  <button
                    onClick={startNewConversation}
                    className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-bold"
                  >
                    + Yeni Konuşma
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
