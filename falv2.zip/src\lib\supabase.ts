import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface ConsultationQuestion {
  id: string;
  asker: string;
  question: string;
  timestamp: number;
  answer?: string;
  answerer?: string;
  answered_at?: number;
  created_at?: string;
  updated_at?: string;
}

export interface UserProfile {
  id: string;
  wallet_address: string;
  name: string;
  profile_image: string | null;
  is_premium: boolean;
  is_witch: boolean;
  is_banned?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface WitchConsultation {
  id: string;
  witch_address: string;
  client_address: string;
  message: string;
  timestamp: number;
  response?: string;
  responded_at?: number;
  created_at?: string;
  updated_at?: string;
}
