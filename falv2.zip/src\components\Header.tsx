'use client';

import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useProfile } from './ProfileProvider';
import { useFreighter } from './FreighterProvider';

export function HeaderWrapper() {
  const router = useRouter();
  const { isAdmin } = useProfile();
  const { isConnected } = useFreighter();

  return (
    <header className="bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <div 
            className="cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => router.push('/')}
          >
            <h1 className="text-3xl font-bold">✨ Mistik Falcı</h1>
            <p className="text-purple-100 text-sm">Freighter ile Kozmik Enerji Deneyimi</p>
          </div>
          

        </div>
      </div>
    </header>
  );
}
