'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

interface WitchApplication {
  id: string;
  applicant_address: string;
  name: string;
  bio: string;
  specialties: string[];
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

export default function AdminWitchesPage() {
  const router = useRouter();
  const [userAddress, setUserAddress] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [applications, setApplications] = useState<WitchApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [selectedApp, setSelectedApp] = useState<WitchApplication | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [modalAction, setModalAction] = useState<'approve' | 'reject' | null>(null);

  useEffect(() => {
    checkAdmin();
  }, []);

  const checkAdmin = async () => {
    try {
      // Freighter'dan cüzdan adresi al
      if (typeof window !== 'undefined' && (window as any).freighter) {
        const publicKey = await (window as any).freighter.getPublicKey();
        setUserAddress(publicKey);

        // Admin tablosunda kontrol et
        const { data } = await supabase
          .from('admins')
          .select('*')
          .eq('wallet_address', publicKey)
          .single();

        if (data) {
          setIsAdmin(true);
          loadApplications();
        } else {
          alert('❌ Admin erişimi yok!');
          router.push('/');
        }
      } else {
        alert('❌ Freighter cüzdanı bulunamadı!');
        router.push('/');
      }
    } catch (err) {
      console.error('Admin check hatası:', err);
      alert('❌ Cüzdan bağlantı hatası!');
      router.push('/');
    } finally {
      setLoading(false);
    }
  };

  const loadApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('witch_applications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (err) {
      console.error('Başvurular yüklenemedi:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (app: WitchApplication) => {
    setProcessing(true);
    try {
      // Güncelle başvuru durumunu
      const { error: updateErr } = await supabase
        .from('witch_applications')
        .update({
          status: 'approved',
          reviewed_at: new Date().toISOString()
        })
        .eq('id', app.id);

      if (updateErr) {
        console.error('Update hatası:', updateErr);
        throw updateErr;
      }

      // Cadıyı user_profiles'e ekle (sadece gerekli alanlar)
      const { error: profileErr } = await supabase
        .from('user_profiles')
        .upsert({
          wallet_address: app.applicant_address,
          name: app.name,
          is_witch: true
        }, {
          onConflict: 'wallet_address'
        });

      if (profileErr) {
        console.error('Profile hatası:', profileErr);
        throw profileErr;
      }

      setApplications(applications.map(a => 
        a.id === app.id ? { ...a, status: 'approved' } : a
      ));
      setSelectedApp(null);
      alert('✅ Başvuru onaylandı!');
    } catch (err) {
      console.error('Approve hatası:', err);
      alert('❌ Hata: ' + (err instanceof Error ? err.message : 'Bilinmeyen'));
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async (app: WitchApplication) => {
    setProcessing(true);
    try {
      const { error } = await supabase
        .from('witch_applications')
        .update({
          status: 'rejected',
          reviewed_at: new Date().toISOString()
        })
        .eq('id', app.id);

      if (error) throw error;

      setApplications(applications.map(a => 
        a.id === app.id ? { ...a, status: 'rejected' } : a
      ));
      setSelectedApp(null);
      alert('❌ Başvuru reddedildi!');
    } catch (err) {
      console.error('Reject hatası:', err);
      alert('❌ Hata: ' + (err instanceof Error ? err.message : 'Bilinmeyen'));
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <p className="text-purple-300">Admin kontrolü yapılıyor...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="text-purple-400 hover:text-purple-300 mb-4 inline-block">
            ← Ana Sayfaya Dön
          </Link>
          <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text mb-2">
            🧙‍♀️ Cadı Başvuru Yönetimi
          </h1>
          <p className="text-slate-300">
            Toplam: {applications.length} | Beklemede: {applications.filter(a => a.status === 'pending').length}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Başvurular Listesi */}
          <div className="md:col-span-1">
            <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6 max-h-[700px] overflow-y-auto">
              <h2 className="text-xl font-bold text-purple-300 mb-4">📋 Başvurular</h2>

              <div className="space-y-2">
                {applications.length === 0 ? (
                  <p className="text-slate-400 text-sm">Başvuru yok</p>
                ) : (
                  applications.map((app) => (
                    <button
                      key={app.id}
                      onClick={() => setSelectedApp(app)}
                      className={`w-full p-3 rounded-lg text-left text-sm transition border ${
                        selectedApp?.id === app.id
                          ? 'bg-purple-600 border-purple-400 text-white'
                          : app.status === 'pending'
                          ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300 hover:bg-yellow-500/30'
                          : app.status === 'approved'
                          ? 'bg-green-500/20 border-green-500/50 text-green-300'
                          : 'bg-red-500/20 border-red-500/50 text-red-300'
                      }`}
                    >
                      <div className="font-semibold">{app.name}</div>
                      <div className="text-xs opacity-75">{app.applicant_address.slice(0, 10)}...</div>
                      <div className="text-xs mt-1">
                        {app.status === 'pending' && '⏳ Beklemede'}
                        {app.status === 'approved' && '✅ Onaylandı'}
                        {app.status === 'rejected' && '❌ Reddedildi'}
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Detay ve İşlemler */}
          <div className="md:col-span-2">
            {selectedApp ? (
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6">
                <h2 className="text-2xl font-bold text-purple-300 mb-6">{selectedApp.name}</h2>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="text-sm text-slate-400">Cüzdan Adresi:</label>
                    <p className="text-white font-mono text-sm break-all">{selectedApp.applicant_address}</p>
                  </div>

                  <div>
                    <label className="text-sm text-slate-400">Biyografi:</label>
                    <p className="text-slate-300 mt-1">{selectedApp.bio}</p>
                  </div>

                  <div>
                    <label className="text-sm text-slate-400">Uzmanlık Alanları:</label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {selectedApp.specialties.map((spec) => (
                        <span key={spec} className="px-3 py-1 rounded-lg bg-purple-600/30 text-purple-300 text-sm border border-purple-500/50">
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm text-slate-400">Başvuru Tarihi:</label>
                    <p className="text-slate-300">{new Date(selectedApp.created_at).toLocaleDateString('tr-TR')}</p>
                  </div>

                  <div>
                    <label className="text-sm text-slate-400">Durum:</label>
                    <p className="text-slate-300 mt-1">
                      {selectedApp.status === 'pending' && '⏳ Beklemede'}
                      {selectedApp.status === 'approved' && '✅ Onaylandı'}
                      {selectedApp.status === 'rejected' && '❌ Reddedildi'}
                    </p>
                  </div>
                </div>

                {selectedApp.status === 'pending' && (
                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        setModalAction('approve');
                        setShowModal(true);
                      }}
                      disabled={processing}
                      className="flex-1 px-4 py-3 bg-green-600 hover:bg-green-700 disabled:bg-slate-600 text-white font-bold rounded-lg transition"
                    >
                      {processing ? '⏳ İşleniyor...' : '✅ Onayla'}
                    </button>
                    <button
                      onClick={() => {
                        setModalAction('reject');
                        setShowModal(true);
                      }}
                      disabled={processing}
                      className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 disabled:bg-slate-600 text-white font-bold rounded-lg transition"
                    >
                      {processing ? '⏳ İşleniyor...' : '❌ Reddet'}
                    </button>
                  </div>
                )}

                {selectedApp.status !== 'pending' && (
                  <div className="text-center text-slate-400 py-3">
                    Bu başvuru zaten işlenmiş
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6 h-64 flex items-center justify-center text-center text-slate-400">
                Detayları görmek için bir başvuru seçin
              </div>
            )}
          </div>
        </div>

        {/* Modal */}
        {showModal && selectedApp && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
            <div className="bg-gradient-to-b from-purple-950 to-indigo-950 border border-purple-500/50 rounded-xl p-6 max-w-md w-full">
              <h3 className="text-2xl font-bold text-purple-300 mb-4">
                {modalAction === 'approve' ? '✅ Onayla' : '❌ Reddet'}
              </h3>
              <p className="text-slate-300 mb-2">
                <strong>{selectedApp.name}</strong> başvurusunu{' '}
                {modalAction === 'approve' ? 'onaylamak' : 'reddetmek'} istediğine emin misin?
              </p>
              <p className="text-slate-400 text-sm mb-6">
                ({selectedApp.applicant_address.slice(0, 10)}...)
              </p>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowModal(false);
                    setModalAction(null);
                  }}
                  className="flex-1 px-4 py-2 bg-slate-600 hover:bg-slate-700 text-white font-bold rounded-lg transition"
                >
                  İptal
                </button>
                <button
                  onClick={async () => {
                    if (modalAction === 'approve') {
                      await handleApprove(selectedApp);
                    } else {
                      await handleReject(selectedApp);
                    }
                    setShowModal(false);
                    setModalAction(null);
                  }}
                  disabled={processing}
                  className={`flex-1 px-4 py-2 text-white font-bold rounded-lg transition ${
                    modalAction === 'approve'
                      ? 'bg-green-600 hover:bg-green-700 disabled:bg-slate-600'
                      : 'bg-red-600 hover:bg-red-700 disabled:bg-slate-600'
                  }`}
                >
                  {processing ? '⏳ İşleniyor...' : 'Evet, Onayla'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

