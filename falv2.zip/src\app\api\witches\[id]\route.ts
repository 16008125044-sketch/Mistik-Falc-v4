import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

// PUT /api/witches/:id - Cadıyı güncelle
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const { name, description, avatarUrl, walletAddress, categories } = body;

    const { data, error } = await supabase
      .from('witches')
      .update({
        name,
        description,
        avatar_url: avatarUrl,
        wallet_address: walletAddress,
        categories,
        updated_at: new Date().toISOString()
      })
      .eq('id', params.id)
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json(data);
  } catch (error) {
    console.error('Cadı güncelleme hatası:', error);
    return NextResponse.json({ error: 'Cadı güncellenemedi' }, { status: 500 });
  }
}

// DELETE /api/witches/:id - Cadıyı sil
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { error } = await supabase
      .from('witches')
      .delete()
      .eq('id', params.id);

    if (error) throw error;
    return NextResponse.json({ message: 'Cadı silindi' });
  } catch (error) {
    console.error('Cadı silme hatası:', error);
    return NextResponse.json({ error: 'Cadı silinemedi' }, { status: 500 });
  }
}
