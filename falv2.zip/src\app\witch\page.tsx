'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useFreighter } from '@/components/FreighterProvider';
import { MysticTarotTheme } from '@/components/mystic_tarot_theme';
import { useLevel } from '@/components/LevelProvider';

export default function WitchPage() {
  const { userLevel, addReading } = useLevel();
  const { address } = useFreighter();
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [canConsult, setCanConsult] = useState(true);
  const [nextConsultTime, setNextConsultTime] = useState<Date | null>(null);

  const witchMessages = [
    '🔮 Ah, hoş geldin! Geleceğini okumaya hazır mısın?',
    '✨ Kaynayan kazanım içinde görmek istediğin nedir?',
    '🌙 Ay ışığı altında sırlarını paylaşabilirsin...',
    '💫 Kaderinin ipliğini çözmek mi istiyorsun?',
    '🕷️ Büyüyle oynan, ama dikkat et. Her şeyin bir bedeli var.',
    '🌑 Karanlıktaki gerçeği görmek cesur misin?',
    '⚡ Evrenin enerjisi seni arıyor. Dinlemeye hazır mısın?',
    '👁️ Üçüncü gözümle seni görebilirim. Korkma.',
    '🧿 Kötü göz seni korumaz. Yalnızca bilgi kurtarır.',
    '🔥 Ateşten geçtiysen, buz korkutamaz seni.',
  ];

  useEffect(() => {
    const randomMessage = witchMessages[Math.floor(Math.random() * witchMessages.length)];
    setMessage(randomMessage);

    // Check cooldown status
    if (address) {
      const lastConsultKey = `witch_consult_${address}`;
      const lastConsultTime = localStorage.getItem(lastConsultKey);

      if (lastConsultTime) {
        const lastTime = new Date(lastConsultTime);
        const now = new Date();
        const diffMs = now.getTime() - lastTime.getTime();
        const diffHours = diffMs / (1000 * 60 * 60);

        if (diffHours < 24) {
          setCanConsult(false);
          // Calculate next available time
          const nextTime = new Date(lastTime.getTime() + 24 * 60 * 60 * 1000);
          setNextConsultTime(nextTime);
        } else {
          setCanConsult(true);
          setNextConsultTime(null);
        }
      } else {
        setCanConsult(true);
        setNextConsultTime(null);
      }
    }
  }, [address]);

  const handleConsultation = async () => {
    if (!canConsult) {
      alert('⏳ Cadı şu anda meşgul. Lütfen 24 saat sonra tekrar gel.');
      return;
    }

    setIsLoading(true);
    
    // Save consultation time
    if (address) {
      localStorage.setItem(`witch_consult_${address}`, new Date().toISOString());
    }

    // Cadıya danışmak 50 EXP verir (cadı rozetine sahip olanlar)
    await addReading(1);
    
    const witchAdvice = [
      '🔮 Ruh kütüphanesinde bir sayfa açıldı. Bir kart çek ve yanıtını bul.',
      '✨ Evrenin size göndermek istediği mesaj: Sabır erdemdir.',
      '🌙 Ay döngüsü seni iyileştiriyor. Üç ay bekle, tüm değişecek.',
      '💫 Karanlık ve ışık arasında sen seçimi yapıyorsun. Hangi tarafa?',
      '🕷️ Dokudığün ağda kendine yakalanma. Özgürlük talep et.',
      '🌑 Siyah ve beyaz yoktur, sadece gri vardır. Orta yolun bilgesi ol.',
      '⚡ Göklerdeki şimşek senin enerjin. Onu dünya fark edecek.',
      '👁️ Gördüğün her şey gerçek değildir. Hissettiğin tek gerçektir.',
      '🧿 Düşmanlarından korkma, kendi gölgenden kork.',
      '🔥 Yangından çıktıysan, öl gerekse de, yanmazsın.',
    ];
    
    setTimeout(() => {
      const randomAdvice = witchAdvice[Math.floor(Math.random() * witchAdvice.length)];
      alert(randomAdvice);
      setCanConsult(false);
      setNextConsultTime(new Date(new Date().getTime() + 24 * 60 * 60 * 1000));
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen" style={{ background: MysticTarotTheme.colors.background }}>
      {/* Başlık */}
      <div className="bg-gradient-to-r from-purple-900 to-black text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <h1 className="text-5xl font-bold mb-2">🧙‍♀️ Cadıya Uğra</h1>
          <p className="text-purple-200 text-lg">Gizemli bilen kadın seni bekliyor...</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Cadının Hücresi */}
        <div
          className="rounded-2xl shadow-2xl p-12 border-2 mb-8 text-center"
          style={{
            background: `linear-gradient(135deg, rgba(88, 28, 135, 0.3), rgba(20, 20, 40, 0.5))`,
            borderColor: '#9333ea',
          }}
        >
          {/* Cadı Avatar */}
          <div className="text-8xl mb-6 animate-pulse">🧙‍♀️</div>

          {/* Mesaj */}
          <p
            className="text-2xl font-bold mb-8 leading-relaxed"
            style={{ color: '#e879f9' }}
          >
            {message}
          </p>

          {/* Bilgi */}
          <div className="mb-8 space-y-3">
            <p style={{ color: MysticTarotTheme.colors.text }} className="text-lg">
              Cadıdan danışmak için tükünü kaması lazım...
            </p>
            {canConsult ? (
              <p style={{ color: '#fbbf24' }} className="text-xl font-semibold">
                💫 +50 EXP kazanacaksın (24 saatte bir)
              </p>
            ) : (
              <div>
                <p style={{ color: '#ef4444' }} className="text-xl font-semibold mb-2">
                  ⏳ Cadı şu anda meşgul
                </p>
                {nextConsultTime && (
                  <p style={{ color: '#fbbf24' }} className="text-sm">
                    Sonraki danışma: {nextConsultTime.toLocaleTimeString('tr-TR')} ({nextConsultTime.toLocaleDateString('tr-TR')})
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Danışma Butonu */}
          <button
            onClick={handleConsultation}
            disabled={isLoading || !canConsult}
            className="px-8 py-4 rounded-lg font-bold text-lg hover:opacity-80 transition disabled:opacity-50 mb-6"
            style={{
              background: canConsult ? 'linear-gradient(135deg, #9333ea, #7c3aed)' : '#6b7280',
              color: 'white',
            }}
          >
            {isLoading ? '⏳ Cadı Danışıyor...' : canConsult ? '✨ Cadıdan Danış (50 EXP)' : '⏳ 24 Saat Bekle'}
          </button>
        </div>

        {/* Cadı Hakkında */}
        <div
          className="rounded-xl shadow-xl p-8 border mb-8"
          style={{
            background: MysticTarotTheme.colors.secondary,
            borderColor: '#9333ea',
          }}
        >
          <h2 className="text-2xl font-bold mb-4" style={{ color: '#e879f9' }}>
            🔮 Cadı Kimdir?
          </h2>
          <p style={{ color: MysticTarotTheme.colors.text }} className="mb-4 leading-relaxed">
            Ormanda yaşayan gizemli kadın. Bin yıl yaşadığı söylenir. Gözlerinde evrenin sırları
            vardır. Kime gelirse, o kişinin kaderini okur. Hiç yanılmaz, ama söylenenleri anlamak
            kişinin zekasıyla ölçülür.
          </p>
          <p style={{ color: MysticTarotTheme.colors.text }} className="mb-4 leading-relaxed">
            Cadı parası almaz, ama danışan hep bir şey kaybeder. Bazen şansa, bazen umuda, bazen
            eski sevgiye. Ama aldığını veriş, her zaman almış olduğundan daha değerli bir şey.
          </p>
          <p style={{ color: '#fbbf24' }} className="font-semibold">
            ⚠️ Uyarı: Cadının sözleri mutlak gerçektir, ama anlamı her zaman açık değildir.
          </p>
        </div>

        {/* İstatistikler */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div
            className="rounded-lg p-6 text-center"
            style={{ background: 'rgba(168, 85, 247, 0.1)', borderLeft: '4px solid #a855f7' }}
          >
            <p style={{ color: MysticTarotTheme.colors.text }} className="text-sm mb-2">
              Seninle Aynı Seviyede
            </p>
            <p className="text-3xl font-bold" style={{ color: '#a855f7' }}>
              {userLevel?.level || 1}
            </p>
          </div>
          <div
            className="rounded-lg p-6 text-center"
            style={{ background: 'rgba(251, 191, 36, 0.1)', borderLeft: '4px solid #fbbf24' }}
          >
            <p style={{ color: MysticTarotTheme.colors.text }} className="text-sm mb-2">
              Kazanacağın EXP
            </p>
            <p className="text-3xl font-bold" style={{ color: '#fbbf24' }}>
              +50 EXP
            </p>
          </div>
        </div>

        {/* Geri Dön */}
        <div className="text-center">
          <Link
            href="/"
            className="px-6 py-3 rounded-lg font-semibold hover:opacity-80 transition inline-block"
            style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
          >
            ← Ana Sayfaya Dön
          </Link>
        </div>
      </div>
    </div>
  );
}
