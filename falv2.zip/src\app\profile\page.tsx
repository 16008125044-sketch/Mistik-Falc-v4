'use client';

import React, { useState, useRef } from 'react';
import Link from 'next/link';
import { useProfile } from '@/components/ProfileProvider';
import { useLevel } from '@/components/LevelProvider';
import { useFreighter } from '@/components/FreighterProvider';
import { MysticTarotTheme } from '@/components/mystic_tarot_theme';

export default function ProfilePage() {
  const { profile, updateName, uploadProfileImage, removeProfileImage, setPremium, setWitch } = useProfile();
  const { userLevel, addPoints } = useLevel();
  const { address, balance } = useFreighter();
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(profile?.name || '');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [buyingPremium, setBuyingPremium] = useState(false);

  const handleBuyPremium = async () => {
    try {
      setBuyingPremium(true);
      const xlmBalance = parseFloat(balance) || 0;
      
      if (xlmBalance < 250) {
        alert('❌ Yetersiz XLM! Premium rozeti 250 XLM tutuyor. Cüzdanınızda: ' + xlmBalance.toFixed(4) + ' XLM');
        setBuyingPremium(false);
        return;
      }
      
      // Premium satın alma işlemini simüle et
      setTimeout(() => {
        setPremium(true);
        alert('✅ Premium rozeti başarıyla satın aldınız! 👑');
        setBuyingPremium(false);
      }, 500);
    } catch (error) {
      alert('Hata: ' + (error as Error).message);
      setBuyingPremium(false);
    }
  };

  const handleBuyWitch = () => {
    setShowInterviewModal(true);
  };

  const handleInterviewSuccess = () => {
    setWitch(true);
    alert('✅ Tebrikler! Artık sen de bir Cadısın! 🧙‍♀️\n\n👑 Cadı Rozeti Avantajları:\n💫 Diğer kullanıcılara tavsiye vererek +50 EXP kazan\n✨ İnsanları dinlemeyi ve rehberlik etmeyi öğren\n🔮 Mistik bilgelik senin rehberin');
  };

  const handleSaveName = async () => {
    if (nameInput.trim()) {
      await updateName(nameInput);
      setEditingName(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      try {
        await uploadProfileImage(e.target.files[0]);
      } catch (error) {
        console.error('Resim yükleme hatası:', error);
      }
    }
  };

  const handleRemoveImage = async () => {
    await removeProfileImage();
  };

  if (!profile || !userLevel) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: MysticTarotTheme.colors.background }}>
        <p style={{ color: MysticTarotTheme.colors.text }}>Yükleniyor...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: MysticTarotTheme.colors.background }}>
      {/* Başlık */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold">👤 Profilim</h1>
          <p className="text-purple-100 mt-2">Profil bilgilerinizi düzenleyin</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Profil Kartı */}
        <div 
          className="rounded-2xl shadow-2xl p-8 mb-8 border-2"
          style={{ 
            background: `linear-gradient(135deg, ${MysticTarotTheme.colors.secondary}, ${MysticTarotTheme.colors.background})`,
            borderColor: MysticTarotTheme.colors.primary
          }}
        >
          <div className="flex flex-col md:flex-row gap-8 items-start">
            {/* Profil Fotoğrafı */}
            <div className="flex flex-col items-center">
              <div 
                className="w-40 h-40 rounded-2xl shadow-lg border-4 flex items-center justify-center cursor-pointer hover:opacity-80 transition overflow-hidden"
                style={{ borderColor: MysticTarotTheme.colors.primary, background: 'rgba(124, 58, 237, 0.2)' }}
                onClick={() => fileInputRef.current?.click()}
              >
                {profile.profileImage ? (
                  <img src={profile.profileImage} alt="Profil" className="w-full h-full object-cover" />
                ) : (
                  <div className="text-6xl">📸</div>
                )}
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />

              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 rounded-lg font-semibold hover:opacity-80 transition text-sm"
                  style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
                >
                  Yükle
                </button>
                {profile.profileImage && (
                  <button
                    onClick={handleRemoveImage}
                    className="px-4 py-2 rounded-lg font-semibold hover:opacity-80 transition text-sm"
                    style={{ background: '#dc2626', color: 'white' }}
                  >
                    Sil
                  </button>
                )}
              </div>
            </div>

            {/* Bilgiler */}
            <div className="flex-1">
              {/* İsim */}
              <div className="mb-6">
                <p className="text-sm opacity-70 mb-2" style={{ color: MysticTarotTheme.colors.text }}>
                  Adınız
                </p>
                {editingName ? (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="flex-1 px-4 py-2 rounded-lg bg-black/40 border border-purple-500 focus:outline-none"
                      style={{ color: MysticTarotTheme.colors.text }}
                    />
                    <button
                      onClick={handleSaveName}
                      className="px-4 py-2 rounded-lg font-semibold"
                      style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
                    >
                      Kaydet
                    </button>
                    <button
                      onClick={() => {
                        setEditingName(false);
                        setNameInput(profile.name);
                      }}
                      className="px-4 py-2 rounded-lg font-semibold"
                      style={{ background: '#666', color: 'white' }}
                    >
                      İptal
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <h2 className="text-3xl font-bold" style={{ color: MysticTarotTheme.colors.highlight }}>
                      {profile.name} {profile.isPremium && '👑'}
                    </h2>
                    <button
                      onClick={() => {
                        setEditingName(true);
                        setNameInput(profile.name);
                      }}
                      className="px-3 py-1 rounded-lg text-sm hover:opacity-80 transition"
                      style={{ background: MysticTarotTheme.colors.primary, color: 'white' }}
                    >
                      Düzenle
                    </button>
                  </div>
                )}
              </div>

              {/* Seviye Bilgisi */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg" style={{ background: 'rgba(124, 58, 237, 0.15)' }}>
                  <p className="text-sm opacity-70 mb-1" style={{ color: MysticTarotTheme.colors.text }}>Seviye</p>
                  <p className="text-3xl font-bold" style={{ color: MysticTarotTheme.colors.primary }}>
                    {userLevel.level}
                  </p>
                </div>
                <div className="p-4 rounded-lg" style={{ background: 'rgba(251, 191, 36, 0.15)' }}>
                  <p className="text-sm opacity-70 mb-1" style={{ color: MysticTarotTheme.colors.text }}>Rütbe</p>
                  <p className="text-xl font-bold" style={{ color: '#fbbf24' }}>
                    {userLevel.title}
                  </p>
                </div>
              </div>

              {/* Puanlar */}
              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="p-3 rounded-lg text-center" style={{ background: 'rgba(224, 224, 224, 0.1)' }}>
                  <p className="text-2xl mb-1">🌙</p>
                  <p className="text-xs opacity-70 mb-1" style={{ color: MysticTarotTheme.colors.text }}>Ay Işığı</p>
                  <p className="text-2xl font-bold" style={{ color: '#e0e0e0' }}>
                    {userLevel.rewards.moonlight}
                  </p>
                </div>
                <div className="p-3 rounded-lg text-center" style={{ background: 'rgba(251, 191, 36, 0.1)' }}>
                  <p className="text-2xl mb-1">⭐</p>
                  <p className="text-xs opacity-70 mb-1" style={{ color: MysticTarotTheme.colors.text }}>Yıldız</p>
                  <p className="text-2xl font-bold" style={{ color: '#fbbf24' }}>
                    {userLevel.rewards.star}
                  </p>
                </div>
                <div className="p-3 rounded-lg text-center" style={{ background: 'rgba(34, 197, 94, 0.1)' }}>
                  <p className="text-2xl mb-1">⭐</p>
                  <p className="text-xs opacity-70 mb-1" style={{ color: MysticTarotTheme.colors.text }}>XLM</p>
                  <p className="text-2xl font-bold" style={{ color: '#22c55e' }}>
                    {userLevel.rewards.xlm.toFixed(4)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Premium Rozeti */}
        {!profile.isPremium && (
          <div 
            className="rounded-xl shadow-xl p-6 border mb-8 bg-gradient-to-r from-yellow-900 to-orange-900"
            style={{ borderColor: '#fbbf24' }}
          >
            <h3 className="text-lg font-bold mb-2" style={{ color: '#fbbf24' }}>
              👑 Premium Rozeti
            </h3>
            <p className="text-sm mb-4" style={{ color: '#e0e0e0' }}>
              Premium rozetine sahip olarak rare kartları normal kullanıcılara kıyasla daha fazla çıkarabilirsin!
            </p>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold" style={{ color: '#fbbf24' }}>
                250 XLM
              </div>
              <button
                onClick={handleBuyPremium}
                disabled={buyingPremium || parseFloat(balance) < 250}
                className="px-6 py-3 rounded-lg font-bold hover:opacity-80 transition disabled:opacity-50"
                style={{ background: '#fbbf24', color: '#000' }}
              >
                {buyingPremium ? 'Satın Alınıyor...' : '✨ Premium Satın Al'}
              </button>
            </div>
          </div>
        )}
        {profile.isPremium && (
          <div 
            className="rounded-xl shadow-xl p-6 border mb-8 bg-gradient-to-r from-yellow-900 to-orange-900"
            style={{ borderColor: '#fbbf24' }}
          >
            <h3 className="text-lg font-bold" style={{ color: '#fbbf24' }}>
              👑 Premium Üye Avantajları
            </h3>
            <p className="text-sm mt-2" style={{ color: '#e0e0e0' }}>
              ✨ Rare kartları 2x daha fazla çıkma olasılığı
            </p>
          </div>
        )}

        {/* Cadı Rozeti Bilgisi */}
        {profile.isWitch && (
          <div 
            className="rounded-xl shadow-xl p-6 border mb-8 bg-gradient-to-r from-purple-900 to-indigo-900"
            style={{ borderColor: '#a855f7' }}
          >
            <h3 className="text-lg font-bold" style={{ color: '#a855f7' }}>
              🧙‍♀️ Cadı Avantajları
            </h3>
            <p className="text-sm mt-2" style={{ color: '#e0e0e0' }}>
              ✨ Diğer kullanıcılara tavsiye vererek +50 EXP kazan
            </p>
            <p className="text-sm mt-2" style={{ color: '#e0e0e0' }}>
              💫 İnsanları dinle ve onlara rehberlik et
            </p>
          </div>
        )}

        {/* Cüzdan Bilgisi */}
        <div 
          className="rounded-xl shadow-xl p-6 border mb-8"
          style={{ 
            background: MysticTarotTheme.colors.secondary,
            borderColor: MysticTarotTheme.colors.primary
          }}
        >
          <h3 className="text-lg font-bold mb-3" style={{ color: MysticTarotTheme.colors.text }}>
            💰 Cüzdan Bilgisi
          </h3>
          <p className="text-sm font-mono opacity-80" style={{ color: MysticTarotTheme.colors.text }}>
            {address}
          </p>
        </div>
      </div>
    </div>
  );
}
