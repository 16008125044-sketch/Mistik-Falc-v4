'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

interface WitchApplication {
  id: string;
  applicant_address: string;
  name: string;
  bio: string;
  specialties: string[];
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

export default function WitchApplicationsAdmin() {
  const [applications, setApplications] = useState<WitchApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [processing, setProcessing] = useState<string | null>(null);

  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    try {
      const { data, error: err } = await supabase
        .from('witch_applications')
        .select('*')
        .order('created_at', { ascending: false });

      if (err) throw err;
      setApplications(data || []);
    } catch (err) {
      setError(`Hata: ${err instanceof Error ? err.message : 'Bilinmeyen hata'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: string, applicant_address: string, app: WitchApplication) => {
    setProcessing(id);
    try {
      // Başvuruyu onaylı işaretle
      const { error: err1 } = await supabase
        .from('witch_applications')
        .update({ status: 'approved' })
        .eq('id', id);

      if (err1) throw err1;

      // Cadıyı user_profiles'e ekle
      const { error: err2 } = await supabase
        .from('user_profiles')
        .upsert({
          wallet_address: applicant_address,
          is_witch: true,
          name: app.name,
          bio: app.bio,
          specialties: app.specialties
        });

      if (err2) throw err2;

      setApplications(apps => apps.map(a => a.id === id ? { ...a, status: 'approved' } : a));
    } catch (err) {
      setError(`Onay hatası: ${err instanceof Error ? err.message : 'Bilinmeyen hata'}`);
    } finally {
      setProcessing(null);
    }
  };

  const handleReject = async (id: string) => {
    setProcessing(id);
    try {
      const { error: err } = await supabase
        .from('witch_applications')
        .update({ status: 'rejected' })
        .eq('id', id);

      if (err) throw err;

      setApplications(apps => apps.map(a => a.id === id ? { ...a, status: 'rejected' } : a));
    } catch (err) {
      setError(`Reddetme hatası: ${err instanceof Error ? err.message : 'Bilinmeyen hata'}`);
    } finally {
      setProcessing(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-purple-300">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="text-purple-400 hover:text-purple-300 mb-4 inline-block">
            ← Ana Sayfaya Dön
          </Link>
          <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text mb-2">
            🧙‍♀️ Cadı Başvuruları
          </h1>
          <p className="text-slate-300">Toplam: {applications.length} başvuru</p>
        </div>

        {error && (
          <div className="mb-4 p-4 rounded-lg bg-red-500/20 border border-red-500/50 text-red-300">
            {error}
          </div>
        )}

        {applications.length === 0 ? (
          <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-12 text-center">
            <p className="text-slate-400">Henüz başvuru yok</p>
          </div>
        ) : (
          <div className="space-y-4">
            {applications.map((app) => (
              <div
                key={app.id}
                className={`bg-purple-950/50 border rounded-xl p-6 transition ${
                  app.status === 'approved'
                    ? 'border-green-500/50 bg-green-950/20'
                    : app.status === 'rejected'
                    ? 'border-red-500/50 bg-red-950/20'
                    : 'border-purple-500/50'
                }`}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-xl font-bold text-purple-300">{app.name}</h2>
                    <p className="text-sm text-slate-400 mt-1">{app.applicant_address.slice(0, 20)}...</p>
                    <p className="text-xs text-slate-500 mt-1">
                      Başvuru: {new Date(app.created_at).toLocaleDateString('tr-TR')}
                    </p>
                  </div>
                  <div className="text-right">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-bold ${
                        app.status === 'approved'
                          ? 'bg-green-500/20 text-green-300'
                          : app.status === 'rejected'
                          ? 'bg-red-500/20 text-red-300'
                          : 'bg-yellow-500/20 text-yellow-300'
                      }`}
                    >
                      {app.status === 'approved'
                        ? '✅ Onaylandı'
                        : app.status === 'rejected'
                        ? '❌ Reddedildi'
                        : '⏳ Beklemede'}
                    </span>
                  </div>
                </div>

                <p className="text-slate-300 mb-4">{app.bio}</p>

                <div className="mb-4">
                  <p className="text-sm text-slate-400 mb-2">Uzmanlık Alanları:</p>
                  <div className="flex flex-wrap gap-2">
                    {app.specialties.map((spec) => (
                      <span key={spec} className="px-2 py-1 bg-purple-600/30 text-purple-300 text-xs rounded">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>

                {app.status === 'pending' && (
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleApprove(app.id, app.applicant_address, app)}
                      disabled={processing !== null}
                      className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-600 text-white font-bold rounded-lg transition"
                    >
                      {processing === app.id ? '⏳ İşleniyor...' : '✅ Onayla'}
                    </button>
                    <button
                      onClick={() => handleReject(app.id)}
                      disabled={processing !== null}
                      className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-slate-600 text-white font-bold rounded-lg transition"
                    >
                      {processing === app.id ? '⏳ İşleniyor...' : '❌ Reddet'}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
