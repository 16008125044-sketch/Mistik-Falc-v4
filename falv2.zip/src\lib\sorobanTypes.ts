/**
 * Soroban Fortune Teller - Type Definitions
 * Complete TypeScript interfaces for smart contract interactions
 */

/**
 * Fortune data structure (stored on blockchain)
 */
export interface Fortune {
  /** The fortune text/interpretation */
  text: string;
  /** Unix timestamp when fortune was delivered */
  timestamp: number;
}

/**
 * Fortune request record (stored on blockchain)
 */
export interface FortuneTellerRequest {
  /** User wallet address who requested */
  user: string;
  /** Unix timestamp when requested */
  timestamp: number;
}

/**
 * Contract storage keys enum
 */
export enum StorageKey {
  ADMIN = 'admin',
  PRICE = 'price',
  TOTAL_REQUESTS = 'total_requests',
  FORTUNE_PREFIX = 'fortune_',
  HISTORY_PREFIX = 'history_',
}

/**
 * Contract initialization parameters
 */
export interface ContractInitParams {
  /** Admin wallet address (can deliver fortunes) */
  admin: string;
  /** Fortune price in XLM */
  price: number;
}

/**
 * Fortune request parameters
 */
export interface RequestFortureParams {
  /** User wallet address requesting fortune */
  user: string;
}

/**
 * Deliver fortune parameters
 */
export interface DeliverFortureParams {
  /** User wallet address to receive fortune */
  user: string;
  /** Fortune text/interpretation */
  fortuneText: string;
}

/**
 * Contract method result wrapper
 */
export interface ContractResult<T> {
  success: boolean;
  data?: T;
  error?: string;
  txHash?: string;
}

/**
 * Contract state snapshot
 */
export interface ContractState {
  admin: string;
  price: number;
  totalRequests: number;
  lastUpdated: number;
}

/**
 * User fortune data (frontend cache)
 */
export interface UserFortune {
  fortune: Fortune | null;
  history: FortuneTellerRequest[];
  isLoading: boolean;
  error: string | null;
}

/**
 * Wallet balance info
 */
export interface WalletBalance {
  address: string;
  xlmBalance: number;
  updated: number;
  isLoading: boolean;
}

/**
 * Admin panel state
 */
export interface AdminState {
  isAdmin: boolean;
  deliverInProgress: boolean;
  priceUpdateInProgress: boolean;
  error: string | null;
}

/**
 * Contract interaction result
 */
export interface TransactionResult {
  hash: string;
  status: 'pending' | 'success' | 'failed';
  timestamp: number;
  method: string;
  params: Record<string, any>;
}

/**
 * UI state for loading/error handling
 */
export interface UIState {
  isLoading: boolean;
  isSubmitting: boolean;
  error: string | null;
  success: string | null;
  selectedTab: 'request' | 'view' | 'history' | 'admin';
}

/**
 * Soroban RPC configuration
 */
export interface SorobanConfig {
  contractId: string;
  rpcUrl: string;
  networkPassphrase: string;
  network: 'testnet' | 'mainnet';
}

/**
 * XLM conversion utilities
 */
export interface XLMConversion {
  xlm: number;
  stroops: number;
}

/**
 * API Error response
 */
export interface APIError {
  code: string;
  message: string;
  details?: Record<string, any>;
}

/**
 * Pagination for history
 */
export interface PaginationParams {
  page: number;
  pageSize: number;
  sortBy: 'date' | 'price';
  order: 'asc' | 'desc';
}

/**
 * History response with pagination
 */
export interface HistoryResponse {
  items: FortuneTellerRequest[];
  total: number;
  page: number;
  pageSize: number;
}

/**
 * Event emitted from contract
 */
export interface ContractEvent {
  type: 'fortune_requested' | 'fortune_delivered' | 'price_updated' | 'error';
  timestamp: number;
  data: Record<string, any>;
}

/**
 * User profile in context of fortunes
 */
export interface UserProfile {
  address: string;
  totalRequests: number;
  totalSpent: number;
  lastFortune: Fortune | null;
  memberSince: number;
}

/**
 * Admin statistics
 */
export interface AdminStats {
  totalRequests: number;
  totalRevenue: number;
  activeUsers: number;
  averagePrice: number;
  lastUpdated: number;
}
