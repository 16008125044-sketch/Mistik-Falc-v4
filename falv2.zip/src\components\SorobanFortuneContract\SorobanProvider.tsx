'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { SorobanContractClient, createTestnetClient } from '@/lib/sorobanClient';

interface SorobanContextType {
  client: SorobanContractClient | null;
  contractId: string;
  isReady: boolean;
  price: number;
  totalRequests: number;
  refreshPrice: () => Promise<void>;
  refreshTotalRequests: () => Promise<void>;
}

const SorobanContext = createContext<SorobanContextType | undefined>(undefined);

export function SorobanProvider({ children }: { children: React.ReactNode }) {
  // Contract ID from environment or deployment
  const contractId = process.env.NEXT_PUBLIC_SOROBAN_CONTRACT_ID || '';

  const [client, setClient] = useState<SorobanContractClient | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [price, setPrice] = useState(50); // Default 50 XLM
  const [totalRequests, setTotalRequests] = useState(0);

  // Initialize contract client
  useEffect(() => {
    if (contractId) {
      try {
        const contractClient = createTestnetClient(contractId);
        setClient(contractClient);
        setIsReady(true);
        // Fetch initial data
        refreshPrice(contractClient);
        refreshTotalRequests(contractClient);
      } catch (error) {
        console.error('Failed to initialize Soroban contract client:', error);
        setIsReady(false);
      }
    } else {
      console.warn('NEXT_PUBLIC_SOROBAN_CONTRACT_ID not set');
    }
  }, [contractId]);

  const refreshPrice = async (clientInstance?: SorobanContractClient) => {
    const clientToUse = clientInstance || client;
    if (!clientToUse) return;

    try {
      const currentPrice = await clientToUse.getPrice();
      setPrice(currentPrice);
    } catch (error) {
      console.error('Failed to refresh price:', error);
    }
  };

  const refreshTotalRequests = async (clientInstance?: SorobanContractClient) => {
    const clientToUse = clientInstance || client;
    if (!clientToUse) return;

    try {
      const count = await clientToUse.getTotalRequests();
      setTotalRequests(count);
    } catch (error) {
      console.error('Failed to refresh total requests:', error);
    }
  };

  return (
    <SorobanContext.Provider
      value={{
        client,
        contractId,
        isReady,
        price,
        totalRequests,
        refreshPrice,
        refreshTotalRequests,
      }}
    >
      {children}
    </SorobanContext.Provider>
  );
}

export function useSoroban(): SorobanContextType {
  const context = useContext(SorobanContext);
  if (!context) {
    throw new Error('useSoroban must be used within SorobanProvider');
  }
  return context;
}
