'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useFreighter } from '@/components/FreighterProvider';
import { createClient } from '@supabase/supabase-js';
import * as StellarSdk from 'stellar-sdk';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

interface WitchConsultation {
  id: string;
  witch_address: string;
  client_address: string;
  message: string;
  timestamp: number;
  response?: string;
  responded_at?: number;
}

const CONSULTATION_COST = 50;
const RESPONSE_REWARD = 40;
const RESPONSE_EXP = 25;

export default function WitchConsultationPage() {
  const { address, isConnected, networkPassphrase, signTransaction } = useFreighter();
  const [consultations, setConsultations] = useState<WitchConsultation[]>([]);
  const [selectedConsult, setSelectedConsult] = useState<WitchConsultation | null>(null);
  const [witchList, setWitchList] = useState<any[]>([]);
  const [selectedWitch, setSelectedWitch] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isWitch, setIsWitch] = useState(false);
  const [balance, setBalance] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showWitchInterview, setShowWitchInterview] = useState(false);
  const [interviewData, setInterviewData] = useState({
    name: '',
    bio: '',
    specialties: [] as string[]
  });

  const loadConsultations = async () => {
    if (!address) return;
    try {
      let data = [];
      if (isWitch) {
        const { data: res, error: err } = await supabase
          .from('witch_consultations')
          .select('*')
          .eq('witch_address', address)
          .order('timestamp', { ascending: false });
        if (err) throw err;
        data = res || [];
      } else {
        const { data: res, error: err } = await supabase
          .from('witch_consultations')
          .select('*')
          .eq('client_address', address)
          .order('timestamp', { ascending: false });
        if (err) throw err;
        data = res || [];
      }
      setConsultations(data);
    } catch (err) {
      console.error('Danışmalar yüklenemedi:', err);
    }
  };

  const loadWitches = async () => {
    try {
      const { data, error: err } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('is_witch', true)
        .eq('is_banned', false);
      if (err) throw err;
      setWitchList(data || []);
    } catch (err) {
      console.error('Cadılar yüklenemedi:', err);
    }
  };

  const startConsultation = async (witchAddress: string) => {
    if (!address) {
      setError('Lütfen cüzdan bağlantısı yapın');
      return;
    }

    setIsLoading(true);
    try {
      // Bakiye kontrol et, yoksa oluştur
      let { data: profile, error: fetchErr } = await supabase
        .from('user_profiles')
        .select('xlm_balance')
        .eq('wallet_address', address)
        .single();

      // Profil yoksa oluştur
      if (!profile) {
        const { data: newProfile, error: createErr } = await supabase
          .from('user_profiles')
          .insert([{
            wallet_address: address,
            xlm_balance: 1000,
            name: 'Kullanıcı'
          }])
          .select('xlm_balance')
          .single();

        if (createErr) throw createErr;
        profile = newProfile;
      }

      if (!profile || profile.xlm_balance < 50) {
        setError('❌ Bakiye yetersiz! (50 XLM gerekli)');
        return;
      }

      // ⭐ GERÇEK STELLAR TRANSFERI YAP
      const netPass = networkPassphrase || 'Test SDF Network ; September 2015';
      const horizonUrl = 'https://horizon-testnet.stellar.org';
      const server = new StellarSdk.Horizon.Server(horizonUrl);

      // Gönderici hesabını al
      const sourceAccount = await server.loadAccount(address);

      // Transaction oluştur
      const transaction = new StellarSdk.TransactionBuilder(sourceAccount, {
        fee: '100',
        networkPassphrase: netPass,
      })
        .addOperation(
          StellarSdk.Operation.payment({
            destination: witchAddress,
            asset: StellarSdk.Asset.native(),
            amount: '40', // Cadıya 40 XLM
          })
        )
        .addOperation(
          StellarSdk.Operation.payment({
            destination: 'GC4ASKLFHP73HGKZI64F6FTO47G4VJAHBMCBI3234SGJAU5QIYUOJERR', // Platform cüzdanı
            asset: StellarSdk.Asset.native(),
            amount: '10', // Platform 10 XLM
          })
        )
        .setTimeout(30)
        .build();

      // Freighter'dan imza al
      let signedTransaction: any;
      try {
        const xdrString = transaction.toEnvelope().toXDR('base64');
        console.log('📝 Transaction imzalanıyor...');
        
        const signedXdr = await signTransaction(xdrString);
        signedTransaction = new StellarSdk.Transaction(signedXdr, netPass);
        console.log('✅ Transaction imzalandı');
      } catch (signErr) {
        console.error('❌ İmza hatası:', signErr);
        throw new Error('Transaction imzalama başarısız: ' + (signErr instanceof Error ? signErr.message : String(signErr)));
      }

      // İşlemi sunucuya gönder
      const submitResult = await server.submitTransaction(signedTransaction);
      console.log('✅ Transaction başarılı:', submitResult);

      // Supabase'de kaydı oluştur
      const { data: sessionId, error: rpcError } = await supabase.rpc('process_consultation_payment', {
        client_addr: address,
        witch_addr: witchAddress,
        amount: 50
      });

      if (rpcError) {
        console.warn('⚠️ RPC hatası (ama transfer yapıldı):', rpcError);
      }

      setSuccess(`✅ Danışma başlatıldı! 40 XLM cadıya gönderildi.`);
      setSelectedWitch(null);
      loadConsultations();
      setBalance(profile.xlm_balance - 50);

      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Danışma hatası:', err);
      setError('❌ Hata: ' + (err instanceof Error ? err.message : 'Bilinmeyen'));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (address) {
      loadConsultations();
      if (!isWitch) {
        loadWitches();
      }
      // Supabase bakiyesini yükle
      loadBalance();
    }
  }, [address, isWitch]);

  const loadBalance = async () => {
    if (!address) return;
    try {
      const { data: profile } = await supabase
        .from('user_profiles')
        .select('xlm_balance')
        .eq('wallet_address', address)
        .single();
      
      if (profile) {
        setBalance(profile.xlm_balance);
      }
    } catch (err) {
      console.error('Bakiye yüklenemedi:', err);
    }
  };

  const handleSendConsultation = async () => {
    if (!address || !newMessage.trim() || !selectedWitch) {
      setError('Lütfen cadı seçin ve mesaj yazın');
      return;
    }

    const balanceNum = typeof balance === 'string' ? parseFloat(balance) : (balance || 0);
    if (balanceNum < CONSULTATION_COST) {
      setError(`Yetersiz bakiye. Gerekli: ${CONSULTATION_COST} XLM`);
      setTimeout(() => setError(''), 5000);
      return;
    }

    setIsLoading(true);
    try {
      const newConsult = {
        witch_address: selectedWitch,
        client_address: address,
        message: newMessage.trim(),
        timestamp: Date.now(),
      };

      const { error: err } = await supabase
        .from('witch_consultations')
        .insert([newConsult]);

      if (err) throw err;

      setNewMessage('');
      setSelectedWitch(null);
      setSuccess(`Danışma gönderildi!`);
      setTimeout(() => loadConsultations(), 500);
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      setError(`Hata: ${err instanceof Error ? err.message : 'Bilinmeyen hata'}`);
      setTimeout(() => setError(''), 5000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBecomeWitch = async () => {
    if (!interviewData.name.trim() || !interviewData.bio.trim() || interviewData.specialties.length === 0) {
      setError('Lütfen tüm alanları doldurun');
      return;
    }

    setIsLoading(true);
    try {
      const { error: err } = await supabase
        .from('witch_applications')
        .insert({
          applicant_address: address,
          name: interviewData.name,
          bio: interviewData.bio,
          specialties: interviewData.specialties,
          status: 'pending'
        });

      if (err) throw err;

      setShowWitchInterview(false);
      setInterviewData({ name: '', bio: '', specialties: [] });
      setSuccess('✅ Başvurunuz alındı! Admin tarafından incelenecektir.');
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      setError(`Hata: ${err instanceof Error ? err.message : 'Bilinmeyen hata'}`);
      setTimeout(() => setError(''), 5000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRespondConsultation = async () => {
    if (!selectedConsult || !response.trim() || !address) {
      setError('Yanıt yazın');
      return;
    }

    setIsLoading(true);
    try {
      const { error: err } = await supabase
        .from('witch_consultations')
        .update({
          response: response.trim(),
          responded_at: Date.now(),
        })
        .eq('id', selectedConsult.id);

      if (err) throw err;

      setResponse('');
      setSelectedConsult(null);
      setSuccess(`Yanıt verildi!`);
      setTimeout(() => loadConsultations(), 500);
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      setError(`Hata: ${err instanceof Error ? err.message : 'Bilinmeyen hata'}`);
      setTimeout(() => setError(''), 5000);
    } finally {
      setIsLoading(false);
    }
  };

  if (!address) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-purple-300 mb-4">Cadı danışmasını kullanmak için cüzdan bağlayınız.</p>
          <Link href="/" className="text-blue-400 hover:text-blue-300 underline">
            Ana sayfaya dön
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-6xl mx-auto">
        {error && (
          <div className="mb-4 p-4 rounded-lg bg-red-500/20 border border-red-500/50 text-red-300">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-4 p-4 rounded-lg bg-green-500/20 border border-green-500/50 text-green-300">
            {success}
          </div>
        )}

        <div className="mb-8">
          <Link href="/" className="text-purple-400 hover:text-purple-300 mb-4 inline-block">
            ← Ana Sayfaya Dön
          </Link>
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text mb-2">
                🔮 Cadı Danışması
              </h1>
              <p className="text-slate-300">
                {isWitch ? '🧙‍♀️ Danışma Talepleri' : '👤 Cadılara Danışma İsteği Gönder'}
              </p>
            </div>
            <div className="flex gap-4">
              {isWitch && (
                <Link
                  href="/witch-panel"
                  className="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold rounded-lg transition"
                >
                  📊 Cadı Paneli
                </Link>
              )}
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-sm text-slate-400">💰 XLM Bakiye</div>
                  <button
                    onClick={loadBalance}
                    className="text-xs bg-purple-700 hover:bg-purple-600 px-2 py-1 rounded transition"
                    title="Bakiyeyi yenile"
                  >
                    🔄
                  </button>
                </div>
                <div className="text-2xl font-bold text-green-400">{balance.toFixed(2)}</div>
              </div>
            </div>
            {!isWitch && (
              <button
                onClick={() => setShowWitchInterview(true)}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold rounded-lg transition"
              >
                🧙‍♀️ Cadı Ol
              </button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            {!isWitch ? (
              <div className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-2 border-purple-500/50 rounded-xl p-6">
                <h2 className="text-2xl font-bold text-transparent bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text mb-4">
                  🔮 Mevcut Cadılar ({witchList.length})
                </h2>

                <div className="space-y-3 max-h-[600px] overflow-y-auto">
                  {witchList.length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-slate-400 text-sm">😴 Henüz cadı yok</p>
                      <p className="text-slate-500 text-xs mt-2">Daha sonra geri gelmeyi deneyin</p>
                    </div>
                  ) : (
                    witchList.map((witch) => (
                      <div
                        key={witch.id}
                        className={`p-4 rounded-lg transition-all cursor-pointer border-2 ${
                          selectedWitch === witch.wallet_address
                            ? 'bg-purple-600/50 border-purple-400 shadow-lg shadow-purple-500/50'
                            : 'bg-slate-800/50 border-slate-600/50 hover:border-purple-500/50 hover:bg-slate-700/50'
                        }`}
                        onClick={() => setSelectedWitch(witch.wallet_address)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div className="font-bold text-lg text-white">{witch.name}</div>
                          <span className="text-xs bg-purple-600/50 px-2 py-1 rounded-full text-purple-200">✨ {witch.specialties?.length || 0} uzmanlık</span>
                        </div>
                        
                        <div className="text-sm text-slate-300 mb-2">{witch.bio?.slice(0, 60)}{witch.bio && witch.bio.length > 60 ? '...' : ''}</div>
                        
                        {witch.specialties && witch.specialties.length > 0 && (
                          <div className="flex flex-wrap gap-1 mb-3">
                            {witch.specialties.slice(0, 3).map((spec: string) => (
                              <span key={spec} className="text-xs bg-purple-500/30 text-purple-300 px-2 py-1 rounded">
                                {spec}
                              </span>
                            ))}
                          </div>
                        )}
                        
                        <div className="text-xs text-slate-500">{witch.wallet_address?.slice(0, 12)}...</div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6">
                <h2 className="text-xl font-bold text-purple-300 mb-4">
                  📬 Talepleri ({consultations.length})
                </h2>

                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {consultations.length === 0 ? (
                  <p className="text-slate-400 text-sm">Henüz yok</p>
                ) : (
                  consultations.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setSelectedConsult(c)}
                      className={`w-full p-3 rounded-lg text-left text-sm transition ${
                        selectedConsult?.id === c.id
                          ? 'bg-purple-600 text-white'
                          : c.response
                          ? 'bg-green-500/20 text-green-300'
                          : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600/50'
                      }`}
                    >
                      <div className="font-semibold truncate">
                        {isWitch
                          ? (c.client_address || 'Unknown').slice(0, 10)
                          : (c.witch_address || 'Unknown').slice(0, 10)}
                        ...
                      </div>
                      <div className="text-xs truncate opacity-75">{c.message.slice(0, 30)}...</div>
                      {c.response && <div className="text-xs mt-1">✅ Yanıtlandı</div>}
                    </button>
                  ))
                )}
              </div>
            </div>
            )}
          </div>

          <div className="md:col-span-2">
            {isWitch && selectedConsult ? (
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6">
                <h2 className="text-xl font-bold text-purple-300 mb-4">📝 Danışma Yanıtla</h2>

                <div className="mb-6">
                  <div className="text-sm text-slate-400 mb-2">İstek Sahibi:</div>
                  <div className="text-white mb-4 font-semibold">{selectedConsult.client_address}</div>

                  <div className="text-sm text-slate-400 mb-2">İstek:</div>
                  <div className="bg-slate-800/50 p-4 rounded-lg text-white mb-4">
                    {selectedConsult.message}
                  </div>
                </div>

                {selectedConsult.response ? (
                  <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                    <div className="text-sm text-green-400 mb-2">✅ Yanıt Verildi</div>
                    <div className="text-white">{selectedConsult.response}</div>
                  </div>
                ) : (
                  <div>
                    <textarea
                      value={response}
                      onChange={(e) => setResponse(e.target.value)}
                      placeholder="Yanıtınızı yazınız..."
                      className="w-full p-4 rounded-lg bg-slate-800 text-white border border-purple-500/50 focus:outline-none focus:border-purple-400 mb-4 resize-none"
                      rows={6}
                    />
                    <button
                      onClick={handleRespondConsultation}
                      disabled={!response.trim() || isLoading}
                      className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-600 text-white font-bold rounded-lg transition"
                    >
                      {isLoading ? '⏳ Gönderiliyor...' : '✨ Yanıt Ver'}
                    </button>
                  </div>
                )}
              </div>
            ) : !isWitch ? (
              <div className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-2 border-purple-500/50 rounded-xl p-6">
                <h2 className="text-2xl font-bold text-transparent bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text mb-6">
                  ✍️ Danışma İsteği Gönder
                </h2>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="text-sm font-semibold text-purple-300 mb-3 block">
                      🧙‍♀️ Cadı Seçiniz
                    </label>
                    {selectedWitch ? (
                      <div className="bg-purple-600/30 border-2 border-purple-500 rounded-lg p-4">
                        <div className="font-semibold text-white mb-1">
                          {witchList.find(w => w.wallet_address === selectedWitch)?.name}
                        </div>
                        <div className="text-xs text-slate-400 mb-3">
                          {witchList.find(w => w.wallet_address === selectedWitch)?.wallet_address?.slice(0, 20)}...
                        </div>
                        <button
                          onClick={() => setSelectedWitch(null)}
                          className="text-xs text-purple-400 hover:text-purple-300 underline"
                        >
                          ✕ Değiştir
                        </button>
                      </div>
                    ) : (
                      <div className="text-center py-6 bg-slate-800/50 border-2 border-dashed border-slate-600/50 rounded-lg text-slate-400">
                        👈 Sol taraftan cadı seçiniz
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="text-sm font-semibold text-purple-300 mb-3 block">
                      💬 Danışma Konusu
                    </label>
                    <textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Danışmak istediğiniz konuyu detaylı şekilde yazınız..."
                      className="w-full p-4 rounded-lg bg-slate-800 text-white border-2 border-purple-500/50 focus:outline-none focus:border-purple-400 placeholder-slate-500 resize-none"
                      rows={8}
                    />
                    <div className="text-xs text-slate-500 mt-2">
                      {newMessage.length} / 500 karakter
                    </div>
                  </div>
                </div>

                <button
                  onClick={async () => {
                    if (!selectedWitch) {
                      setError('❌ Lütfen önce bir cadı seçiniz');
                      setTimeout(() => setError(''), 3000);
                      return;
                    }
                    if (!newMessage.trim()) {
                      setError('❌ Lütfen danışma konusunu yazınız');
                      setTimeout(() => setError(''), 3000);
                      return;
                    }
                    await startConsultation(selectedWitch);
                    setNewMessage('');
                    setSelectedWitch(null);
                  }}
                  disabled={!selectedWitch || !newMessage.trim() || isLoading || balance < 50}
                  className={`w-full px-6 py-3 font-bold rounded-lg transition text-white text-lg ${
                    !selectedWitch || !newMessage.trim() || balance < 50
                      ? 'bg-slate-600 cursor-not-allowed opacity-50'
                      : 'bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 shadow-lg hover:shadow-xl'
                  }`}
                >
                  {isLoading ? (
                    <span>⏳ İşleniyor...</span>
                  ) : (
                    <span>
                      {balance < 50 ? '💸 Bakiye Yetersiz' : '💬 Danışma İsteği Gönder (50 XLM)'}
                    </span>
                  )}
                </button>

                {balance < 50 && (
                  <div className="mt-4 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-300 text-sm text-center">
                    ⚠️ Danışma için 50 XLM gereklidir. Bakiyeniz: {balance.toFixed(2)} XLM
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6 text-center text-slate-400">
                Danışma seçin
              </div>
            )}
          </div>
        </div>
      </div>

      {showWitchInterview && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-purple-500/50 rounded-xl p-8 max-w-md w-full shadow-2xl">
            <h2 className="text-2xl font-bold text-purple-300 mb-6 text-center">🧙‍♀️ Cadı Ol Mülakatı</h2>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-purple-300 mb-2 block">Adınız</label>
                <input
                  type="text"
                  value={interviewData.name}
                  onChange={(e) => setInterviewData({ ...interviewData, name: e.target.value })}
                  placeholder="Cadı adı"
                  className="w-full p-3 rounded-lg bg-slate-800/50 text-white border border-purple-500/30 focus:outline-none focus:border-purple-400 placeholder-slate-500"
                />
              </div>

              <div>
                <label className="text-sm text-purple-300 mb-2 block">Bio</label>
                <textarea
                  value={interviewData.bio}
                  onChange={(e) => setInterviewData({ ...interviewData, bio: e.target.value })}
                  placeholder="Kendinizi kısaca tanıtın"
                  className="w-full p-3 rounded-lg bg-slate-800/50 text-white border border-purple-500/30 focus:outline-none focus:border-purple-400 resize-none placeholder-slate-500"
                  rows={3}
                />
              </div>

              <div>
                <label className="text-sm text-purple-300 mb-3 block">Uzmanlık Alanları</label>
                <div className="space-y-2">
                  {['Aşk & İlişkiler', 'Kariyer & Para', 'Sağlık & Wellness', 'Ruh & Tarot', 'Kişisel Gelişim'].map((spec) => (
                    <label key={spec} className="flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={interviewData.specialties.includes(spec)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setInterviewData({
                              ...interviewData,
                              specialties: [...interviewData.specialties, spec]
                            });
                          } else {
                            setInterviewData({
                              ...interviewData,
                              specialties: interviewData.specialties.filter((s) => s !== spec)
                            });
                          }
                        }}
                        className="mr-3 w-4 h-4 rounded border-purple-500/50 accent-purple-500"
                      />
                      <span className="text-sm text-slate-300">{spec}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-6">
                <button
                  onClick={() => {
                    setShowWitchInterview(false);
                    setInterviewData({ name: '', bio: '', specialties: [] });
                  }}
                  className="flex-1 px-4 py-2 bg-slate-700/50 hover:bg-slate-700 text-slate-300 font-bold rounded-lg transition border border-slate-600"
                >
                  İptal
                </button>
                <button
                  onClick={handleBecomeWitch}
                  disabled={isLoading || !interviewData.name.trim() || !interviewData.bio.trim() || interviewData.specialties.length === 0}
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-slate-600 disabled:to-slate-600 text-white font-bold rounded-lg transition"
                >
                  {isLoading ? '⏳ Kaydediliyor' : '✨ Gönder'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
