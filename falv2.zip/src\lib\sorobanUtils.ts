// Soroban Contract utilities

// Soroban Contract adresi (deploy edildikten sonra)
// Test için örnek: CCMHPHV4QZL5FVKZ3GTQQXQ7Z5H75NZE2KSTZZDKM3AZGJJ6X3QBZLRX
export const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_SOROBAN_CONTRACT_ADDRESS || '';

// Soroban RPC URL
export const SOROBAN_RPC_URL = process.env.NEXT_PUBLIC_SOROBAN_RPC_URL || 'https://soroban-testnet.stellar.org';

// Contract fonksiyonlarını çağır
export async function invokeContractFunction(
  functionName: string,
  params: any[],
  signerAddress: string
) {
  if (!CONTRACT_ADDRESS) {
    throw new Error('Contract adresi tanımlanmamış');
  }

  try {
    // TODO: Freighter ile transaction imzalanacak
    // Şu an placeholder
    console.log(`Calling ${functionName} with params:`, params);
    return null;
  } catch (error) {
    console.error('Contract çağrısı hatası:', error);
    throw error;
  }
}

// Soru sor
export async function askQuestion(askerAddress: string, question: string) {
  return invokeContractFunction('ask_question', [askerAddress, question], askerAddress);
}

// Cevap ver
export async function answerQuestion(
  answererAddress: string,
  questionId: string,
  answer: string
) {
  return invokeContractFunction(
    'answer_question',
    [answererAddress, questionId, answer],
    answererAddress
  );
}

// Soruları al
export async function getQuestions() {
  return invokeContractFunction('get_questions', [], '');
}

// Kullanıcının harcadığı paranı al
export async function getUserSpent(userAddress: string) {
  return invokeContractFunction('get_user_spent', [userAddress], '');
}

// Cadının kazandığı paranı al
export async function getWitchEarned(witchAddress: string) {
  return invokeContractFunction('get_witch_earned', [witchAddress], '');
}

// Site deposu
export async function getSiteDeposit() {
  return invokeContractFunction('get_site_deposit', [], '');
}
