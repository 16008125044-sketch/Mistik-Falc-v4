'use client';

import { useFreighter } from '@/components/FreighterProvider';
import FreighterTestPanel from '@/components/FreighterTestPanel';
import { useState } from 'react';

export default function Bootcamp() {
  const { address, network, isConnected, sorobanRpcUrl } = useFreighter();
  const [expandedModule, setExpandedModule] = useState<number | null>(0);

  const modules = [
    {
      title: '🧱 Blockchain Temelleri',
      description: 'Blockchain nedir ve nasıl çalışır?',
      content: [
        'Dağıtık defter (ledger) sistemi',
        'Merkeziyetsizlik (Decentralization)',
        'Konsensüs Mekanizmaları',
        'Zincir yapısı ve manipülasyona karşı koruma',
      ],
    },
    {
      title: '🌐 Cüzdanlar & Anahtar Yönetimi',
      description: 'Private key, public key ve güvenlik',
      content: [
        'Public Key (Adres) ve Private Key (Gizli Anahtar)',
        'Seed Phrase (12/24 kelime)',
        'Akıllı Cüzdan (Smart Wallet)',
        'Freighter Cüzdan Entegrasyonu',
      ],
    },
    {
      title: '🧪 Testnet Nedir?',
      description: 'Gerçek para olmayan geliştirme ağı',
      content: [
        'Testnet açıklaması',
        'Faucet ile ücretsiz token alma',
        'Stellar Testnet XLM',
        'Smart contract ve transaction testi',
      ],
    },
    {
      title: '🌟 Stellar Ekosistemine Giriş',
      description: 'Hızlı ve düşük maliyetli blockchain',
      content: [
        'Stellar nedir (5 saniye işlem süresi)',
        'Düşük işlem ücretleri',
        'Sınır ötesi ödemeler',
        'Stellar Consensus Protocol (SCP)',
      ],
    },
    {
      title: '🧠 Soroban – Akıllı Kontrat Platformu',
      description: 'Rust ve WASM ile smart contracts',
      content: [
        'Soroban nedir',
        'Rust dilinde kontrat yazımı',
        'WASM execution',
        'Hızlı ve güvenli deterministik hesaplama',
      ],
    },
    {
      title: '📦 IPFS (InterPlanetary File System)',
      description: 'Dağıtık dosya depolama',
      content: [
        'IPFS nedir ve nasıl çalışır',
        'Content-addressed depolama',
        'NFT metadata depolama',
        'Permanent bağlantılar',
      ],
    },
  ];

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-4xl font-bold mb-2 text-purple-900">📚 Web3 & Stellar Bootcamp</h1>
      <p className="text-gray-600 mb-8">Freighter cüzdanınız ile başlayın ve blockchain dünyasında yolculuğunuza çıkın.</p>

      {/* Freighter Bilgisi */}
      {isConnected && address && (
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-4 mb-8">
          <h2 className="font-semibold text-green-900 mb-3">✅ Bootcamp Bilgileriniz</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-600">Freighter Cüzdanı</p>
              <p className="font-mono text-green-700 break-all">{address}</p>
            </div>
            <div>
              <p className="text-gray-600">Ağ</p>
              <p className="font-semibold text-green-700">{network}</p>
            </div>
          </div>
          {sorobanRpcUrl && (
            <div className="mt-4 p-3 bg-white rounded text-xs">
              <p className="text-gray-600">Soroban RPC URL</p>
              <p className="font-mono text-gray-700 break-all">{sorobanRpcUrl}</p>
            </div>
          )}
        </div>
      )}

      {/* Modüller */}
      <div className="space-y-3">
        {modules.map((module, idx) => (
          <div key={idx} className="bg-white rounded-lg shadow hover:shadow-md transition border border-gray-200">
            <button
              onClick={() => setExpandedModule(expandedModule === idx ? null : idx)}
              className="w-full text-left p-5 hover:bg-gray-50 transition flex justify-between items-center"
            >
              <div>
                <h3 className="font-bold text-lg text-gray-900">{module.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{module.description}</p>
              </div>
              <span className={`text-2xl transition-transform ${expandedModule === idx ? 'rotate-180' : ''}`}>▼</span>
            </button>

            {expandedModule === idx && (
              <div className="px-5 pb-5 border-t border-gray-200">
                <ul className="space-y-2 mt-4">
                  {module.content.map((item, itemIdx) => (
                    <li key={itemIdx} className="flex gap-3 text-gray-700">
                      <span className="text-purple-600 font-bold">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <button className="mt-4 px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 transition text-sm font-medium">
                  {isConnected ? '🎓 Modülü Tamamla' : '🔗 Freighter Bağla'}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* İleri Konular */}
      <div className="mt-12 bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg p-6 border border-purple-200">
        <h2 className="text-2xl font-bold text-purple-900 mb-4">🚀 İleri Konular</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded p-4">
            <h3 className="font-semibold text-gray-900 mb-2">📝 Demo İşlemler</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ Testnet cüzdan oluşturma</li>
              <li>✓ Faucet ile token alma</li>
              <li>✓ XLM transferi</li>
              <li>✓ Smart contract deployment</li>
            </ul>
          </div>
          <div className="bg-white rounded p-4">
            <h3 className="font-semibold text-gray-900 mb-2">🌍 Gerçek Dünya Kullanım</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ MoneyGram On/Off Ramp</li>
              <li>✓ USDC Transferleri</li>
              <li>✓ RWA Tokenizasyonu</li>
              <li>✓ Fintech Entegrasyonları</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Freighter Test Panel */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">🔧 Freighter Test Panel</h2>
        <FreighterTestPanel />
      </div>
    </div>
  );
}
