'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface Astrologer {
  id: string;
  name: string;
  description: string;
  emoji: string;
  cost: number;
}

interface AstrologerContextType {
  astrologers: Astrologer[];
  selectedAstrologer: Astrologer | null;
  selectAstrologer: (id: string) => void;
}

const AstrologerContext = createContext<AstrologerContextType | undefined>(undefined);

export const defaultAstrologers: Astrologer[] = [];

export function AstrologerProvider({ children }: { children: React.ReactNode }) {
  const [selectedAstrologer, setSelectedAstrologer] = useState<Astrologer | null>(null);
  const [astrologers, setAstrologers] = useState<Astrologer[]>([]);
  const [hydrated, setHydrated] = useState(false);

  // Falcıları localStorage'dan yükle ve güncelle
  const loadAstrologers = () => {
    const falciListesi: Astrologer[] = [];
    
    // Tüm localStorage anahtarlarını kontrol et
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('profile_') && key.endsWith('_isAstrologer')) {
        const isAstrologer = localStorage.getItem(key) === 'true';
        if (isAstrologer) {
          // Adres kısmını çıkar: profile_{ADDRESS}_isAstrologer
          const addressMatch = key.match(/^profile_(.+)_isAstrologer$/);
          if (addressMatch) {
            const address = addressMatch[1];
            const nameKey = `profile_${address}_name`;
            const name = localStorage.getItem(nameKey) || 'Bilinmeyen Falcı';
            
            // Falcıyı listeye ekle (yineleme varsa ekleme)
            if (!falciListesi.find(f => f.id === address)) {
              falciListesi.push({
                id: address,
                name: name,
                description: 'Onaylı falcı',
                emoji: '🔮',
                cost: 50,
              });
            }
          }
        }
      }
    }
    
    setAstrologers(falciListesi);
    return falciListesi;
  };

  useEffect(() => {
    // İlk yükleme
    const initialFalcilar = loadAstrologers();
    
    // Seçili falcıyı kontrol et
    const saved = localStorage.getItem('selectedAstrologer');
    if (saved) {
      const astrologer = initialFalcilar.find(a => a.id === saved);
      if (astrologer) {
        setSelectedAstrologer(astrologer);
      }
    }
    
    setHydrated(true);

    // localStorage değişimlerini dinle (storage event)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key && e.key.endsWith('_isAstrologer')) {
        // Falcı durumu değişti, listesini güncelle
        const updatedAstrologers = loadAstrologers();
        
        // Seçili falcı hala listede varsa koru, yoksa temizle
        setSelectedAstrologer(prev => {
          if (prev && updatedAstrologers.find(a => a.id === prev.id)) {
            return prev;
          }
          return null;
        });
      }
    };

    // Storage event listener ekle (farklı sekmelerden güncellemeler için)
    window.addEventListener('storage', handleStorageChange);

    // Aynı sekmede localStorage değişimlerini dinlemek için interval
    const checkInterval = setInterval(() => {
      const newAstrologers = loadAstrologers();
      setAstrologers(prev => {
        // Değişim olup olmadığını kontrol et
        if (JSON.stringify(prev) !== JSON.stringify(newAstrologers)) {
          return newAstrologers;
        }
        return prev;
      });
    }, 1000); // Her 1 saniyede kontrol et

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(checkInterval);
    };
  }, []);

  const selectAstrologer = (id: string) => {
    const astrologer = astrologers.find(a => a.id === id);
    if (astrologer) {
      setSelectedAstrologer(astrologer);
      localStorage.setItem('selectedAstrologer', id);
    }
  };

  if (!hydrated) {
    return <>{children}</>;
  }

  return (
    <AstrologerContext.Provider
      value={{
        astrologers: astrologers,
        selectedAstrologer,
        selectAstrologer,
      }}
    >
      {children}
    </AstrologerContext.Provider>
  );
}

export function useAstrologer() {
  const context = useContext(AstrologerContext);
  if (context === undefined) {
    throw new Error('useAstrologer must be used within AstrologerProvider');
  }
  return context;
}
