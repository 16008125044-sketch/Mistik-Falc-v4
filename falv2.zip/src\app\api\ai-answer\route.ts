export async function POST(request: Request) {
  try {
    const { question, context } = await request.json();

    if (!question || typeof question !== 'string') {
      return Response.json({ error: 'Geçersiz soru' }, { status: 400 });
    }

    // Konuşma bağlamını ve soruyu analiz ederek cevap oluştur
    const answer = generateResponse(question, context);

    return Response.json({ answer });
  } catch (error) {
    console.error('AI endpoint hatası:', error);
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function generateResponse(question: string, context?: string): string {
  const q = question.toLowerCase();

  // Temel cevaplar
  const responses: Record<string, string> = {
    'python': 'Python, yüksek seviyeli, yorumlanmış bir programlama dilidir. Okunabilir sözdizimi ve geniş kütüphane ekosistemi ile bilinir. Web geliştirme, veri analizi, yapay zeka ve otomasyon gibi alanlarda yaygın olarak kullanılır.',
    'javascript': 'JavaScript, web tarayıcılarında çalışan istemci-tarafı bir betik dilidir. Etkileşimli web sayfaları oluşturmak için kullanılır. Node.js ile sunucu tarafında da çalıştırılabilir.',
    'typescript': 'TypeScript, JavaScript üzerinde inşa edilen ve statik tip sistemini kütüphaneye ekleyen bir dildir. Büyük projelerde hataları erkenden yakalamaya yardımcı olur.',
    'react': 'React, Facebook tarafından geliştirilen bir JavaScript kütüphanesidir. Kullanıcı arayüzleri oluşturmak için bileşen tabanlı bir yaklaşım kullanır.',
    'next.js': 'Next.js, React için bir çerçevedir. Sunucu tarafı oluşturma, statik site oluşturma ve API yolları gibi özellikleri sağlar.',
    'nedir': 'Sorunuzu daha spesifik hale getirir misiniz? Belirli bir konuda bilgi almak istediğiniz söyleyebilir misiniz?',
    'selam': 'Merhaba! Size yardımcı olmaktan mutluyum. Bir sorunuz varsa sormaktan çekinmeyin.',
    'merhaba': 'Merhaba! Hoş buldum. Sorunuzu sorun, cevaplamaya çalışacağım.',
    'teşekkür': 'Bir şey değil! Başka sorularınız varsa sormaktan çekinmeyin.',
    'sağol': 'Memnuniyetle! Başka ne yapabilirim?',
    'adım': 'Ben senin yapay zeka asistanınım. Sizin sorularınıza cevap vermek için buradayım.',
  };

  // Anahtar kelimeler için cevapları ara
  for (const [key, value] of Object.entries(responses)) {
    if (q.includes(key)) {
      return value;
    }
  }

  // Bağlam varsa, konuşmanın akışını dikkate al
  if (context) {
    if (q.includes('evet') || q.includes('doğru') || q.includes('haklı')) {
      return 'Haklısınız! Başka bir taraftan bakarsak, bu konuda daha fazla bilgi arıyor musunuz?';
    }
    if (q.includes('hayır') || q.includes('yanlış') || q.includes('değil')) {
      return 'Anladım. O halde farklı bir yaklaşım deneyelim. Başka bir açıdan açıklama istediğiniz başka bir konu var mı?';
    }
    if (q.includes('nasıl') || q.includes('nasıl yapabilirim')) {
      return 'Bunu adım adım açıklayabilirim. Başlamadan önce, hangi seviyeden başlamayı tercih edersiniz? Başlangıç veya ileri düzey?';
    }
    if (q.includes('neden') || q.includes('nedeninden')) {
      return 'Bu bir harika soru! Bunun arkasında birkaç neden var. Kısaca söylemek gerekirse...';
    }
  }

  // Varsayılan cevap
  return `Sizin sorunuz: "${question}"\n\nBu çok ilginç bir soru! Detaylı bir cevap vermek için:\n- Sorunuzu biraz daha spesifikleştirebilir misiniz?\n- Belirli bir programlama dili veya konu hakkında mı?\n- İşi başında pratik bir örnek mi gerekli?\n\nSize daha iyi yardımcı olmak için lütfen daha fazla bilgi verin!`;
}
