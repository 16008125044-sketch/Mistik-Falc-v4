export const MysticTarotTheme = {
  colors: {
    background: '#0f0f1e',
    primary: '#7c3aed',
    secondary: '#1f1f3f',
    text: '#e0e0e0',
    highlight: '#fbbf24',
  },
  fonts: {
    heading: 'Georgia, serif',
    body: 'Segoe UI, sans-serif',
  },
  effects: {
    stars: {
      className: 'absolute inset-0 opacity-20 pointer-events-none',
      style: {
        backgroundImage: 'radial-gradient(1px 1px at 20% 30%, white, rgba(0,0,0,0))',
        backgroundSize: '50px 50px',
      },
    },
  },
  animations: {
    cardGlow: 'hover:shadow-2xl hover:shadow-purple-500/50 transition-shadow duration-300',
  },
};
