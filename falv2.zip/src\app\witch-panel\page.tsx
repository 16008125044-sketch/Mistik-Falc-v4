'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useFreighter } from '@/components/FreighterProvider';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

interface WitchSession {
  id: string;
  client_address: string;
  witch_address: string;
  amount: number;
  status: string;
  created_at: string;
  completed_at?: string;
  response?: string;
  witch_earnings?: number;
}

interface UserProfile {
  id: string;
  wallet_address: string;
  name: string;
  is_witch: boolean;
  is_premium?: boolean;
}

export default function WitchPanelPage() {
  const { address, isConnected } = useFreighter();
  const [isWitch, setIsWitch] = useState(false);
  const [witchSessions, setWitchSessions] = useState<WitchSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<WitchSession | null>(null);
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [earningsTotal, setEarningsTotal] = useState(0);

  useEffect(() => {
    if (address && isConnected) {
      checkWitchStatus();
    }
  }, [address, isConnected]);

  const checkWitchStatus = async () => {
    try {
      setIsLoading(true);
      
      // Kullanıcının cadı olup olmadığını kontrol et
      const { data: profile, error: profileErr } = await supabase
        .from('user_profiles')
        .select('is_witch')
        .eq('wallet_address', address)
        .single();

      if (profileErr || !profile?.is_witch) {
        setError('❌ Bu sayfa sadece cadılar için erişilebilir. Cadı başvurusu yapınız.');
        setIsWitch(false);
        return;
      }

      setIsWitch(true);

      // Cadının danışma oturumlarını yükle
      const { data: sessions, error: sessionsErr } = await supabase
        .from('witch_sessions')
        .select('*')
        .eq('witch_address', address)
        .order('created_at', { ascending: false });

      if (sessionsErr) throw sessionsErr;

      setWitchSessions(sessions || []);

      // Toplam kazançları hesapla
      const total = (sessions || []).reduce((sum, s) => sum + (s.witch_earnings || 0), 0);
      setEarningsTotal(total);
    } catch (err) {
      console.error('Hata:', err);
      setError('Bir hata oluştu: ' + (err instanceof Error ? err.message : 'Bilinmeyen hata'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRespond = async () => {
    if (!selectedSession || !response.trim()) {
      setError('Lütfen yanıt yazınız');
      return;
    }

    setIsLoading(true);
    try {
      const { error: updateErr } = await supabase
        .from('witch_sessions')
        .update({
          response: response.trim(),
          status: 'completed',
          completed_at: new Date().toISOString(),
        })
        .eq('id', selectedSession.id);

      if (updateErr) throw updateErr;

      setSuccess('✅ Yanıt başarıyla gönderildi!');
      setResponse('');
      setSelectedSession(null);
      setTimeout(() => {
        checkWitchStatus();
        setSuccess('');
      }, 1000);
    } catch (err) {
      setError('Hata: ' + (err instanceof Error ? err.message : 'Bilinmeyen hata'));
      setTimeout(() => setError(''), 5000);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-purple-300 mb-4">Cadı panelini görmek için cüzdan bağlayınız.</p>
          <Link href="/" className="text-blue-400 hover:text-blue-300 underline">
            Ana sayfaya dön
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <div className="h-12 w-12 border-4 border-purple-400 border-t-pink-400 rounded-full mx-auto" />
          </div>
          <p className="text-purple-300">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!isWitch) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <div className="text-center max-w-md">
          <h1 className="text-3xl font-bold text-purple-300 mb-4">🔐 Cadı Paneli</h1>
          <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-6 mb-6">
            <p className="text-red-300 mb-4">{error}</p>
            <Link
              href="/witch-consultation"
              className="inline-block px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold rounded-lg transition"
            >
              🧙‍♀️ Cadı Başvurusu Yap
            </Link>
          </div>
          <Link href="/" className="text-purple-400 hover:text-purple-300 underline">
            Ana sayfaya dön
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-6xl mx-auto">
        {error && (
          <div className="mb-4 p-4 rounded-lg bg-red-500/20 border border-red-500/50 text-red-300">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-4 p-4 rounded-lg bg-green-500/20 border border-green-500/50 text-green-300">
            {success}
          </div>
        )}

        {/* Başlık */}
        <div className="mb-8">
          <Link href="/" className="text-purple-400 hover:text-purple-300 mb-4 inline-block">
            ← Ana Sayfaya Dön
          </Link>
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text mb-2">
                🧙‍♀️ Cadı Paneli
              </h1>
              <p className="text-slate-300">Kullanıcılardan gelen danışma isteklerine yanıt verin</p>
            </div>
            <div className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 border-2 border-green-500/50 rounded-lg p-6 text-center">
              <div className="text-sm text-green-300 mb-2">💰 Toplam Kazanç</div>
              <div className="text-3xl font-bold text-green-400">{earningsTotal.toFixed(2)}</div>
              <div className="text-xs text-green-400 mt-2">XLM</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Sol: Danışma İstekleri */}
          <div className="md:col-span-1">
            <div className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-2 border-purple-500/50 rounded-xl p-6 sticky top-6">
              <h2 className="text-2xl font-bold text-transparent bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text mb-4">
                📨 Danışma İstekleri ({witchSessions.length})
              </h2>

              <div className="space-y-3 max-h-[600px] overflow-y-auto">
                {witchSessions.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-slate-400 text-sm">😴 Henüz istek yok</p>
                    <p className="text-slate-500 text-xs mt-2">Kullanıcılar sizi seçtiğinde istekler burada görünecek</p>
                  </div>
                ) : (
                  witchSessions.map((session) => (
                    <button
                      key={session.id}
                      onClick={() => setSelectedSession(session)}
                      className={`w-full p-4 rounded-lg text-left transition-all border-2 ${
                        selectedSession?.id === session.id
                          ? 'bg-purple-600/50 border-purple-400 shadow-lg shadow-purple-500/50'
                          : session.response
                          ? 'bg-green-600/20 border-green-500/30 hover:border-green-500/50'
                          : 'bg-slate-800/50 border-slate-600/50 hover:border-purple-500/50'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="font-semibold text-white">
                          {session.client_address?.slice(0, 12)}...
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          session.response
                            ? 'bg-green-600/50 text-green-200'
                            : 'bg-yellow-600/50 text-yellow-200'
                        }`}>
                          {session.response ? '✅ Yanıtlandı' : '⏳ Bekleniyor'}
                        </span>
                      </div>
                      
                      <div className="text-xs text-slate-400 mb-2">
                        {new Date(session.created_at).toLocaleDateString('tr-TR')}
                      </div>

                      <div className="text-sm text-slate-300 line-clamp-2">
                        {session.amount} XLM danışma
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Sağ: Danışma Detayı ve Yanıtlama */}
          <div className="md:col-span-2">
            {selectedSession ? (
              <div className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-2 border-purple-500/50 rounded-xl p-6 space-y-6">
                <div>
                  <h3 className="text-2xl font-bold text-transparent bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text mb-4">
                    📝 Danışma Detayı
                  </h3>

                  <div className="space-y-4 bg-slate-900/50 rounded-lg p-4 border border-slate-700/50">
                    <div>
                      <div className="text-sm text-slate-400 mb-1">👤 İstek Sahibi</div>
                      <div className="text-white font-semibold">{selectedSession.client_address}</div>
                    </div>

                    <div>
                      <div className="text-sm text-slate-400 mb-1">💰 Danışma Ücreti</div>
                      <div className="text-white font-semibold text-lg">
                        {selectedSession.amount} XLM
                        <span className="text-xs text-green-400 ml-2">
                          (Siz: {selectedSession.witch_earnings || 0} XLM)
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-slate-400 mb-1">📅 Tarih</div>
                      <div className="text-white">
                        {new Date(selectedSession.created_at).toLocaleString('tr-TR')}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-slate-400 mb-1">📌 Durum</div>
                      <div className={`text-white font-semibold ${
                        selectedSession.response ? 'text-green-400' : 'text-yellow-400'
                      }`}>
                        {selectedSession.response ? '✅ Yanıtlandı' : '⏳ Bekleniyor'}
                      </div>
                    </div>
                  </div>
                </div>

                {selectedSession.response ? (
                  <div className="bg-green-500/10 border-2 border-green-500/30 rounded-lg p-6">
                    <div className="text-lg font-bold text-green-400 mb-3">✅ Verilen Yanıt</div>
                    <div className="text-white bg-slate-900/50 p-4 rounded-lg">
                      {selectedSession.response}
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="text-lg font-bold text-purple-300 mb-3 block">
                      💬 Yanıtınızı Yazınız
                    </label>
                    <textarea
                      value={response}
                      onChange={(e) => setResponse(e.target.value)}
                      placeholder="Danışana özel, düşünceli ve yardımcı bir yanıt yazınız..."
                      className="w-full p-4 rounded-lg bg-slate-800 text-white border-2 border-purple-500/50 focus:outline-none focus:border-purple-400 placeholder-slate-500 resize-none mb-4"
                      rows={8}
                    />
                    <div className="text-xs text-slate-500 mb-4">
                      {response.length} / 2000 karakter
                    </div>

                    <button
                      onClick={handleRespond}
                      disabled={!response.trim() || isLoading}
                      className={`w-full px-6 py-3 font-bold rounded-lg transition text-white text-lg ${
                        !response.trim() || isLoading
                          ? 'bg-slate-600 cursor-not-allowed opacity-50'
                          : 'bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 shadow-lg hover:shadow-xl'
                      }`}
                    >
                      {isLoading ? '⏳ Gönderiliyor...' : '✨ Yanıtı Gönder'}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-2 border-purple-500/50 rounded-xl p-12 text-center">
                <div className="text-6xl mb-4">🔮</div>
                <p className="text-slate-400 text-lg">Sol taraftan bir danışma seçiniz</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
