'use client';

import React, { useState, useEffect } from 'react';

interface DailyReading {
  date: string;
  zodiac: string;
  mainMessage: string;
  love: string;
  career: string;
  health: string;
  lucky: {
    number: number;
    hour: string;
    element: string;
  };
}

const ZODIAC_TRAITS = {
  Koç: {
    element: 'Ateş',
    trait: 'Cesur, hızlı, lider',
    mainMessages: [
      'Ateş enerjin bugün parlıyor! Cesur ol, atılgan ol, lider ol.',
      'Başlarken çekinceli misin? Hayır! Hemen atılış zamanı gelmiş.',
      'Rekabet seni çağırıyor. Rakibi yenip birinci ol.',
      'Yeni bir proje veya macera için tam zaman. Ruh seninle beraber.',
    ],
  },
  Boğa: {
    element: 'Toprak',
    trait: 'İstikrar, güvenilirlik, hoşlanılar',
    mainMessages: [
      'Sabrınız kavi, güvenilirliğiniz onu kazandıracak. Sabırla devam et.',
      'Maddi konular ön planda. Düşünceli harcama yap, zenginlik gelecek.',
      'İstikrarlı adımlar ile hedefi yakala. Aceleye gerek yok, plan tutacak.',
      'Lüksü ve konforunu hak ediyorsun. Kendine iyi davran.',
    ],
  },
  İkizler: {
    element: 'Hava',
    trait: 'Zeki, sosyal, meraklı',
    mainMessages: [
      'Entelektüel gücün harika! Söyle, dinle, bağlan.',
      'İletişim bugün altın. Doğru söz söyle, yeni bağlantılar kurabilirsin.',
      'Merak ve öğrenme arzunu tatmin et. Yeni bilgi denize girecek.',
      'Sosyal etkinliklere git, burada kader seni bekliyor.',
    ],
  },
  Yengeç: {
    element: 'Su',
    trait: 'Duygusal, koruyucu, empatik',
    mainMessages: [
      'Duygularına güven, sezgilerin doğru. İçsel ses seni yönetsin.',
      'Aile ve yakınların seni çağırıyor. Bağlantı ve sevgi bugün iyileştirici.',
      'Korumalı bir ortamda kalmak istiyorum diyorsan, evet iyidir. Geri çekilmeyin.',
      'Emosyonel ihtiyaçlarınızı göz ardı etmeyin. Kendine de yuva yap.',
    ],
  },
  Aslan: {
    element: 'Ateş',
    trait: 'Müebbit, güzel, hegemonyacı',
    mainMessages: [
      'Karizman bugün zirve yaptı! Parlak ve sevilen ol.',
      'Sahneye çık, ışık sende. Gücünü göster, başarısını kanıtla.',
      'Merkezde olmak senin hakkın. Cesur, güzel ve koruyucu davran.',
      'Yaratıcılığın sınırsız. Kendini ifade etmeye başla, başarı gelecek.',
    ],
  },
  Başak: {
    element: 'Toprak',
    trait: 'Analitik, mütekemel, faydalı',
    mainMessages: [
      'Detaylara dikkat et, o detaylar kazanacak seni. Analiz et, planla, yap.',
      'Sağlık ve temizlik ön planda. Organizasyona başla, enerji gelecek.',
      'Kusurluluktan mükemmelliğe gitmek istiyorsun ama sakin. Yavaş yavaş ilerle.',
      'Yardımcı ol, kut kazanacaksın. Dünyanın ihtiyacı olan şeyi ver.',
    ],
  },
  Terazi: {
    element: 'Hava',
    trait: 'Ahenkli, adil, sosyal',
    mainMessages: [
      'Denge ve uyum sana kızılötesi. Ahenkli ilişkiler kur, barış sağla.',
      'Karar vermeye ihtiyacın var mı? Mantık ve kalbi tartı, orta yolu bul.',
      'Sosyal çevren seni çağırıyor. Harika insanlarla bağlantı kurabilirsin.',
      'Estetik ve güzellik seni çeksin. Çevrenin schöne bir hale getir.',
    ],
  },
  Akrep: {
    element: 'Su',
    trait: 'Yoğun, gizemli, güçlü',
    mainMessages: [
      'Derinliğine dalış yap, gizli olanı keşfet. Ruh seni rehber etsin.',
      'Yoğun duygular güne hükmeditecek. Onları kontrol et, zarlamı dönüştür.',
      'Dönüşüm ve yenileme zamanı. Eski bırak, yeni kendini kabul et.',
      'İntuitif gücün çok kuvvetli. Sezgine güven, çok doğru çıkacak.',
    ],
  },
  Yay: {
    element: 'Ateş',
    trait: 'Maceraperest, iyimser, felsefi',
    mainMessages: [
      'Sınırlar seni tutsak etmesin. Özgürlüğe çık, maceraya git.',
      'Umut ve iyimserlik seni yönetecek. Büyük düşün, başarı gelecek.',
      'Yeni ufuklar seni çağırıyor. Yolculuğa çık, keşfet, öğren.',
      'Felsefik sorular seni meşgul etsin. Anlam ara, bulacaksın.',
    ],
  },
  Oğlak: {
    element: 'Toprak',
    trait: 'Disiplin, kararlı, sorumlu',
    mainMessages: [
      'Disiplin ve sorumluluk seni kazandıracak. Hedefine odaklan, pes etme.',
      'Kariyerde önemli adım atma zamanı. Sabırlı, dayanıklı, ilerlemeyi sürdür.',
      'Uzun vadeli planlar yap, çabanı buna yönel. Başarı güvenli bir yolda gelecek.',
      'Inatçılığın güç, ama eğitilmesi lazım. Hedefi unutma ama yolda aşkı da kaç.',
    ],
  },
  Kova: {
    element: 'Hava',
    trait: 'İnovatif, bağımsız, vizyoner',
    mainMessages: [
      'Farklılığın güzel, özgünlüğün güçlü. Kendi yolunun git.',
      'Teknoloji ve inovasyona doğru git. Geleceği sen yaratacaksın.',
      'Bağımsızlık seninle beraber. Başkasına bağlı olmak istemediğini göster.',
      'Vizyoner fikirler seni heyecanlandıracak. Hayalin gerçeği yap.',
    ],
  },
  Balık: {
    element: 'Su',
    trait: 'Sempatik, sanatsal, rüyamsal',
    mainMessages: [
      'Sempati ve empati enerjin güçlü. Başkasının ağlısını hisset, iyilemeyi sağla.',
      'Sanat ve hayal gücü seni çağırıyor. Ruhun ifadesini bulması kütlü.',
      'Danışmanlık ve rehberlik seninle uyumlu. Diğerlerine yol göster.',
      'Rüyaları gerçeğe dönüştürme zamanı. Hayal gücünü aksiyon ile birleştir.',
    ],
  },
};

const DAILY_READINGS: Record<string, string[]> = {
  love: [
    'Aşkın enerjileri güçlü. Yeni bir ilişki başlayabilir veya mevcut ilişkiniz derinleşebilir.',
    'Samimi iletişim önemli. Kalben söyle, sözsüz mesajlardan sakın.',
    'Bekle, acı verici bir konuşma faydalı olabilir. Dürüstlük en iyi ilacı.',
    'Yalnızlık ve bağlantı arasındaki dengeyi bul. Kalbini korumak kadar vermeyi de öğren.',
    'Tutkuyla sabır arasında bir seçim yapmalısın. Aceleye getirme, ama boşver da deme.',
    'Sevgi seni çağırıyor ama bekleme halindeyken olmamalısın. Harekete geç!',
    'Emosyonel kapılar açılmaya hazırlanıyor. Yeni birisi hayatına girebilir veya eski birisi geri dönebilir.',
    'Kalbinin sesi ile aklının sesi çatışıyor. Ruhuna güven, o her zaman doğru yolu bilir.',
    'İlişkilerde samimiyet ve açıklık fetişi yapacaksın. Bu gün söylemeliysen söyle.',
    'Aşk, aylar sonra gelecek ama hazırlanma süreci bugün başlıyor. Kendine yatırım yap.',
  ],
  career: [
    'İş cephesinde fırsat kapısı açılıyor. Başvuru yap, teklif sun, yeni proje başlat.',
    'Ekip çalışması vurgulu. Yalnız hareket etmek yerine işbirliğini tercih et.',
    'Sabırla çalış, sonuçlar haftanın sonunda göz bebeğine oturacak.',
    'Para konusunda beklenmedik bir şans gelecek. Bunu rasyonel bir şekilde değerlendir.',
    'Yeni bir iş teklifi veya müşteri gelme ihtimali yüksek. Cevap vermeden önce düşün ama çok durakla.',
    'Finansal kararlarında cesur ol. Korkunun seni paraliz etmemesine izin ver.',
    'Kariyer basamağı tırmanacak mısın? Evet, ama sıradaki adımın ne olduğunu bilmelisin.',
    'İş ve özel hayat arasında bir denge kurmak zorunda kalacaksın. Hangisine daha çok enerji ver?',
    'Müşteri veya patron seni gözlüyor. Bu an bunu göstermek için mükemmel, performans eksik yapma.',
    'Yeni bir proje veya venture sana yaklaşıyor. Riski hesapla ama fırsatı kaçırma.',
    'Rekabet ortamında çevik ol. Hızlı hareket edenler kazanacak, geç kalanlar geride kalacak.',
    'Finansal çıkmazı geçmek için yaratıcı çözüm gereklidir. Düşünmeye başla şimdi.',
  ],
  health: [
    'Dinlenme kritik. Vücudunu dinle, ihtiyacı olan şeyleri yap.',
    'Meditasyon ve yoga günlük rutinin olsun. Ruh dengesi fizik sağlığı etkiliyor.',
    'Beslenmeye dikkat et, kemik ve kas güçlendir.',
    'Stres seviyelerin yükseliyor. Rahatlamak için bir şeyler yap — yürüyüş, kitap, müzik.',
    'Enerji düşüklüğü hissediyorsan, C vitamini ve D vitamini al. Vücut sana bunu söylüyor.',
    'Uyku kaliteni artır. Gece yatış saatini erkene al, sabah kendini daha güçlü hisseteceksin.',
    'Hareket et! Statik kalmanın yeri yok. Beden senin ruha geri dökmek istiyor.',
    'Ağrı veya rahatsızlık varsa doktoru çağırma vaktı gelmiş olabilir. Erteleme yapma.',
    'Antistres aktivitelerine yönél. Sevdiğin hobi bugün daha iyileştirici olacak.',
    'Beyin ve beden tükenmiş. Bu hafta çalışma tempını azalt, bir gün tamamen dinlen.',
    'Toksinleri temizleyin. Bol su iç, sağlıklı yemek ye, zararlı alışkanlıklardan uzak dur.',
    'Bağışıklık sistemin zayıflıyor. Vitamin supplementi almayı düşün veya doktor danış.',
  ],
};

export default function DailyFortune() {
  const [reading, setReading] = useState<DailyReading | null>(null);
  const [selectedZodiac, setSelectedZodiac] = useState('Koç');

  useEffect(() => {
    generateDailyReading(selectedZodiac);
  }, [selectedZodiac]);

  const generateDailyReading = (zodiac: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dateStr = today.toLocaleDateString('tr-TR');
    
    // Burç özelliklerini al
    const traits = ZODIAC_TRAITS[zodiac as keyof typeof ZODIAC_TRAITS] || ZODIAC_TRAITS['Koç'];
    
    // Hemen her gün değişecek şekilde seed oluştur
    const seed = today.getTime();
    const seededRandom = (index: number) => {
      const x = Math.sin(seed + index) * 10000;
      return x - Math.floor(x);
    };

    const reading: DailyReading = {
      date: dateStr,
      zodiac: zodiac,
      mainMessage: traits.mainMessages[Math.floor(seededRandom(0) * traits.mainMessages.length)],
      love: DAILY_READINGS['love'][Math.floor(seededRandom(2) * DAILY_READINGS['love'].length)],
      career: DAILY_READINGS['career'][Math.floor(seededRandom(3) * DAILY_READINGS['career'].length)],
      health: DAILY_READINGS['health'][Math.floor(seededRandom(4) * DAILY_READINGS['health'].length)],
      lucky: {
        number: Math.floor(seededRandom(5) * 31) + 1,
        hour: `${Math.floor(seededRandom(6) * 12) + 1}:${seededRandom(7) > 0.5 ? '00' : '30'} ${seededRandom(8) > 0.5 ? 'AM' : 'PM'}`,
        element: traits.element,
      },
    };

    setReading(reading);
  };

  const zodiacList = ['Koç', 'Boğa', 'İkizler', 'Yengeç', 'Aslan', 'Başak', 'Terazi', 'Akrep', 'Yay', 'Oğlak', 'Kova', 'Balık'];

  return (
    <div className="space-y-8">
      {/* Başlık */}
      <div className="text-center space-y-3">
        <h2 className="text-5xl font-bold text-transparent bg-gradient-to-r from-yellow-300 via-purple-400 to-pink-400 bg-clip-text">
          ☀️ GÜNÜN FALI ☀️
        </h2>
        <p className="text-yellow-200 text-lg">Bugünün sana getireceği tüm enerji ve mesajlar</p>
      </div>

      {/* Burç Seçim */}
      <div className="flex gap-2 justify-center flex-wrap">
        {zodiacList.map((zodiac) => (
          <button
            key={zodiac}
            onClick={() => setSelectedZodiac(zodiac)}
            className={`px-4 py-2 rounded-full font-semibold transition-all ${
              selectedZodiac === zodiac
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white scale-105 shadow-lg'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {zodiac}
          </button>
        ))}
      </div>

      {reading && (
        <div className="space-y-6">
          {/* Tarih ve Genel Mesaj */}
          <div className="bg-gradient-to-r from-purple-900/60 to-indigo-900/60 border-2 border-purple-400/60 rounded-2xl p-8 backdrop-blur-sm text-center">
            <div className="text-sm text-purple-300 font-semibold uppercase tracking-widest mb-2">
              {reading.date} - {reading.zodiac} Burcu
            </div>
            <h3 className="text-3xl font-bold text-yellow-300 mb-4">✨ Günün Mesajı ✨</h3>
            <p className="text-white text-xl leading-relaxed italic">{reading.mainMessage}</p>
          </div>

          {/* Yaşam Alanları */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Aşk */}
            <div className="bg-gradient-to-br from-pink-900/50 to-rose-900/50 border border-pink-400/40 rounded-xl p-6 hover:scale-105 transition-transform">
              <div className="text-5xl mb-3">💕</div>
              <h4 className="text-pink-300 font-bold uppercase tracking-wider text-sm mb-3">Aşk & İlişkiler</h4>
              <p className="text-pink-100 leading-relaxed">{reading.love}</p>
            </div>

            {/* Kariyer */}
            <div className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 border border-green-400/40 rounded-xl p-6 hover:scale-105 transition-transform">
              <div className="text-5xl mb-3">💼</div>
              <h4 className="text-green-300 font-bold uppercase tracking-wider text-sm mb-3">Kariyer & Para</h4>
              <p className="text-green-100 leading-relaxed">{reading.career}</p>
            </div>

            {/* Sağlık */}
            <div className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 border border-blue-400/40 rounded-xl p-6 hover:scale-105 transition-transform">
              <div className="text-5xl mb-3">🌟</div>
              <h4 className="text-blue-300 font-bold uppercase tracking-wider text-sm mb-3">Sağlık & Enerji</h4>
              <p className="text-blue-100 leading-relaxed">{reading.health}</p>
            </div>
          </div>

          {/* Şans Bilgileri */}
          <div className="bg-gradient-to-r from-yellow-900/40 to-amber-900/40 border border-yellow-400/40 rounded-2xl p-6">
            <h4 className="text-yellow-300 font-bold uppercase tracking-wider text-sm mb-4 text-center">
              🍀 Bugünün Şans Faktörleri 🍀
            </h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-yellow-400 mb-1">{reading.lucky.number}</div>
                <div className="text-xs text-yellow-300 uppercase tracking-wider">Şans Numarası</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-yellow-400 mb-1">{reading.lucky.hour}</div>
                <div className="text-xs text-yellow-300 uppercase tracking-wider">Şans Saati</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-yellow-400 mb-1">{reading.lucky.element}</div>
                <div className="text-xs text-yellow-300 uppercase tracking-wider">Egemen Element</div>
              </div>
            </div>
          </div>

          {/* Yenile Butonu */}
          {/* Silindi - 24 saatte bir değişiyor */}
        </div>
      )}
    </div>
  );
}
