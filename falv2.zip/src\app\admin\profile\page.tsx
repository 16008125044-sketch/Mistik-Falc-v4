'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

interface PendingApplication {
  id: string;
  applicant_address: string;
  name: string;
  bio: string;
  specialties: string[];
}

interface UserProfile {
  id: string;
  wallet_address: string;
  name: string;
  is_banned: boolean;
  is_witch: boolean;
}

export default function AdminProfilePage() {
  const router = useRouter();
  const [userAddress, setUserAddress] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [searchUser, setSearchUser] = useState('');
  const [userLoading, setUserLoading] = useState(false);

  useEffect(() => {
    checkAdmin();
  }, []);

  const checkAdmin = async () => {
    try {
      if (typeof window !== 'undefined' && (window as any).freighter) {
        const publicKey = await (window as any).freighter.getPublicKey();
        setUserAddress(publicKey);

        const { data } = await supabase
          .from('admins')
          .select('*')
          .eq('wallet_address', publicKey)
          .single();

        if (data) {
          setIsAdmin(true);
          getPendingCount();
        } else {
          router.push('/');
        }
      }
    } catch (err) {
      console.error('Admin check hatası:', err);
      router.push('/');
    } finally {
      setLoading(false);
    }
  };

  const getPendingCount = async () => {
    try {
      const { count } = await supabase
        .from('witch_applications')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      setPendingCount(count || 0);
    } catch (err) {
      console.error('Pending sayısı hatası:', err);
    }
  };

  const searchUsers = async () => {
    if (!searchUser.trim()) return;
    
    setUserLoading(true);
    try {
      const { data } = await supabase
        .from('user_profiles')
        .select('*')
        .or(`wallet_address.ilike.%${searchUser}%,name.ilike.%${searchUser}%`);

      setUsers(data || []);
    } catch (err) {
      console.error('Kullanıcı arama hatası:', err);
    } finally {
      setUserLoading(false);
    }
  };

  const toggleBan = async (userId: string, isBanned: boolean) => {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ is_banned: !isBanned })
        .eq('id', userId);

      if (error) throw error;
      
      setUsers(users.map(u => 
        u.id === userId ? { ...u, is_banned: !isBanned } : u
      ));
    } catch (err) {
      console.error('Ban hatası:', err);
      alert('Ban işlemi başarısız');
    }
  };

  const toggleWitchBadge = async (userId: string, isWitch: boolean) => {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ is_witch: !isWitch })
        .eq('id', userId);

      if (error) throw error;
      
      setUsers(users.map(u => 
        u.id === userId ? { ...u, is_witch: !isWitch } : u
      ));
    } catch (err) {
      console.error('Rozet hatası:', err);
      alert('Rozet işlemi başarısız');
    }
  };

  const logout = async () => {
    if (typeof window !== 'undefined' && (window as any).freighter) {
      try {
        await (window as any).freighter.disconnect?.();
      } catch (err) {
        console.error('Disconnect hatası:', err);
      }
    }
    router.push('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <p className="text-purple-300">Yükleniyor...</p>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="text-purple-400 hover:text-purple-300 mb-4 inline-block">
            ← Ana Sayfaya Dön
          </Link>
        </div>

        <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-8">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">👨‍💼</div>
            <h1 className="text-3xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text mb-2">
              Admin Paneli
            </h1>
            <p className="text-slate-400">Yönetici Profili</p>
          </div>

          <div className="space-y-6 mb-8">
            <div className="bg-slate-900/50 rounded-lg p-6 border border-purple-500/30">
              <label className="text-sm text-slate-400 block mb-2">Cüzdan Adresi</label>
              <p className="text-white font-mono text-sm break-all">{userAddress}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-900/50 rounded-lg p-6 border border-purple-500/30">
                <div className="text-2xl font-bold text-purple-300">{pendingCount}</div>
                <p className="text-slate-400 text-sm mt-2">Bekleyen Başvuru</p>
              </div>

              <div className="bg-slate-900/50 rounded-lg p-6 border border-purple-500/30">
                <div className="text-2xl font-bold text-green-400">✅</div>
                <p className="text-slate-400 text-sm mt-2">Admin Statüsü</p>
              </div>
            </div>
          </div>

          <div className="space-y-3 mb-8">
            <Link
              href="/admin/witches"
              className="block w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold rounded-lg transition text-center"
            >
              📋 Başvuruları Yönet
            </Link>

            <button
              onClick={() => {
                getPendingCount();
              }}
              className="w-full px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-lg transition"
            >
              🔄 Yenile
            </button>

            <button
              onClick={logout}
              className="w-full px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition"
            >
              🚪 Çıkış Yap
            </button>
          </div>

          <div className="bg-purple-900/50 border border-purple-500/50 rounded-xl p-6 mb-8">
            <h2 className="text-xl font-bold text-purple-300 mb-4">👑 Admin Ekle</h2>
            <div className="space-y-3">
              <div>
                <label className="text-sm text-slate-400 block mb-1">Cüzdan Adresi</label>
                <input
                  type="text"
                  placeholder="GDYW..."
                  defaultValue="GDYWAIW7PUWCXAQ3PN6G6HHU76IRBP43T7XBXE5FHUNRQU2LKT5BCERO"
                  id="adminWallet"
                  className="w-full bg-slate-900/50 border border-slate-700 rounded px-4 py-2 text-white text-sm"
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 block mb-1">İsim</label>
                <input
                  type="text"
                  placeholder="Admin adı"
                  defaultValue="kral baba"
                  id="adminName"
                  className="w-full bg-slate-900/50 border border-slate-700 rounded px-4 py-2 text-white text-sm"
                />
              </div>
              <button
                onClick={async () => {
                  const { addAdmin } = await import('@/app/admin/actions/addAdmin');
                  const wallet = (document.getElementById('adminWallet') as HTMLInputElement).value;
                  const name = (document.getElementById('adminName') as HTMLInputElement).value;
                  
                  if (!wallet.trim() || !name.trim()) {
                    alert('Lütfen tüm alanları doldurun');
                    return;
                  }
                  
                  const result = await addAdmin(wallet, name);
                  if (result.success) {
                    alert(`✅ ${name} admin olarak eklendi!`);
                    (document.getElementById('adminWallet') as HTMLInputElement).value = '';
                    (document.getElementById('adminName') as HTMLInputElement).value = '';
                  } else {
                    alert(`❌ Hata: ${result.error}`);
                  }
                }}
                className="w-full px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold rounded transition"
              >
                ➕ Admin Ekle
              </button>
            </div>
          </div>

          <div className="bg-blue-900/30 border border-blue-500/30 rounded-lg p-4 text-sm text-blue-300">
            <p>💡 İpucu: "Başvuruları Yönet" butonundan cadı başvurularını onaylayabilir veya reddedebilirsiniz.</p>
          </div>

          <div className="bg-orange-900/50 border border-orange-500/50 rounded-xl p-6 mt-8">
            <h2 className="text-xl font-bold text-orange-300 mb-4">👥 Kullanıcı Yönetimi</h2>
            <div className="space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Kullanıcı ara (cüzdan veya isim)..."
                  value={searchUser}
                  onChange={(e) => setSearchUser(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && searchUsers()}
                  className="flex-1 bg-slate-900/50 border border-slate-700 rounded px-4 py-2 text-white text-sm"
                />
                <button
                  onClick={searchUsers}
                  disabled={userLoading}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-600 text-white font-bold rounded transition"
                >
                  🔍 Ara
                </button>
              </div>

              {users.length > 0 && (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {users.map((user) => (
                    <div
                      key={user.id}
                      className={`bg-slate-900/50 border rounded-lg p-4 ${
                        user.is_banned ? 'border-red-500/50' : 'border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="text-xs text-slate-400 font-mono mb-1">
                            ID: {user.id}
                          </div>
                          <div className="text-sm font-semibold text-white mb-1">
                            {user.name || 'İsimsiz'}
                          </div>
                          <div className="text-xs text-slate-400 font-mono break-all">
                            {user.wallet_address}
                          </div>
                        </div>
                        <div className="flex gap-1 ml-2">
                          {user.is_banned && (
                            <span className="px-2 py-1 bg-red-600/30 text-red-300 text-xs rounded">
                              🚫 Banlı
                            </span>
                          )}
                          {user.is_witch && (
                            <span className="px-2 py-1 bg-purple-600/30 text-purple-300 text-xs rounded">
                              🧙 Cadı
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-2 mt-3">
                        <button
                          onClick={() => toggleBan(user.id, user.is_banned)}
                          className={`flex-1 px-3 py-1 text-xs font-bold rounded transition ${
                            user.is_banned
                              ? 'bg-green-600/50 hover:bg-green-600/70 text-green-300'
                              : 'bg-red-600/50 hover:bg-red-600/70 text-red-300'
                          }`}
                        >
                          {user.is_banned ? '✅ Ban Kaldır' : '🚫 Banla'}
                        </button>
                        <button
                          onClick={() => toggleWitchBadge(user.id, user.is_witch)}
                          className={`flex-1 px-3 py-1 text-xs font-bold rounded transition ${
                            user.is_witch
                              ? 'bg-slate-600/50 hover:bg-slate-600/70 text-slate-300'
                              : 'bg-purple-600/50 hover:bg-purple-600/70 text-purple-300'
                          }`}
                        >
                          {user.is_witch ? '❌ Rozet Kaldır' : '✨ Rozet Ver'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {users.length === 0 && searchUser && !userLoading && (
                <p className="text-slate-400 text-sm text-center py-4">Kullanıcı bulunamadı</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
