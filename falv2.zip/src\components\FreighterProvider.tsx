'use client';

import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { 
  getAddress, 
  getNetworkDetails, 
  signTransaction,
  requestAccess,
  WatchWalletChanges 
} from '@stellar/freighter-api';
import { createClient } from '@supabase/supabase-js';

interface FreighterContextType {
  address: string | null;
  network: string | null;
  networkPassphrase: string | null;
  networkUrl: string | null;
  sorobanRpcUrl: string | null;
  isConnected: boolean;
  isLoading: boolean;
  error: string | null;
  disconnect: () => void;
  balance: string;
  connect: () => Promise<void>;
  signTransaction: (tx: string) => Promise<string>;
}

const FreighterContext = createContext<FreighterContextType | undefined>(undefined);

export function FreighterProvider({ children }: { children: React.ReactNode }) {
  const [address, setAddress] = useState<string | null>(null);
  const [network, setNetwork] = useState<string | null>(null);
  const [networkPassphrase, setNetworkPassphrase] = useState<string | null>(null);
  const [networkUrl, setNetworkUrl] = useState<string | null>(null);
  const [sorobanRpcUrl, setSorobanRpcUrl] = useState<string | null>(null);
  const [isConnectedWallet, setIsConnectedWallet] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [balance, setBalance] = useState<string>('0');
  const [lastBalanceFetch, setLastBalanceFetch] = useState<number>(0);
  const [balanceCache, setBalanceCache] = useState<string>('0');
  const watcherRef = useRef<any>(null);

  const fetchBalance = async (addr: string, rpcUrl: string, forceRefresh: boolean = false) => {
    try {
      // Cache'de 2 dakika kalırsa yenileme
      const now = Date.now();
      const twoMinutes = 2 * 60 * 1000;
      
      if (!forceRefresh && (now - lastBalanceFetch) < twoMinutes) {
        console.log('💾 Cached bakiye kullanılıyor:', balanceCache);
        setBalance(balanceCache);
        return;
      }
      
      console.log('📊 Bakiye fetch ediliyor (fresh):', { addr: addr.slice(0, 10) + '...', rpcUrl });
      
      // Timeout ayarla (10 saniye)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);
      
      const response = await fetch(`${rpcUrl}/accounts/${addr}`, {
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        console.warn('❌ Bakiye API başarısız:', response.status, response.statusText);
        // Cache'den geri dön
        setBalance(balanceCache);
        return;
      }
      const data = await response.json();
      console.log('📦 API Yanıtı:', data);
      const nativeBalance = data.balances?.find(
        (balance: any) => balance.asset_type === 'native'
      );
      if (nativeBalance) {
        console.log('✅ Bakiye alındı:', nativeBalance.balance, 'XLM');
        setBalance(nativeBalance.balance);
        setBalanceCache(nativeBalance.balance);
        setLastBalanceFetch(now);
        
        // Freighter bakiyesini Supabase'e kaydet
        const supabase = createClient(
          process.env.NEXT_PUBLIC_SUPABASE_URL || '',
          process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
        );
        
        try {
          const balanceNum = parseFloat(nativeBalance.balance);
          const { error } = await supabase
            .from('user_profiles')
            .upsert(
              {
                wallet_address: addr,
                xlm_balance: balanceNum,
                updated_at: new Date().toISOString()
              },
              { onConflict: 'wallet_address' }
            );
          
          if (error) {
            console.warn('⚠️ Supabase bakiye güncellenirken hata:', error.message);
          } else {
            console.log('📝 Supabase bakiyesi güncellendi:', balanceNum);
          }
        } catch (supabaseErr) {
          console.warn('⚠️ Supabase güncellemesi başarısız:', supabaseErr);
        }
      } else {
        console.warn('⚠️ Native balance bulunamadı, balances:', data.balances);
        setBalance(balanceCache);
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.error('❌ Bakiye isteği timeout (10s), cache kullanılıyor');
      } else {
        console.error('❌ Bakiye alınamadı:', err.message);
      }
      // Hata durumunda cache'den geri dön
      setBalance(balanceCache);
    }
  };

  const connect = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Freighter'a erişim iste
      await requestAccess();
      
      // Adres al
      const addressResult = await getAddress();
      if (addressResult.error) {
        throw new Error(addressResult.error);
      }
      
      // Ağ bilgilerini al
      const networkResult = await getNetworkDetails();
      if (networkResult.error) {
        throw new Error(networkResult.error);
      }
      
      setAddress(addressResult.address || null);
      setNetwork(networkResult.network);
      setNetworkPassphrase(networkResult.networkPassphrase);
      
      // Horizon URL'i belirle (Testnet vs Mainnet)
      let horizonUrl = networkResult.networkUrl || 'https://horizon-testnet.stellar.org';
      if (networkResult.network?.includes('mainnet') || networkResult.network?.includes('public')) {
        horizonUrl = 'https://horizon.stellar.org';
      }
      
      setNetworkUrl(horizonUrl);
      setSorobanRpcUrl(networkResult.sorobanRpcUrl || null);
      setIsConnectedWallet(true);
      
      console.log('🌐 Ağ seçildi:', { network: networkResult.network, horizonUrl });
      
      // Bakiye al
      if (addressResult.address) {
        await fetchBalance(addressResult.address, horizonUrl);
      }
      
      setIsLoading(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Bağlantı başarısız');
      setIsLoading(false);
    }
  };

  const handleSignTransaction = async (tx: string): Promise<string> => {
    try {
      const result = await signTransaction(tx, {
        networkPassphrase: networkPassphrase || '',
      });
      if (result.error) {
        throw new Error(result.error);
      }
      return result.signedTxXdr || '';
    } catch (err) {
      throw err;
    }
  };

  // Sadece ilk yükleme - periyodik refresh yapma (rate limit nedeniyle)
  useEffect(() => {
    if (address && networkUrl && isConnectedWallet) {
      console.log('🔄 İlk bakiye yükleniyor...');
      fetchBalance(address, networkUrl, true);
    }
  }, [address, networkUrl, isConnectedWallet]);

  const disconnect = () => {
    try {
      // Watcher'ı durdur
      if (watcherRef.current) {
        watcherRef.current.stop();
        watcherRef.current = null;
      }
    } catch (err) {
      console.error('Watcher durdurulurken hata:', err);
    }

    // Çıkış öncesi mevcut adresi al
    const currentAddress = address;

    // Local state'i tamamen temizle
    setAddress(null);
    setNetwork(null);
    setNetworkPassphrase(null);
    setNetworkUrl(null);
    setSorobanRpcUrl(null);
    setIsConnectedWallet(false);
    setBalance('0');
    setError(null);
    setBalanceCache('0');
    setLastBalanceFetch(0);

    // Cüzdan verilerini sil
    if (currentAddress) {
      localStorage.removeItem(`freighter_${currentAddress}_wallet_name`);
      localStorage.removeItem(`freighter_${currentAddress}_profile_image`);
      localStorage.removeItem(`level_${currentAddress}`);
    }

    // Tüm freighter verilerini sil (geriye uyumluluk)
    const keysToRemove = Object.keys(localStorage).filter(key => 
      key.startsWith('freighter_') || key.startsWith('level_')
    );
    keysToRemove.forEach(key => localStorage.removeItem(key));

    console.log('🔐 Cüzdan başarıyla çıkış yaptı');
    
    // Ana sayfaya yönlendir ve cüzdan bağlanmasını iste
    setTimeout(() => {
      window.location.href = '/';
    }, 300);
  };

  useEffect(() => {
    const checkWalletConnection = async () => {
      try {
        setIsLoading(true);
        
        // İlk olarak adres ve ağ bilgisini al
        const addressResult = await getAddress();
        
        if (!addressResult.address) {
          setIsLoading(false);
          return;
        }

        // Ağ bilgilerini al
        const networkResult = await getNetworkDetails();
        
        setAddress(addressResult.address);
        setNetwork(networkResult.network);
        setNetworkPassphrase(networkResult.networkPassphrase);
        setNetworkUrl(networkResult.networkUrl);
        setSorobanRpcUrl(networkResult.sorobanRpcUrl || null);
        setIsConnectedWallet(true);
        
        // Bakiye al
        if (networkResult.networkUrl) {
          await fetchBalance(addressResult.address, networkResult.networkUrl);
        }

        setIsLoading(false);

        // Cüzdan değişikliklerini izle
        const watcher = new WatchWalletChanges(2000);
        watcherRef.current = watcher;
        watcher.watch((walletInfo) => {
          if (walletInfo && walletInfo.address) {
            // Eğer cüzdan adresi değişirse, kullanıcıyı çıkart
            if (walletInfo.address !== addressResult.address) {
              console.log('Cüzdan değiştirildi. Sistem çıkış yapıyor...');
              disconnect();
              return;
            }
            
            setAddress(walletInfo.address);
            setNetwork(walletInfo.network || null);
            setNetworkPassphrase(walletInfo.networkPassphrase || null);
            
            // Cüzdan değişildiğinde bakiye yenile
            if (networkResult?.networkUrl) {
              fetchBalance(walletInfo.address, networkResult.networkUrl);
            }
          }
        });

        // Otomatik bakiye refresh kaldırıldı - Supabase'den manuel yükleme kullanılıyor

        return () => {
          if (watcherRef.current) {
            watcherRef.current.stop();
          }
        };
      } catch (err) {
        console.error('Cüzdan kontrolü sırasında hata:', err);
        setIsLoading(false);
      }
    };

    checkWalletConnection();

    return () => {
      if (watcherRef.current) {
        watcherRef.current.stop();
      }
    };
  }, []);

  return (
    <FreighterContext.Provider
      value={{
        address,
        network,
        networkPassphrase,
        networkUrl,
        sorobanRpcUrl,
        isConnected: isConnectedWallet,
        isLoading,
        error,
        disconnect,
        balance,
        connect,
        signTransaction: handleSignTransaction,
      }}
    >
      {children}
    </FreighterContext.Provider>
  );
}

export function useFreighter() {
  const context = useContext(FreighterContext);
  if (!context) {
    throw new Error('useFreighter must be used within FreighterProvider');
  }
  return context;
}
