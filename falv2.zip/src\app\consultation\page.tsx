'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useFreighter } from '@/components/FreighterProvider';
import { supabase } from '@/lib/supabase';

interface Question {
  id: string;
  asker: string;
  question: string;
  timestamp: number;
  answer?: string;
  answered_at?: number;
  is_ai_answer?: boolean;
}

const QUESTION_COST = 20;

export default function ConsultationPage() {
  const { address, balance } = useFreighter();

  const [questions, setQuestions] = useState<Question[]>([]);
  const [newQuestion, setNewQuestion] = useState('');
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isAnswering, setIsAnswering] = useState(false);

  const loadQuestions = async () => {
    try {
      const { data, error: err } = await supabase
        .from('consultation_questions')
        .select('*')
        .order('timestamp', { ascending: false });

      if (err) throw err;
      setQuestions(data || []);
    } catch (err) {
      console.error('Sorular yüklenemedi:', err);
    }
  };

  useEffect(() => {
    loadQuestions();
    const interval = setInterval(loadQuestions, 5000);
    return () => clearInterval(interval);
  }, []);

  const getAIResponse = async (question: string): Promise<string> => {
    try {
      const response = await fetch('/api/ai-answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question }),
      });

      if (!response.ok) throw new Error('AI cevap alınamadı');

      const data = await response.json();
      return data.answer || 'Üzgünüm, sorunuza cevap veremiyorum.';
    } catch (err) {
      return 'Sistemde bir hata oluştu.';
    }
  };

  const handleAskQuestion = async () => {
    if (!address || !newQuestion.trim()) {
      setError('Lütfen soru yazınız');
      return;
    }

    const balanceNum = typeof balance === 'string' ? parseFloat(balance) : (balance || 0);
    if (balanceNum < QUESTION_COST) {
      setError('Yetersiz bakiye');
      return;
    }

    setIsLoading(true);
    try {
      const { data, error: dbError } = await supabase
        .from('consultation_questions')
        .insert([{
          asker: address,
          question: newQuestion.trim(),
          timestamp: Date.now(),
          is_ai_answer: false,
        }])
        .select();

      if (dbError) throw dbError;

      setIsAnswering(true);
      const aiAnswer = await getAIResponse(newQuestion.trim());

      const { error: updateError } = await supabase
        .from('consultation_questions')
        .update({
          answer: aiAnswer,
          answered_at: Date.now(),
          is_ai_answer: true,
        })
        .eq('id', data[0].id);

      if (updateError) throw updateError;

      setNewQuestion('');
      setSuccess('Soru gönderildi');

      setTimeout(() => loadQuestions(), 500);
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      setError('Hata: ' + (err instanceof Error ? err.message : 'Bilinmeyen'));
    } finally {
      setIsLoading(false);
      setIsAnswering(false);
    }
  };

  if (!address) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-purple-300 mb-4">Soru sormak için cüzdan bağlayınız.</p>
          <Link href="/" className="text-blue-400 hover:text-blue-300 underline">
            Ana sayfaya dön
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-violet-950 to-indigo-950 p-6">
      <div className="max-w-6xl mx-auto">
        {error && <div className="mb-4 p-4 rounded-lg bg-red-500/20 text-red-300">{error}</div>}
        {success && <div className="mb-4 p-4 rounded-lg bg-green-500/20 text-green-300">{success}</div>}

        <div className="mb-8">
          <Link href="/" className="text-purple-400 mb-4 inline-block">← Ana Sayfa</Link>
          <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text mb-2">
            ❓ Soru Sor - Yapay Zeka Cevapla
          </h1>
          <p className="text-slate-300">Herhangi bir soruyu sor ve yapay zeka sana yardımcı olsun</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6">
              <h2 className="text-xl font-bold text-purple-300 mb-4">📋 Sorular ({questions.length})</h2>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {questions.length === 0 ? (
                  <p className="text-slate-400 text-sm">Henüz soru yok</p>
                ) : (
                  questions.map(q => (
                    <button
                      key={q.id}
                      onClick={() => setSelectedQuestion(q)}
                      className={`w-full p-3 rounded-lg text-left text-sm ${
                        selectedQuestion?.id === q.id ? 'bg-purple-600 text-white' : q.answer ? 'bg-green-500/20 text-green-300' : 'bg-slate-700/50'
                      }`}
                    >
                      <div className="truncate">{(q.asker || '?').slice(0, 10)}...</div>
                      <div className="text-xs opacity-75">{q.question.slice(0, 40)}...</div>
                      {q.answer && <div className="text-xs mt-1">🤖 AI</div>}
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="md:col-span-2">
            {selectedQuestion ? (
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6">
                <h2 className="text-xl font-bold text-purple-300 mb-4">❓ Soru</h2>
                <div className="bg-slate-800/50 p-4 rounded-lg text-white mb-4">{selectedQuestion.question}</div>
                {selectedQuestion.answer ? (
                  <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                    <div className="text-sm text-green-400 mb-2">🤖 AI Cevabı</div>
                    <div className="text-white text-sm whitespace-pre-wrap">{selectedQuestion.answer}</div>
                  </div>
                ) : (
                  <div className="text-center text-yellow-400">⏳ Cevaplanıyor...</div>
                )}
              </div>
            ) : (
              <div className="bg-purple-950/50 border border-purple-500/50 rounded-xl p-6">
                <h2 className="text-xl font-bold text-purple-300 mb-4">✍️ Soru Sor</h2>
                <textarea
                  value={newQuestion}
                  onChange={(e) => setNewQuestion(e.target.value)}
                  placeholder="Sorunuzu yazınız..."
                  className="w-full p-4 rounded-lg bg-slate-800 text-white border border-purple-500/50 mb-4 resize-none"
                  rows={8}
                />
                <div className="mb-4 p-3 rounded-lg bg-slate-800/50 text-sm">
                  <div>💰 Bakiye: <span className="text-yellow-400 font-bold">{typeof balance === 'string' ? parseFloat(balance).toFixed(2) : balance} XLM</span></div>
                  <div className="mt-1">❓ Ücreti: <span className="text-orange-400">{QUESTION_COST} XLM</span></div>
                </div>
                <button
                  onClick={handleAskQuestion}
                  disabled={!newQuestion.trim() || isLoading}
                  className="w-full px-4 py-3 bg-purple-600 hover:bg-purple-700 disabled:bg-slate-600 text-white font-bold rounded-lg"
                >
                  {isLoading ? 'İşleniyor...' : '🚀 Gönder'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
