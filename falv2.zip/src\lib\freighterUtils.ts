// Freighter Utilities - İşlem ve İmzalama Fonksiyonları

import {
  requestAccess,
  signTransaction,
  signMessage,
  addToken,
  getAddress,
} from '@stellar/freighter-api';

/**
 * Cüzdan erişimi iste (ilk bağlantı)
 */
export async function requestWalletAccess() {
  try {
    const result = await requestAccess();
    if (result.error) {
      throw new Error(result.error);
    }
    return result.address;
  } catch (error) {
    throw new Error(`Cüzdan erişimi başarısız: ${error}`);
  }
}

/**
 * Kullanıcı adresi al
 */
export async function getWalletAddress() {
  try {
    const result = await getAddress();
    if (result.error) {
      throw new Error(result.error);
    }
    return result.address;
  } catch (error) {
    throw new Error(`Adres alınamadı: ${error}`);
  }
}

/**
 * İşlemi imzala (networkPassphrase kullan)
 */
export async function signTx(
  xdrString: string,
  networkPassphrase: string,
  address?: string
) {
  try {
    const result = await signTransaction(xdrString, {
      networkPassphrase,
      address,
    });

    if (result.error) {
      throw new Error(result.error);
    }

    return result.signedTxXdr;
  } catch (error) {
    throw new Error(`İşlem imzalama başarısız: ${error}`);
  }
}

/**
 * Mesaj imzala
 */
export async function signMsg(message: string, address: string) {
  try {
    const result = await signMessage(message, { address });

    if (result.error) {
      throw new Error(result.error);
    }

    return result.signedMessage;
  } catch (error) {
    throw new Error(`Mesaj imzalama başarısız: ${error}`);
  }
}

/**
 * Soroban token ekle
 */
export async function addSorobanToken(
  contractId: string,
  networkPassphrase?: string
) {
  try {
    const result = await addToken({
      contractId,
      networkPassphrase,
    });

    if (result.error) {
      throw new Error(result.error);
    }

    return result.contractId;
  } catch (error) {
    throw new Error(`Token ekleme başarısız: ${error}`);
  }
}

/**
 * Tarot okuma kaydını blockchain'e yaz
 */
export async function recordTarotReadingOnChain(
  userAddress: string,
  cardName: string,
  readingText: string,
  timestamp: number
) {
  const reading = {
    userAddress,
    cardName,
    readingText,
    timestamp,
    recordedAt: new Date().toISOString(),
  };

  // Local storage'a ekle
  if (typeof window !== 'undefined') {
    const existingReadings = localStorage.getItem('tarotReadings');
    const readings = existingReadings ? JSON.parse(existingReadings) : [];
    readings.push(reading);
    localStorage.setItem('tarotReadings', JSON.stringify(readings));
  }

  return reading;
}

/**
 * Tarot okuma geçmişini getir
 */
export function getTarotReadingHistory(userAddress?: string) {
  if (typeof window === 'undefined') return [];

  const readings = localStorage.getItem('tarotReadings');
  if (!readings) return [];

  const allReadings = JSON.parse(readings);

  if (userAddress) {
    return allReadings.filter((r: any) => r.userAddress === userAddress);
  }

  return allReadings;
}
