'use client';

import React, { useState, useEffect } from 'react';

export default function DebugPage() {
  const [storageData, setStorageData] = useState<Record<string, string>>({});
  const [filter, setFilter] = useState('');

  useEffect(() => {
    const data: Record<string, string> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        data[key] = localStorage.getItem(key) || '';
      }
    }
    setStorageData(data);

    // Query param kontrol
    const params = new URLSearchParams(window.location.search);
    
    // Tüm localStorage'ı sil
    if (params.get('clearAll') === 'true') {
      localStorage.clear();
      alert('✅ Tüm localStorage verileri silindi!');
      window.location.href = '/debug';
      return;
    }
    
    // Tüm karakterleri falcı yap
    if (params.get('makeAllAstrologers') === 'true') {
      let count = 0;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('profile_') && key.endsWith('_name')) {
          const addressPart = key.replace('profile_', '').replace('_name', '');
          localStorage.setItem(`profile_${addressPart}_isAstrologer`, 'true');
          count++;
        }
      }
      alert(`✅ ${count} karakter falcı yapıldı!`);
      window.location.href = '/debug';
      return;
    }
  }, []);

  const filteredData = Object.entries(storageData).filter(([key]) =>
    key.toLowerCase().includes(filter.toLowerCase())
  );

  const handleClearAll = () => {
    if (confirm('Tüm localStorage verileri silinecek. Emin misin?')) {
      localStorage.clear();
      setStorageData({});
      alert('✅ Temizlendi');
    }
  };

  const handleClearAstrologers = () => {
    if (confirm('Tüm falcı verileri silinecek. Emin misin?')) {
      const toDelete = Object.keys(storageData).filter(key =>
        key.includes('_isAstrologer')
      );
      toDelete.forEach(key => localStorage.removeItem(key));
      
      const newData = { ...storageData };
      toDelete.forEach(key => delete newData[key]);
      setStorageData(newData);
      alert(`✅ ${toDelete.length} falcı verisi silindi`);
    }
  };

  const handleMakeAllAstrologers = () => {
    if (confirm('Tüm karakterleri falcı yapacak. Emin misin?')) {
      let count = 0;
      const newData = { ...storageData };
      
      for (let [key, value] of Object.entries(storageData)) {
        if (key.startsWith('profile_') && key.endsWith('_name')) {
          const addressPart = key.replace('profile_', '').replace('_name', '');
          const isAstrologerKey = `profile_${addressPart}_isAstrologer`;
          
          localStorage.setItem(isAstrologerKey, 'true');
          newData[isAstrologerKey] = 'true';
          count++;
        }
      }
      
      setStorageData(newData);
      alert(`✅ ${count} karakter falcı yapıldı!`);
      window.location.reload();
    }
  };

  const handleRemoveKey = (key: string) => {
    localStorage.removeItem(key);
    const newData = { ...storageData };
    delete newData[key];
    setStorageData(newData);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">🔧 Debug: localStorage</h1>

        {/* İstatistikler */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="bg-blue-900/50 p-4 rounded-lg">
            <div className="text-2xl font-bold">{Object.keys(storageData).length}</div>
            <div className="text-gray-400">Toplam Veri</div>
          </div>
          <div className="bg-purple-900/50 p-4 rounded-lg">
            <div className="text-2xl font-bold">
              {Object.keys(storageData).filter(k => k.includes('_isAstrologer')).length}
            </div>
            <div className="text-gray-400">Falcı Verileri</div>
          </div>
          <div className="bg-green-900/50 p-4 rounded-lg">
            <div className="text-2xl font-bold">
              {Object.keys(storageData).filter(k => k.includes('_isAstrologer') && storageData[k] === 'true').length}
            </div>
            <div className="text-gray-400">Falcı Sayısı</div>
          </div>
          <div className="bg-yellow-900/50 p-4 rounded-lg">
            <div className="text-2xl font-bold">
              {Object.keys(storageData).filter(k => k.includes('profile_') && k.includes('_name')).length}
            </div>
            <div className="text-gray-400">Profil Adları</div>
          </div>
        </div>

        {/* Araçlar */}
        <div className="bg-gray-800/50 p-6 rounded-lg mb-8 space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="localStorage'da ara..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="flex-1 px-4 py-2 bg-gray-700 rounded text-white"
            />
            <button
              onClick={() => setFilter('')}
              className="px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded"
            >
              Temizle
            </button>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => {
                // Tüm profilleri falcı yap
                let count = 0;
                for (let [key, value] of Object.entries(storageData)) {
                  if (key.includes('profile_') && key.includes('_name')) {
                    const addressMatch = key.match(/^profile_(.+)_name$/);
                    if (addressMatch) {
                      const address = addressMatch[1];
                      localStorage.setItem(`profile_${address}_isAstrologer`, 'true');
                      // Mülakat durumunu da set et
                      localStorage.setItem(`profile_${address}_interviewStatus`, 'passed');
                      localStorage.setItem(`profile_${address}_interviewCompletedAt`, Date.now().toString());
                      count++;
                    }
                  }
                }
                alert(`✅ ${count} kişi falcı yapıldı!`);
                window.location.reload();
              }}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded"
            >
              ✨ Tüm Profilleri Falcı Yap
            </button>
            <button
              onClick={handleClearAstrologers}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded"
            >
              ❌ Tüm Falcıları Sil
            </button>
            <button
              onClick={handleClearAll}
              className="px-4 py-2 bg-red-800 hover:bg-red-900 rounded"
            >
              ❌❌ Hepsini Sil
            </button>
          </div>
        </div>

        {/* Veri Tablosu */}
        <div className="bg-gray-800/50 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-700">
                <th className="px-4 py-2 text-left">Anahtar</th>
                <th className="px-4 py-2 text-left">Değer</th>
                <th className="px-4 py-2 text-center">İşlem</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map(([key, value]) => (
                <tr key={key} className="border-t border-gray-700 hover:bg-gray-700/30">
                  <td className="px-4 py-2 font-mono text-sm text-gray-300 break-all">
                    {key}
                  </td>
                  <td className="px-4 py-2">
                    {value.length > 100 ? (
                      <details>
                        <summary className="cursor-pointer text-blue-400">
                          {value.substring(0, 100)}...
                        </summary>
                        <pre className="mt-2 bg-gray-900 p-2 rounded text-xs overflow-auto max-h-48">
                          {value}
                        </pre>
                      </details>
                    ) : (
                      <span className="text-gray-200">{value}</span>
                    )}
                  </td>
                  <td className="px-4 py-2 text-center">
                    <button
                      onClick={() => handleRemoveKey(key)}
                      className="px-2 py-1 bg-red-600 hover:bg-red-700 rounded text-sm"
                    >
                      Sil
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredData.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            Eş leşen veri yok
          </div>
        )}

        {/* Falcı Listesi */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">✨ Tespit Edilen Falcılar</h2>
          <div className="bg-gray-800/50 rounded-lg p-6">
            {(() => {
              const astrologers: any[] = [];
              const seen = new Set<string>();

              for (let [key, value] of Object.entries(storageData)) {
                if (key.includes('_isAstrologer') && value === 'true') {
                  const addressPart = key.replace('profile_', '').replace('_isAstrologer', '');
                  if (!seen.has(addressPart)) {
                    seen.add(addressPart);
                    const name = storageData[`profile_${addressPart}_name`] || 'Bilinmiyor';
                    astrologers.push({ address: addressPart, name });
                  }
                }
              }

              if (astrologers.length === 0) {
                return <p className="text-gray-400">Falcı bulunamadı</p>;
              }

              return (
                <div className="space-y-4">
                  {astrologers.map((ast) => {
                    // Bu falcıya gönderilen soruları bul
                    const receivedQuestionsKey = `profile_${ast.address}_receivedQuestions`;
                    const questions = JSON.parse(storageData[receivedQuestionsKey] || '[]');
                    const unansweredCount = questions.filter((q: any) => !q.answer).length;
                    const answeredCount = questions.filter((q: any) => q.answer).length;

                    return (
                      <div key={ast.address} className="bg-purple-900/30 p-4 rounded-lg">
                        <div className="font-bold text-purple-300">✨ {ast.name}</div>
                        <div className="text-sm text-gray-400 font-mono mb-2">{ast.address}</div>
                        <div className="flex gap-2 text-xs">
                          <span className="bg-yellow-900 px-2 py-1 rounded">❓ Bekleme: {unansweredCount}</span>
                          <span className="bg-green-900 px-2 py-1 rounded">✅ Cevaplı: {answeredCount}</span>
                        </div>
                        {questions.length > 0 && (
                          <details className="mt-2 text-xs text-gray-300">
                            <summary className="cursor-pointer hover:text-gray-200">📋 Soruları Göster ({questions.length})</summary>
                            <div className="mt-2 space-y-2 bg-black/30 p-2 rounded">
                              {questions.map((q: any, idx: number) => (
                                <div key={idx} className="border-l-2 border-purple-500 pl-2 py-1">
                                  <div className="font-mono text-gray-400">
                                    👤 {q.askerName}
                                  </div>
                                  <div className="text-gray-300">Q: {q.question.substring(0, 50)}...</div>
                                  {q.answer && <div className="text-green-400">A: {q.answer.substring(0, 50)}...</div>}
                                </div>
                              ))}
                            </div>
                          </details>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        </div>

        {/* Tüm Karakterler ve isAstrologer Durumu */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">👥 Tüm Karakterler (isAstrologer Durumu)</h2>
          <div className="bg-gray-800/50 rounded-lg p-6">
            {(() => {
              const characters: Record<string, { name: string; isAstrologer: boolean }> = {};

              for (let [key, value] of Object.entries(storageData)) {
                if (key.startsWith('profile_') && key.endsWith('_name')) {
                  const addressPart = key.replace('profile_', '').replace('_name', '');
                  if (!characters[addressPart]) {
                    characters[addressPart] = { name: value, isAstrologer: false };
                  } else {
                    characters[addressPart].name = value;
                  }
                }
                if (key.startsWith('profile_') && key.endsWith('_isAstrologer')) {
                  const addressPart = key.replace('profile_', '').replace('_isAstrologer', '');
                  if (!characters[addressPart]) {
                    characters[addressPart] = { name: 'Bilinmiyor', isAstrologer: value === 'true' };
                  } else {
                    characters[addressPart].isAstrologer = value === 'true';
                  }
                }
              }

              if (Object.keys(characters).length === 0) {
                return <p className="text-gray-400">Karakter bulunamadı</p>;
              }

              return (
                <div className="space-y-2">
                  {Object.entries(characters).map(([address, char]) => (
                    <div key={address} className={`p-3 rounded-lg flex justify-between items-center ${char.isAstrologer ? 'bg-green-900/30 border border-green-500' : 'bg-gray-700/30'}`}>
                      <div>
                        <div className="font-bold">{char.name}</div>
                        <div className="text-xs text-gray-400 font-mono">{address.substring(0, 12)}...</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="text-sm font-bold">
                          {char.isAstrologer ? (
                            <span className="text-green-400">✅ Falcı</span>
                          ) : (
                            <span className="text-gray-400">❌ Falcı Değil</span>
                          )}
                        </div>
                        {!char.isAstrologer && (
                          <button
                            onClick={() => {
                              localStorage.setItem(`profile_${address}_isAstrologer`, 'true');
                              window.location.reload();
                            }}
                            className="px-2 py-1 text-xs bg-green-600 hover:bg-green-700 rounded text-white"
                          >
                            Falcı Yap
                          </button>
                        )}
                        {char.isAstrologer && (
                          <button
                            onClick={() => {
                              localStorage.setItem(`profile_${address}_isAstrologer`, 'false');
                              window.location.reload();
                            }}
                            className="px-2 py-1 text-xs bg-red-600 hover:bg-red-700 rounded text-white"
                          >
                            Falcı Kaldır
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        </div>
      </div>
    </div>
  );
}
