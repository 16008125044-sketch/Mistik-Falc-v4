import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { FreighterProvider } from "@/components/FreighterProvider";
import { LevelProvider } from "@/components/LevelProvider";
import { ProfileProvider } from "@/components/ProfileProvider";
import { LevelDisplay } from "@/components/LevelDisplay";
import { HeaderWrapper } from "@/components/Header";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Seç-İzle Tarot x Freighter",
  description: "Freighter cüzdanı ile entegre Tarot okuma platformu",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-gray-50`}
      >
        <FreighterProvider>
          <ProfileProvider>
            <LevelProvider>
              <HeaderWrapper />
              <main className="py-8">
                {children}
              </main>
              <LevelDisplay />
              <footer className="bg-gray-800 text-white text-center py-6 mt-12">
                <p className="text-sm">© 2025 Mistik Falcı • Powered by Stellar + Freighter</p>
              </footer>
            </LevelProvider>
          </ProfileProvider>
        </FreighterProvider>
      </body>
    </html>
  );
}
